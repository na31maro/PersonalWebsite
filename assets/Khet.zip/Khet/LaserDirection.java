
/**
 * Enumeration class LaserDirection - write a description of the enum class here
 * 
 * @author Nick and Freddy
 * @version 4/3/16
 */
public enum LaserDirection
{
    NORTH, SOUTH, EAST, WEST
}
