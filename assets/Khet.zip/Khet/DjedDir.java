
/**
 * Enumeration class DjedDir - holds values djed mirrors can face
 * 
 * @author Group 6
 * @version 4/1/16
 */
public enum DjedDir
{
    //Using back and fwd, the same way you would identify 
    //       / = BACK
    //       \ = FWD
    BACK, FWD
}
