import java.awt.*;
/**
 * Represents obelisk pieces which can be stacked and block the laser
 * 
 * @author Group 6 
 * @version 4/1/16
 */
public class Obelisk extends Piece
{
    //How many obelisks are stacked ("hitpoints")
    protected int hp;
    
    public Obelisk(Color c)
    {
        super(c);
        hp = 2;
    }
    
    /**
     * Get method for hp.
     * 
     * @return the hp of the Obelisk
     */
    public int getHP(){return hp;};

    /**
     * Decrease hp by 1.
     */
    public void decHP(){hp--;};
    
    /**
     * Increase hp by 1. 
     */
    public void incHP(){hp++;};
    
    public void rotate(){}
}
