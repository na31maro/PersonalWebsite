import java.awt.*;
/**
 * represents pharaoh piece, akin to king in chess, can't be hit by laser or you lose
 * 
 * @author Group 6
 * @version 4/1/16
 */
public class Pharaoh extends Piece
{
    public Pharaoh(Color c)
    {
        super(c);
    }

    public void rotate(){}
    
}
