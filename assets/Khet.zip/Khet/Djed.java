import java.awt.*;
/**
 * Represents the two-sided mirror pieces, djeds. 
 * 
 * @author Group 6
 * @version 4/1/16
 */
public class Djed extends Piece
{
    DjedDir dir;
    /**
     * Constructor for objects of class Djed
     */
    public Djed(Color c)
    {
        super(c);
        dir = DjedDir.BACK;
    }

    /**
     * This method changes the direction of the Djed.
     */
    public void rotate(){
        if (dir == DjedDir.BACK)
            dir = DjedDir.FWD;
        else
            dir = DjedDir.BACK;
    }
    
    /**
     * This method returns the direction. 
     * 
     * @return the direction the Djed is facing. 
     */
    public DjedDir getDir(){
        return dir;
    }
}
