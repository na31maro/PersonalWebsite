
/**
 * Enumeration class PMD - holds the directions that a pyramid mirror 
 * can face
 * 
 * @author Group 6
 * @version 4/1/16
 */
public enum PMD
{
    //Pyramid can face NorthEast, NorthWest
    //SouthEast, SouthWest
    NE, NW, SE, SW
}
