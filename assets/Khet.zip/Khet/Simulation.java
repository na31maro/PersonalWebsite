import java.applet.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import java.util.ArrayList;

/**
 * This program is an applet that simulates 
 * gameplay of KHET 1.0
 * @author Group 6
 * @version 4/13/16
 */
public class Simulation extends Applet implements MouseListener
{
    //==============================Constants=====================
    //width of each board square S_S = square side
    private final int S_S = 50;

    //x value where board ends
    private final int BOARD_X = S_S*11;

    // y value where board ends 
    private final int BOARD_Y = S_S*9;

    //represents number of points for drawing a pyramid
    private final int PPTS = 3;

    //represents number of points for drawing a djed
    private final int DPTS = 4;    

    //==========================GameBoard Properties==================
    //boolean to determine whether game has started or not
    private boolean isSetup = true;

    //2d array representation of the board
    private Piece[][] board = new Piece[10][8];

    //size of applet
    private Dimension d = getSize();

    //represents the current color 
    private Color c = Color.RED;

    //represents the colors of the outermost columns
    private Color blueSquare = new Color( 176, 226, 255);
    private Color redSquare = new Color( 255, 193, 193);

    //===========================Laser Data Members==================
    //current laser direction
    private LaserDirection curLasDir; 
    //coords for Laser Fire
    private ArrayList<Integer> laserCoordsAL = new ArrayList<Integer>();
    private boolean pieceDestroyed = false;
    private boolean ready4laser = false; 

    //===========================Arrays for drawing pieces==============
    //--------------------pyramids:
    //represent basis for drawing a NE-facing pyramid
    private int[] NEpyrX = {1, 1, S_S};
    private int[] NEpyrY = {1, S_S, S_S};

    //represent basis for drawing a SE- facing pyramid
    private int[] SEpyrX = {1, 1, S_S};
    private int[] SEpyrY = {1, S_S, 1};

    //represent basis for drawing a SW- facing pyramid
    private int[] SWpyrX = {1, S_S, S_S};
    private int[] SWpyrY = {1, 1, S_S};

    //represent basis for drawing a NW- facing pyramid
    private int[] NWpyrX = {1, S_S, S_S};
    private int[] NWpyrY = {S_S, S_S, 1};

    //--------------------djeds:
    //represent basis for drawing a SE facing djed 
    private int[] SEdjedX = {1, 6, S_S, S_S-5};
    private int[] SEdjedY = {S_S-5, S_S, 6, 1};

    //represent basis for drawing a SW facing djed 
    private int[] SWdjedX = {1, S_S-5, S_S, 6};
    private int[] SWdjedY = {6, S_S, S_S-5, 1};

    //===============================================================
    //represents number of pieces currently on board
    private int pieces = 0;

    //stores any sort of message to tell the player(s)
    private String message = "Setup"+
        " phase, players place all starting pieces";

    //tells whether it is blue's turn or not
    private boolean blueTurn = true;

    //represent where a piece was taken from
    private int origX = 0;
    private int origY = 0;

    private Piece piece = null;

    private boolean moved = false;

    //Switch to true for debug mode
    private boolean working = false;

    //Used to create a custom cursor in paint
    boolean mouseEntered = false;
    Toolkit toolkit = Toolkit.getDefaultToolkit();
    Image image = toolkit.getImage("flash.png");
    Cursor flash = toolkit.createCustomCursor(image , new Point(getX(), 
                getY()), "img");

    //Setting the customize Zootopia background
    private Image background;

    String soundfile1 = "laser.wav";
    String soundfile = "clicker.wav";
    String soundfile2 = "error.wav";
    //Used to fix the flickering issue
    Graphics bg; // The graphics for the screen before it is printed 
    //Image offscreen; // The image of the screen
    //int curX, curY;
    /**
     * This init method is 
     * called when the applet first starts, 
     * just adds mouse sensitivity
     */
    public void init(){ 
        addMouseListener(this); 
        background = getImage(getCodeBase(),"background.jpg");
        //offscreen = createImage(800,800); // Creating offscreen
        //bg = offscreen.getGraphics(); 
        // Creating bufferGraphics as the graphics object for offscreen
    }

    /**
     * This applets 
     * begins the applet and
     * paints it for the first time
     */
    public void start(){
        repaint();  
    }

    /**
     * obligatory mouseExited method
     * unused by our program.
     * needs to be defined because it is in the
     * mouselistener interface we implement
     * 
     * @param e event when mouse exits a component
     */
    public void mouseExited(MouseEvent e){}

    /**
     * allows for a custom cursor to be created
     * whenever the mouse enters the applet window
     * 
     * @param e event when mouse enters a component
     */
    public void mouseEntered(MouseEvent e){
        mouseEntered = true;
        repaint();
    }

    /**
     * allows pieces to be placed
     * and then adjusted in setup phase 
     * when boxes are clicked.
     * can end setup when button is clicked.
     * Allows legal moves to be made by each 
     * player when in gameplay phase.
     * Begins laser firing when each dot
     * is legally clicked.
     * 
     * @param e event when mouse is clicked
     */
    public void mouseClicked(MouseEvent e){
        //play a click sound
        play( getDocumentBase(), soundfile );
        e.consume();
        //automatically place pieces if team is testing
        if (isSetup && working){
            for (int i = 1; i < 8; i++)
                board[8][i] = new Pyramid(Color.RED);
            for (int i = 1; i < 8; i++)
                board[2][i] = new Pyramid(Color.BLUE);
            for (int i = 1; i < 3; i++)
                board[3][i] = new Djed(Color.RED);
            for (int i = 1; i < 3; i++)
                board[4][i] = new Djed(Color.BLUE);
            for (int i = 1; i < 3; i++)
                board[6][i] = new Obelisk(Color.RED);
            for (int i = 1; i < 3; i++)
                board[7][i] = new Obelisk(Color.BLUE);
            board[5][1] = new Pharaoh(Color.RED);
            board[5][2] = new Pharaoh(Color.BLUE);
            pieces = 24;
            repaint();
            working = false;
            c = Color.BLUE;
        }
        else{
            //if it is setup phase before gameplay begins
            if(isSetup){
                //calls method that handles clicks when setup
                this.setup(e); 
            }
            // not setup, actual gameplay
            else{
                //if click is in board
                if(e.getButton() == 1 && e.getX() > S_S && e.getX()<BOARD_X
                && e.getY() > S_S && e.getY() < BOARD_Y){
                    //locate clicks
                    for (int x = 1; x <11; x++){
                        for (int y = 1; y < 9; y++){
                            if (!moved && e.getX() > S_S*x 
                            && e.getX() < (x+1)*S_S && e.getY() > S_S*y 
                            && e.getY() < (y+1)*S_S){
                                //pick up piece 
                                //if piece of correct color is clicked
                                //and no piece has been picked up yet
                                if(board[x-1][y-1]!=null && piece == null 
                                && board[x-1][y-1].getColor() == c){
                                    piece = board[x-1][y-1];
                                    board[x-1][y-1] = null;
                                    origX = x-1;
                                    origY = y-1;
                                    repaint();
                                }

                                //message if wrong color piece is clicked
                                else if(board[x-1][y-1]!=null 
                                && piece == null && 
                                board[x-1][y-1].getColor() != c){
                                    message = "Cannot pick up piece."+
                                    " That is not your color.";
                                    repaint();
                                }

                                else if (board[x-1][y-1] == null &&
                                piece!=null){

                                    //place piece back in original space
                                    //no penalty
                                    if(!this.isRestricted(e) && x-1 == origX 
                                    && y-1 == origY){
                                        board[x-1][y-1] = piece;
                                        piece = null;
                                        repaint();
                                    }
                                    //place piece in empty adjacent space
                                    else if(!this.isRestricted(e) && 
                                    (x-2 == origX  || x-1 == origX ||
                                        x == origX) && (y-2 == origY
                                        || y-1== origY
                                        || y == origY))
                                    {
                                        board[x-1][y-1] = piece;
                                        piece = null;
                                        message = "Please click your "
                                        +"color's laser.";
                                        moved = true;
                                        repaint();
                                    }
                                    //error message if move illegal
                                    else{
                                        message = "Illegal move.";
                                        repaint();
                                    }
                                }
                                //error message if space
                                //is occupied
                                else if (board[x-1][y-1] != null 
                                && piece != null){
                                    message = "Space occupied; "+
                                    "Illegal move.";
                                    repaint();
                                }
                            }
                        }
                    }
                }
                //right click to rotate 90 degrees (clockwise)
                else if (!moved && e.getButton() == 3 &&  piece == null
                && e.getX() > S_S && e.getX()<BOARD_X &&
                e.getY() > S_S && e.getY() < BOARD_Y){
                    //locate clicks
                    for (int x = 1; x <11; x++){
                        for (int y = 1; y < 9; y++){ 
                            if (e.getX() > S_S*x && e.getX() < (x+1)*S_S
                            && e.getY() > S_S*y && e.getY() < (y+1)*S_S){
                                if (board[x-1][y-1]!= null &&
                                board[x-1][y-1].getColor().equals(c)){
                                    board[x-1][y-1].rotate();
                                    message = "Please click your color's "
                                    +"laser.";
                                    moved = true;
                                    repaint();
                                }
                            }
                        }
                    }
                }
                //middle click to rotate 270 degrees (90 counterclockwise)
                else if (!moved && e.getButton() == 2 && piece == null &&
                e.getX() > S_S && e.getX()<BOARD_X && e.getY() > S_S
                && e.getY() < BOARD_Y){
                    //locate clicks
                    for (int x = 1; x <11; x++){
                        for (int y = 1; y < 9; y++){ 
                            if (e.getX() > S_S*x && e.getX() < (x+1)*S_S
                            && e.getY() > S_S*y && e.getY() < (y+1)*S_S){
                                if (board[x-1][y-1]!= null &&
                                board[x-1][y-1].getColor().equals(c)){
                                    board[x-1][y-1].rotate();
                                    board[x-1][y-1].rotate();
                                    board[x-1][y-1].rotate();
                                    message = "Please click "
                                    +"your color's laser.";
                                    moved = true;
                                    repaint();
                                }
                            }
                        }
                    }
                }
                //space is right clicked with obelisk in hand stacks/unstacks
                else if (!moved && e.getButton() == 3 && piece != null
                && piece instanceof Obelisk ){
                    for (int x = 1; x <11; x++){
                        for (int y = 1; y < 9; y++){ 
                            if (e.getX() > S_S*x && e.getX() < (x+1)*S_S &&
                            e.getY() > S_S*y && e.getY() < (y+1)*S_S
                            && (x-2 == origX || x-1 == origX || x == origX)
                            &&(y-2 == origY || y-1 == origY || y == origY)){
                                // unstack
                                if (!isRestricted(e) 
                                && board[x-1][y-1] == null
                                && ((Obelisk)piece).getHP()>1){
                                    board[x-1][y-1] = new Obelisk(c);
                                    ((Obelisk)board[x-1][y-1]).decHP();
                                    ((Obelisk)piece).decHP();
                                    board[origX][origY] = piece;
                                    piece = null;
                                    pieces++;
                                    message = "Please click your "
                                    +"color's laser.";
                                    moved = true;
                                    repaint();
                                }
                                // stack
                                else if(board[x-1][y-1] != null
                                && board[x-1][y-1] instanceof Obelisk
                                && board[x-1][y-1].getColor().equals(c)
                                && ((Obelisk)board[x-1][y-1]).getHP() == 1
                                && ((Obelisk)piece).getHP()==1){
                                    piece = null;
                                    ((Obelisk)board[x-1][y-1]).incHP();
                                    pieces--;
                                    message = "Please click your "
                                    +"color's laser.";
                                    moved = true;
                                    repaint();
                                }
                            }
                        }
                    }
                }
                //swaps if djed is held 
                //and another adjacent piece right clicked
                else if (!moved && e.getButton() == 3 
                && piece != null && piece instanceof Djed ){
                    for (int x = 1; x <11; x++){
                        for (int y = 1; y < 9; y++){ 
                            if (e.getX() > S_S*x && e.getX() < (x+1)*S_S
                            && e.getY() > S_S*y && e.getY() < (y+1)*S_S
                            && (x-2 == origX || x-1 == origX || x == origX)
                            && (y-2 == origY || y-1 == origY || y == origY)
                            && board[x-1][y-1]!=null && (board[x-1][y-1] 
                                instanceof Obelisk || board[x-1][y-1] 
                                instanceof Pyramid)){
                                board[origX][origY] = board[x-1][y-1];
                                board[x-1][y-1] = piece;
                                piece = null;
                                moved = true;
                                message = "Please click your color's laser.";
                                repaint();
                            }
                        }
                    }
                }
                //If red button is pressed fire red laser
                //and end turn
                else if( moved && (e.getX() >= 65 && e.getX() <= 81)
                && (e.getY() >= 30 && e.getY() <= 46)){
                    if( !blueTurn)
                    {
                        play( getDocumentBase(), soundfile1 );
                        redLaser(); 
                        endTurn();
                    }
                    else
                    {
                        play( getDocumentBase(), soundfile2 );
                        message = "Incorrect move...Blue Player " +
                        "cannot fire Red Player's Laser.  Make a Legal" +
                        " turn.";
                        repaint();
                    }
                }   

                //If Blue button is pressed fire Blue laser
                //and end turn
                else if( moved && (e.getX() >= 515 && e.getX() <= 531)
                && (e.getY() >= 454 && e.getY() <= 470)){
                    if( blueTurn )
                    {
                        play( getDocumentBase(), soundfile1 );
                        blueLaser();
                        endTurn();
                    }       
                    else
                    {
                        //Incorrect move...Red cannot fire Blue's Laser
                        play( getDocumentBase(), soundfile2 );
                        message = "Incorrect move...Red Player " +
                        "cannot fire Blue Player's Laser.  Make a Legal" +
                        " turn"; 
                        repaint();
                    }
                }
                else{}
            }
        }
        e.consume();
    }

    /**
     * This method
     * checks which color's turn it is
     * and then changes it to the
     * opposite's turn
     */
    public void endTurn(){
        if(blueTurn){
            c = Color.RED;
            blueTurn = false;
            moved = false;
            message = "Red move.";
            repaint();
        }
        else{
            c = Color.BLUE;
            blueTurn = true;
            moved = false;
            message = "Blue move.";
            repaint();
        }
    }

    public void mousePressed(MouseEvent e){}

    public void mouseReleased(MouseEvent e){}

    public void  paint (Graphics g){
        d = getSize();
        //fontmetrics, used to center text
        FontMetrics f = g.getFontMetrics();
        g.drawImage(background, 0, 0, 800, 700, this);
        paintBoard(g);

        paintPieces(g);
        //Painting a cursor
        if (mouseEntered) setCursor(flash);; 
        if(ready4laser){
            drawLaser(g);
            ready4laser = false; 
        }
        // Finally, draw offscreen to g as the whole screen
        //g.drawImage(offscreen,0,0,this); 
    }

    ////////////////////////////////////////
    ///////////////////////////////////////
    //*********LASER METHODS*********//
    ////////////////////////////////////////
    ///////////////////////////////////////

    /**
     * drawLaser will look at the coordinates
     * listed int laserCoordsAL 
     * and print the laser lines based on them. 
     * 
     * @param g - applet graphics
     */

    public void drawLaser(Graphics g){
        for(int i=0; i<laserCoordsAL.size()-2; i+=2){              
            g.setColor(Color.GREEN);
            g.drawLine(laserCoordsAL.get(i), laserCoordsAL.get(i+1),
                laserCoordsAL.get(i+2), laserCoordsAL.get(i+3));
        }
        laserCoordsAL.clear();
    }        

    /**
     * This is the
     * Starter method for the red laser button push 
     */
    public void redLaser(){
        pieceDestroyed = false; 
        laserCoordsAL.clear(); 
        curLasDir = LaserDirection.SOUTH;
        int x = 0;
        int y = 0; 
        //Add edge of board
        laserCoordsAL.add((50*(x+2)-25));
        laserCoordsAL.add((50*(y+2)-50));

        //Loop through board "SOUTH" 
        for(int i = y; i<8; i++){
            if(board[x][i]!=null){

                //Add piece coords
                laserCoordsAL.add((50*(x+2)-25));
                laserCoordsAL.add((50*(i+2)-25));

                handlePiece(x,i);
                if(!pieceDestroyed)
                    advanceLaser(x,i);
                return;
            }
        }

        laserCoordsAL.add((50*(x+2)-25));
        laserCoordsAL.add(BOARD_Y);

        ready4laser = true;
    }

    /** 
     * This is the 
     * Starter method for the blue laser button push. 
     */
    public void blueLaser(){
        pieceDestroyed = false; 
        laserCoordsAL.clear(); 
        curLasDir = LaserDirection.NORTH;
        int x = 9;
        int y = 7; 

        //Add edge of board
        laserCoordsAL.add((50*(x+2)-25));
        laserCoordsAL.add((50*(y+2)));
        for(int i = y; i>=0; i--){
            if(board[x][i]!=null){

                //Add piece coords
                laserCoordsAL.add((50*(x+2)-25));
                laserCoordsAL.add((50*(i+2)-25));

                handlePiece(x,i);
                if(!pieceDestroyed)
                    advanceLaser(x,i);
                return;
            }
        }

        laserCoordsAL.add((50*(x+2)-25));
        laserCoordsAL.add(S_S);

        ready4laser = true;
    }

    /**
     * advanceLaser() will take in 2 coordinates that represent spaces on the 
     * board. The method contains 4 for loops, one for searching up, down, left
     * and right on the board. The search is looking for an existing piece and 
     * draws a line from the parameter coords to the piece coords. If it 
     * finds none, than the laser hits a wall.
     * 
     * @param x - x coord of the start of search
     * @param y - y coord of the start of search  
     */
    public void advanceLaser(int x, int y){
        if(curLasDir == LaserDirection.SOUTH){
            //Loop through board "SOUTH" 
            for(int i = y+1; i<8; i++){
                if(board[x][i]!=null){                  
                    laserCoordsAL.add((50*(x+2)-25));
                    laserCoordsAL.add((50*(i+2)-25));

                    handlePiece(x,i);
                    if(!pieceDestroyed)
                        advanceLaser(x,i);
                    return;
                }
            }
            //No Piece Found Going "SOUTH"
            laserCoordsAL.add((50*(x+2)-25));
            laserCoordsAL.add(BOARD_Y);
            ready4laser = true;

        }
        else if(curLasDir == LaserDirection.NORTH){
            //Loop through board "NORTH" 
            for(int i = y-1; i>=0; i--){
                if(board[x][i]!=null){

                    laserCoordsAL.add((50*(x+2)-25));
                    laserCoordsAL.add((50*(i+2)-25));
                    handlePiece(x,i);
                    if(!pieceDestroyed)
                        advanceLaser(x,i);
                    return;
                }
            }
            //No Piece Found Going "NORTH"
            laserCoordsAL.add((50*(x+2)-25));
            laserCoordsAL.add(S_S);
            ready4laser = true;

        }
        else if(curLasDir == LaserDirection.EAST){
            //Loop through board "EAST" 
            for(int i = x+1; i<10; i++){
                if(board[i][y]!=null){
                    laserCoordsAL.add((50*(i+2)-25));
                    laserCoordsAL.add((50*(y+2)-25));

                    handlePiece(i,y);
                    if(!pieceDestroyed)
                        advanceLaser(i,y);
                    return;
                }
            }
            //No Piece Found Going "EAST"
            laserCoordsAL.add(BOARD_X);
            laserCoordsAL.add(50*(y+2)-25);

            ready4laser = true;

        }
        else if(curLasDir == LaserDirection.WEST){
            //Loop through board "WEST" 
            for(int i = x-1; i>=0; i--){
                if(board[i][y]!=null){
                    laserCoordsAL.add(50*(i+2)-25);
                    laserCoordsAL.add(50*(y+2)-25);

                    handlePiece(i,y);
                    if(!pieceDestroyed)
                        advanceLaser(i,y);
                    return;
                }
            }
            //No Piece Found Going "WEST"
            laserCoordsAL.add(S_S);
            laserCoordsAL.add((50*(y+2)-25));
            ready4laser = true;
        }

    }

    ////////////////////////////////////////
    ///////////////////////////////////////
    //************HANDLE METHODS*********//
    ////////////////////////////////////////
    ///////////////////////////////////////

    /**
     * This method will take two coordinates
     * of a piece where the laser hit
     * and will determine which
     * type of piece, a Pyramid, Obelisk,
     * Djed, or Pharaoh is was hit.
     * Once determined, this method will
     * then call upon the correct
     * handle method to determine what will be done
     * to the piece (be destroyed,reflect off
     * a mirror, destack, or end game)
     * 
     * @param x int value of the gameboard 
     * that this method is checking what
     * type of piece it is
     * 
     * @param y int value of the gameboard
     * that this method is checking what
     * type of piece it is
     */
    public void handlePiece(int x, int y){
        if(board[x][y] instanceof Pyramid)
            handlePyramid(x,y);        
        else if (board[x][y] instanceof Obelisk)
            handleObelisk(x,y);
        else if (board[x][y] instanceof Djed)
            handleDjed(x,y);
        else if (board[x][y] instanceof Pharaoh)
            handlePharaoh(x,y);
    }

    /**
     * This method will detemine which player
     * wins when a pharoah is hit with a laser
     * and will end the game.
     * 
     * @param x int value of the gameboard
     * where a pharaoh is present
     * @param y int value of the gameboard
     * where a pharaoh is present
     */
    public void handlePharaoh(int x, int y)
    {
        //checks what color the pharaoh is
        String phColor = "";
        if(board[x][y].getColor() == Color.RED)
            phColor = "Red";
        else
            phColor = "Blue";        

        //removes Pharaoh from the board
        board[x][y] = null;
        pieces--;
        repaint();

        //notifies that the opposing side wins
        //end of the game

        JFrame winningMessage = new JFrame("END OF GAME");

        if(phColor == "Red")
        {
            JOptionPane.showMessageDialog( winningMessage, "Blue wins!");
            System.exit(0);
        }
        else
        {
            JOptionPane.showMessageDialog( winningMessage, "Red wins!");
            System.exit(0);
        }
    }

    /**
     * This method will determine what
     * happens to an obelisk when it is
     * hit with a laser.  Either
     * the piece will be destroyed
     * or will destack (destroy one
     * of the stacked Obelisks)
     * 
     * @param x int value of the gameboard
     * where an Obelisk is present
     * @param y int value of the gameboard
     * where an Obelisk is present
     */
    public void handleObelisk(int x, int y)
    {
        int curHP = ((Obelisk)board[x][y]).getHP();
        //Obelisk is stacked
        if( curHP > 1) {      
            ((Obelisk)board[x][y]).decHP();
            pieceDestroyed = true;
            ready4laser=true;
        }        

        //Obelsik is not stacked
        if( curHP == 1)
        {
            board[x][y] = null;
            pieceDestroyed = true;
            ready4laser=true;
            pieces--;
        }
    }

    /**
     * This method will determine what
     * happens when a Djed is hit with
     * a laser.  The piece cannot be
     * destroyed so they can only
     * reflect the laser in another
     * direction.
     * 
     * @param x int value of the gameboard
     * where a Djed is present
     * @param y int value of the gameboard
     * where a Djed is present
     */
    public void handleDjed(int x, int y)
    {
        //Reflects
        if( curLasDir == LaserDirection.NORTH)
        {
            //If Djed is in BACK position
            //Laser moves West
            if( ((Djed)board[x][y]).getDir() == DjedDir.BACK)            
                curLasDir = LaserDirection.EAST;           

            //If Djed is in FWD position
            //Laaser moves East
            else
                curLasDir = LaserDirection.WEST;            
        }
        else if( curLasDir == LaserDirection.SOUTH)
        {
            //If Djed is in BACK position
            //Laser moves East
            if(((Djed)board[x][y]).getDir() == DjedDir.BACK)
                curLasDir = LaserDirection.WEST;
            else
            {
                //If Djed is in FWD position
                //Laaser moves West
                curLasDir = LaserDirection.EAST;
            }
        }
        else if( curLasDir == LaserDirection.EAST)
        {
            //If Djed is in BACK position
            if(((Djed)board[x][y]).getDir() == DjedDir.BACK)
            {
                curLasDir = LaserDirection.NORTH;
            }
            else
            {
                //If Djed is in FWD position
                curLasDir = LaserDirection.SOUTH;
            }
        }
        else if( curLasDir == LaserDirection.WEST)
        {
            //If Djed is in BACK position
            //Laser moves North
            if(((Djed)board[x][y]).getDir() == DjedDir.BACK)            
                curLasDir = LaserDirection.SOUTH;            
            else
            {
                //If Djed is in FWD position
                //Laaser moves South 
                curLasDir = LaserDirection.NORTH;
            }
        }

    }

    /**
     * This method will determine what
     * happens when a Pyramid is hit with
     * a laser.  The piece will either
     * be destroyed or reflect the laser
     * in a different direction.
     * 
     * @param x int value of the gameboard
     * where a Pyramid is present
     * @param y int value of the gameboard
     * where a Pyramid is present
     */
    public void handlePyramid(int x, int y)
    {
        //Figure what direction the Pyramid is in
        if( ((Pyramid)board[x][y]).getDir() == PMD.NE)
        {
            //PYR is in NE direction and laser is coming

            if( curLasDir == LaserDirection.NORTH)
            {
                //Laser is moving north, hitting the south side
                //of the pyramid
                //piece is destroyed
                board[x][y] = null;
                pieceDestroyed = true;
                ready4laser=true;
                pieces--;
            }
            else if( curLasDir == LaserDirection.EAST)
            {
                //Laser is moving East, hitting the West side
                //of the pyramid
                //piece is destroyed
                board[x][y] = null;
                pieceDestroyed = true;
                ready4laser=true;
                pieces--;
            }
            else if( curLasDir == LaserDirection.SOUTH)
            {
                //Laser is moving south, hitting the north
                //side of the pyramid
                //REFLECTS
                curLasDir = LaserDirection.EAST;
            }
            else if( curLasDir == LaserDirection.WEST){
                //Laser is moving west, hitting the east
                //side of the pyramid
                //Reflects
                curLasDir = LaserDirection.NORTH;
            }
        }
        else if( ((Pyramid)board[x][y]).getDir() == PMD.NW)
        {
            //PYR is in NW direction and laser is coming
            if( curLasDir == LaserDirection.NORTH)
            {
                //Laser is coming down on South side
                //of pyramid
                //piece is destroyed
                board[x][y] = null;
                pieceDestroyed = true;
                ready4laser=true;
                pieces--;
            }
            else if( curLasDir == LaserDirection.EAST)
            {
                //Laser is coming down on West side
                //of pyramid
                //REFLECTS
                curLasDir = LaserDirection.NORTH;
            }
            else if( curLasDir == LaserDirection.SOUTH)
            {
                //Laser is coming down on North side
                //of pyramid
                //REFLECTS
                curLasDir = LaserDirection.WEST;
            }
            else if( curLasDir == LaserDirection.WEST){
                //Laser is coming down on East side
                //of pyramid
                //piece is destroyed
                board[x][y] = null;
                pieceDestroyed = true;
                ready4laser=true;
                pieces--;
            }
        }
        else if( ((Pyramid)board[x][y]).getDir() == PMD.SE)
        {
            if( curLasDir == LaserDirection.NORTH)
            {
                //Laser is coming down on South side
                //of pyramid
                //Reflects
                curLasDir = LaserDirection.EAST;
            }
            else if( curLasDir == LaserDirection.EAST)
            {
                //Laser is coming down on West side
                //of pyramid
                //piece is destroyed
                board[x][y] = null;
                pieceDestroyed = true;
                ready4laser=true;
                pieces--;
            }
            else if( curLasDir == LaserDirection.SOUTH)
            {
                //Laser is coming down on North side
                //of pyramid
                //piece is destroyed
                board[x][y] = null;
                pieceDestroyed = true;
                ready4laser=true;
                pieces--;
            }
            else if( curLasDir == LaserDirection.WEST){
                //Laser is coming down on East side
                //of pyramid
                //Reflects
                curLasDir = LaserDirection.SOUTH;
            }
        }
        else if(((Pyramid)board[x][y]).getDir() == PMD.SW)
        {
            if( curLasDir == LaserDirection.NORTH)
            {
                //Laser is coming down on South side
                //of pyramid
                //Reflects
                curLasDir = LaserDirection.WEST;
            }
            else if( curLasDir == LaserDirection.EAST)
            {
                //Laser is coming down on West side
                //of pyramid
                //Reflects
                curLasDir = LaserDirection.SOUTH;
            }
            else if( curLasDir == LaserDirection.SOUTH)
            {
                //Laser is coming down on North side
                //of pyramid
                //piece is destroyed
                board[x][y] = null;
                pieceDestroyed = true;
                ready4laser=true;
                pieces--;
            }
            else if( curLasDir == LaserDirection.WEST)
            {
                //Laser is coming down on EAST side
                //of pyramid
                //piece is destroyed
                board[x][y] = null;
                pieceDestroyed = true;
                ready4laser=true;
                pieces--;
            }
        }
    }

    ////////////////////////////////////////
    ///////////////////////////////////////
    //*****OTHER GRAPHIS METHODS*********//
    ////////////////////////////////////////
    ///////////////////////////////////////

    /**
     * takes in piece, determines its type,
     * and uses basis array fields to fill it
     * if necessary for that piece type.
     * 
     * @param x the position horizontally
     * of the piece in the board array
     * @param y the position vertically
     * of the piece in the board array
     * @param curPiece the piece to draw
     * 
     * @return the Polygon object that represents
     * the piece in its correct onscreen position
     */
    public Polygon makePolygon(int x, int y, Piece curPiece){
        //pyramid, represented by right triangle
        if(curPiece instanceof Pyramid){
            //facing northeast
            if (((Pyramid)(curPiece)).getDir() == PMD.NE){
                int[] pyrX = new int[3];
                int[] pyrY = new int[3];
                for (int i = 0; i<3; i++)
                    pyrX[i] = NEpyrX[i]+(x+1)*S_S;
                for (int i = 0; i<3; i++)
                    pyrY[i] = NEpyrY[i]+(y+1)*S_S;
                return new Polygon(pyrX,pyrY,PPTS);
            }
            //facing southeast
            else if(((Pyramid)(curPiece)).getDir() == PMD.SE){
                int[] pyrX = new int[3];
                int[] pyrY = new int[3];
                for (int i = 0; i<3; i++)
                    pyrX[i] = SEpyrX[i]+(x+1)*S_S;
                for (int i = 0; i<3; i++)
                    pyrY[i] = SEpyrY[i]+(y+1)*S_S;
                return new Polygon(pyrX,pyrY,PPTS);
            }
            //facing southwest
            else if(((Pyramid)(curPiece)).getDir() == PMD.SW){
                int[] pyrX = new int[3];
                int[] pyrY = new int[3];
                for (int i = 0; i<3; i++)
                    pyrX[i] = SWpyrX[i]+(x+1)*S_S;
                for (int i = 0; i<3; i++)
                    pyrY[i] = SWpyrY[i]+(y+1)*S_S;
                return new Polygon(pyrX,pyrY,PPTS);
            }
            //facing northwest
            else{
                int[] pyrX = new int[3];
                int[] pyrY = new int[3];
                for (int i = 0; i<3; i++)
                    pyrX[i] = NWpyrX[i]+(x+1)*S_S;
                for (int i = 0; i<3; i++)
                    pyrY[i] = NWpyrY[i]+(y+1)*S_S;
                return new Polygon(pyrX,pyrY,PPTS);
            }
        }
        //djed, represented by
        //diagonally oriented rectangle
        if(curPiece instanceof Djed){
            if (((Djed)(curPiece)).getDir() == DjedDir.FWD){
                int[] dX = new int[4];
                int[] dY = new int[4];
                for (int i = 0; i<4; i++)
                    dX[i] = SWdjedX[i]+(x+1)*S_S;
                for (int i = 0; i<4; i++)
                    dY[i] = SWdjedY[i]+(y+1)*S_S;
                return new Polygon(dX,dY,DPTS);
            }
            else{
                int[] dX = new int[4];
                int[] dY = new int[4];
                for (int i = 0; i<4; i++)
                    dX[i] = SEdjedX[i]+(x+1)*S_S;
                for (int i = 0; i<4; i++)
                    dY[i] = SEdjedY[i]+(y+1)*S_S;
                return new Polygon(dX,dY,DPTS);
            }
        }
        //obelisk, represented by square
        if(curPiece instanceof Obelisk){
            int []oX = {1+(x+1)*S_S, (x+2)*S_S, (x+2)*S_S, 1+(x+1)*S_S};
            int []oY = {1+(y+1)*S_S, 1+(y+1)*S_S, (y+2)*S_S, (y+2)*S_S};
            return new Polygon(oX, oY, 4);
        }
        //pharaoh, represented by hourglass shape
        else{
            int[]pX = {1+(x+1)*S_S, (x+2)*S_S, 1+(x+1)*S_S, (x+2)*S_S};
            int[]pY = {1+(y+1)*S_S, 1+(y+1)*S_S, (y+2)*S_S, (y+2)*S_S};
            return new Polygon(pX, pY, 4);
        }        
    }
    //==================Paint Methods=======================
    /**
     * Paints the board spaces in a 10 by 8 grid
     *
     *@param g - applet graphics
     */
    public void paintBoard(Graphics g){
        FontMetrics f = g.getFontMetrics();

        if (piece != null){
            g.setColor(new Color(230, 217, 127));
            g.fillRect((origX+1)*S_S, (origY+1)*S_S, 50,50);
        }

        //Blue Color restricted Squares
        g.setColor(blueSquare);
        g.fillRect(BOARD_Y + 50, S_S , 50, 400 );
        g.fillRect(S_S + S_S, S_S, S_S, S_S);
        g.fillRect(S_S + S_S, BOARD_Y - S_S, S_S, S_S);

        //Red Color restricted Squares
        g.setColor(redSquare);
        g.fillRect(S_S, S_S, 50, 400);
        g.fillRect(BOARD_X - 100, S_S, S_S, S_S);
        g.fillRect(BOARD_X -100 ,BOARD_Y -50,S_S ,S_S );

        g.setColor(Color.BLACK);
        // draws vertical lines
        for (int i = 0; i<=10; i++){
            g.drawLine(i*S_S+S_S, S_S, i*S_S+S_S, BOARD_Y);
        }
        //draws horizontal lines
        for (int i = 0; i<=8; i++){
            g.drawLine(S_S, i*S_S+S_S, BOARD_X, i*S_S+S_S);
        }

        //draws a message for the player if applicable
        g.drawString(message, d.width/2-f.stringWidth(message)/2,
            BOARD_Y+90);        

        if(isSetup){
            //creates a button to be clicked 
            g.setColor(Color.RED);
            g.fillRect(d.width/2-50,BOARD_Y+25, 100, 50);
            g.setColor(Color.WHITE);
            g.drawString("Click to Start",
                d.width/2-f.stringWidth("Click to Start")/2, BOARD_Y+55);
        }

        //adds two buttons that will fire each laser

        //Red Laser Button
        g.setColor(Color.RED);
        g.fillOval(65,30,16,16);

        //Blue Laser Button
        g.setColor(Color.BLUE);
        g.fillOval(515,454,16,16);
    }

    /**
     * paintPieces contains loop to display all pieces on board.
     * 
     * @param g - applet graphics
     */
    public void paintPieces(Graphics g){
        // massive for loop to display all pieces in board
        for(int row = 0; row < 10; row++){
            for (int col = 0; col < 8; col++){
                Piece curPiece = board[row][col];
                if (curPiece!=null){
                    g.setColor(curPiece.getColor());
                    g.fillPolygon(this.makePolygon(row,col,curPiece));
                }
                if (curPiece instanceof Obelisk){
                    String hp = ""+((Obelisk)(curPiece)).getHP();
                    g.setColor(Color.WHITE);
                    g.drawString(hp, (int)((row+2)*S_S - (S_S*.5)),
                        (int)((col+2)*S_S - (S_S*.5)));
                }
            }
        }
    }

    /**
     * This method is used to setup the 
     * gameboard with each colors' pieces.
     * @param the click to be interpreted
     */
    public void setup(MouseEvent e){
        if(e.getX()<d.width/2+50 && e.getX()>d.width/2-50 && 
        e.getY()<BOARD_Y+25+50 &&  e.getY()> BOARD_Y+25 && 
        pieces != 24){
            message = "Not all pieces have been placed. Please place"+
            " all 24 starting pieces.";
            repaint();
        }
        //End setup phase
        else if(piece == null && e.getX()<d.width/2+50 &&
        e.getX()>d.width/2-50 && e.getY()<BOARD_Y+25+50
        && e.getY()> BOARD_Y+25&& pieces == 24){
            isSetup=false; 
            message = "Get Ready to Play: Blue move.";
            repaint();
        }
        //If board space is clicked, place current piece.
        else if (pieces < 24 && 
        e.getX() > S_S && e.getX()<BOARD_X && 
        e.getY() > S_S && e.getY() < BOARD_Y){
            if (pieces%2 ==0)
                c = Color.RED;
            else
                c = Color.BLUE;
            Piece curPiece;

            if (pieces < 14){

                curPiece = new Pyramid(c);
            }
            else if (pieces < 18)
            {
                curPiece = new Djed(c);
            }
            else if (pieces < 22)
            {
                curPiece = new Obelisk(c);
            }
            else
            {
                curPiece = new Pharaoh(c);

            }
            for (int x = 1; x <11; x++){
                for (int y = 1; y < 9; y++){
                    if (board[x-1][y-1]==null && 
                    e.getX() > S_S*x && e.getX() < (x+1)*S_S && 
                    e.getY() > S_S*y && e.getY() < (y+1)*S_S &&
                    !this.isRestrictedSetup(e)){
                        board[x-1][y-1] = curPiece;
                        pieces++;
                        if (pieces == 24)
                            message = "All pieces placed, rotate "+
                            "and press red button when ready.";

                        repaint();
                    }
                }
            }
        }
        //Rotate pieces.
        else if (e.getButton() == MouseEvent.BUTTON3 && e.getX() > S_S
        && e.getX()<BOARD_X && e.getY() > S_S && e.getY() < BOARD_Y){
            for (int x = 1; x <11; x++){
                for (int y = 1; y < 9; y++){
                    if (board[x-1][y-1]!=null && e.getX() > S_S*x
                    && e.getX() < (x+1)*S_S && e.getY() > S_S*y
                    && e.getY() < (y+1)*S_S){
                        board[x-1][y-1].rotate();
                        repaint();
                    }
                }
            }
        }
        // pieck up a piece if one hasn't been already
        else if (e.getButton() == MouseEvent.BUTTON1 &&
        piece == null && e.getX() > S_S && e.getX()<BOARD_X
        && e.getY() > S_S && e.getY() < BOARD_Y){
            for (int x = 1; x <11; x++){
                for (int y = 1; y < 9; y++){
                    if (board[x-1][y-1]!=null && e.getX() > S_S*x
                    && e.getX() < (x+1)*S_S && e.getY() > S_S*y
                    && e.getY() < (y+1)*S_S){
                        piece = board[x-1][y-1];
                        board[x-1][y-1] = null;
                        repaint();
                    }
                }
            }
        }
        //place piece if one has been picked up
        else if (e.getButton() == MouseEvent.BUTTON1 && piece != null
        && e.getX() > S_S && e.getX()<BOARD_X && e.getY() > S_S &&
        e.getY() < BOARD_Y && !this.isRestricted(e)){
            for (int x = 1; x <11; x++){
                for (int y = 1; y < 9; y++){
                    if (board[x-1][y-1]==null && e.getX() > S_S*x &&
                    e.getX() < (x+1)*S_S && e.getY() > S_S*y &&
                    e.getY() < (y+1)*S_S ){
                        board[x-1][y-1] = piece;
                        piece = null;
                        repaint();
                    }
                }
            }
        }
    }

    /**
     * This method pops a JOptionPane with a the 
     * message of a passed in string. 
     * 
     * @param s any string. 
     */
    public void debug(String s){
        JOptionPane.showMessageDialog(this,
            s, "Inane custom dialog",
            JOptionPane.INFORMATION_MESSAGE,
            null);
    }

    /**
     * checks if a move is illegally made 
     * during initial piece placement phase
     * by putting a piece of the wrong color 
     * into a colored square
     * 
     * @param e the piece placing to be checked
     * 
     * @return true if move is restricted,
     * false if it is legal
     */
    public boolean isRestrictedSetup(MouseEvent e){
        if (c.equals(Color.BLUE) && ((e.getX() > S_S && e.getX()<S_S*2
                && e.getY() > S_S && e.getY() < BOARD_Y) || (e.getX() > 9*S_S
                && e.getX() < 10*S_S && e.getY()> S_S && e.getY()<S_S*2) ||
            (e.getX() > 9*S_S && e.getX() < 10*S_S && e.getY()>8*S_S
                && e.getY() < BOARD_Y)))
            return true;
        else if (c.equals(Color.RED) && ((e.getX() > S_S*10
                && e.getX()<BOARD_X && e.getY() > S_S && e.getY() < BOARD_Y)
            || (e.getX() > 2*S_S && e.getX() < 3*S_S && e.getY()> S_S
                && e.getY()<S_S*2) ||  (e.getX() > 2*S_S && e.getX() < 3*S_S
                && e.getY()>8*S_S && e.getY() < BOARD_Y)))
            return true;
        else
            return false;
    }

    /**
     * checks if a move is illegally made
     * by putting a piece of the wrong color 
     * into a colored square
     * 
     * @param e the click to be checked
     * 
     * @return true if move is restricted,
     * false if it is legal
     */
    public boolean isRestricted(MouseEvent e){
        if (piece.getColor().equals(Color.BLUE) && ((e.getX() > S_S
                && e.getX()<S_S*2 && e.getY() > S_S && e.getY() < BOARD_Y)
            || (e.getX() > 9*S_S && e.getX() < 10*S_S && e.getY()> S_S
                && e.getY()<S_S*2) ||  (e.getX() > 9*S_S && e.getX() < 10*S_S
                && e.getY()>8*S_S && e.getY() < BOARD_Y)))
            return true;
        else if (piece.getColor().equals(Color.RED) && ((e.getX() > S_S*10
                && e.getX()<BOARD_X && e.getY() > S_S && e.getY() < BOARD_Y)
            || (e.getX() > 2*S_S && e.getX() < 3*S_S && e.getY()> S_S
                && e.getY()<S_S*2) ||  (e.getX() > 2*S_S && e.getX() < 3*S_S
                && e.getY()>8*S_S && e.getY() < BOARD_Y)))
            return true;
        else
            return false;
    }
}