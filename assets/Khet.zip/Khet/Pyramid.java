import java.awt.*;
/**
 * Represents single-sided mirror pieces, pyramids
 * 
 * @author Group 6
 * @version 4/1/16
 */
public class Pyramid extends Piece
{
    PMD dir;
    public Pyramid(Color c)
    {
        super(c);
        dir = PMD.NE;
    }

    public void rotate(){
        if (dir == PMD.NE)
            dir = PMD.SE;
        else if (dir == PMD.SE)
            dir = PMD.SW;
        else if (dir == PMD.SW)
            dir = PMD.NW;
        else
            dir = PMD.NE;
    }
    
    public PMD getDir(){
        return dir;
    }
}

