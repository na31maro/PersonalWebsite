import java.awt.*;
/**
 * Abstract class that cannot be instantiated. 
 * Holds crucial data common to all pieces such as color and coordinates 
 * 
 * @author Group 6
 * @version 4/1/16
 */
public abstract class Piece
{
    protected Color color;
    protected boolean isAlive;

    public Piece(Color c){
        color = c;
    }

    public Color getColor(){return color;}

    public void remove(){isAlive = false;}
    
    public abstract void rotate();
}
