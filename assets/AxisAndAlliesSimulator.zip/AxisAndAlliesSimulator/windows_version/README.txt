Thanks for downloading my Axis and Allies Combat Simulator! 

To run, you will need to have Java installed, and you may also need a JDK.
 
Windows 
To run the program, just open the runProgram bat file to execute 
the project in command prompt. 

Mac
Open Terminal and navigate to the directory containing 
AxisAndAlliesSimulator.jar
Execute the command java -jar AxisAndAlliesSimulator.jar 