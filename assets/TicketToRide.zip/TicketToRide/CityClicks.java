import java.awt.event.*;
/**
 * This class is used to determine which city a player
 * clicks on.
 * 
 * @author Nick
 * @version 1.0
 */
public class CityClicks
{
    
    /**
     * This method returns a string of the city name that was 
     * clicked last to be used in other methods, classes, in order
     * to purchase routes between cities.
     * 
     * @param e MouseEvent where the mouse is 
     *          currently located.
     *          
     * @return String the name of the city that was 
     *         clicked on.
     */
    public String checkCityClick(MouseEvent e){
        if(locateClick(e,403,423,32,52))
            return "Stornoway";

        else if(locateClick(e,439,459,79,99))
            return "Ullapool";

        else if(locateClick(e,564,584,78,98))
            return "Wick";

        else if(locateClick(e,391,411,168,188))
            return "Fort William";

        else if(locateClick(e,473,493,124,144))
            return "Inverness";

        else if(locateClick(e,555,575,204,224))
            return "Aberdeen";

        else if(locateClick(e,220,240,251,271))
            return "Londonderry";

        else if(locateClick(e,396,416,268,288))
            return "Glasgow";

        else if(locateClick(e,457,477,285,305))
            return "Edinburgh";

        else if(locateClick(e,497,517,239,259))
            return "Dundee";

        else if(locateClick(e,118,138,285,305))
            return "Sligo";

        else if(locateClick(e,325,345,325,345))
            return "Stranraer";

        else if(locateClick(e,263,283,330,350))
            return "Belfast";

        else if(locateClick(e,45,65,354,374))
            return "Galway";

        else if(locateClick(e,211,231,367,387))
            return "Dundalk";

        else if(locateClick(e,420,440,380,400))
            return "Carlisle";

        else if(locateClick(e,492,512,399,419))
            return "Newcastle";

        else if(locateClick(e,46,66,422,442))
            return "Limerick";

        else if(locateClick(e,126,146,407,427))
            return "Tullamore";

        else if(locateClick(e,187,207,423,443))
            return "Dublin";

        else if(locateClick(e,378,398,428,448))
            return "Barrow";

        else if(locateClick(e,34,54,491,511))
            return "Cork";

        else if(locateClick(e,135,155,503,523))
            return "Rosslare";

        else if(locateClick(e,276,296,468,488))
            return "Howhead";

        else if(locateClick(e,351,371,481,501))
            return "Liverpool";

        else if(locateClick(e,454,474,486,506))
            return "Leeds";

        else if(locateClick(e,254,274,554,574))
            return "Aberystwyth";

        else if(locateClick(e,399,419,512,532))
            return "Manchester";

        else if(locateClick(e,508,528,524,544))
            return "Hull";

        else if(locateClick(e,218,238,605,625))
            return "Carmarthen";

        else if(locateClick(e,297,317,596,616))
            return "Llandrindod Wells";

        else if(locateClick(e,381,401,608,628))
            return "Birmingham";

        else if(locateClick(e,436,456,580,600))
            return "Nottingham";

        else if(locateClick(e,261,281,645,665))
            return "Cardiff";

        else if(locateClick(e,421,441,653,673))
            return "Northampton";

        else if(locateClick(e,480,500,670,690))
            return "Cambridge";

        else if(locateClick(e,573,593,664,684))
            return "Norwich";

        else if(locateClick(e,80,100,701,721))
            return "Penzance";

        else if(locateClick(e,176,196,712,732))
            return "Plymouth";

        else if(locateClick(e,301,321,682,702))
            return "Bristol";

        else if(locateClick(e,387,407,703,723))
            return "Reading";

        else if(locateClick(e,448,468,723,743))
            return "London";

        else if(locateClick(e,527,547,715,735))
            return "Ipswich";

        else if(locateClick(e,352,372,759,779))
            return "Southampton";

        else if(locateClick(e,419,439,786,806))
            return "Brighton";

        else if(locateClick(e,517,537,787,807))
            return "Dover";

        else if(locateClick(e,303,323,861,881))
            return "West France";

        else if(locateClick(e,591,611,828,848))
            return "East France";
            else if(locateClick(e,19,39,811,831))
                return "New York";
        else             
            return "";
    }

    /**
     * This method returns true if the mouse is clicked
     * at a specific location range and false if not
     * 
     * @param e MouseEvent where the click is located
     * @param startX starting X coordinate of desired range
     * @param endX end X coordinate of desired range
     * @param startY starting Y coordinate of desired range
     * @param endY end Y coordinate of desired range
     * 
     * @return true if mouse is clicked within specific range
     * @return false if mouse is not clicked within specific range
     */
    public boolean locateClick(MouseEvent e, int startX, 
    int endX, int startY, int endY){
        if(e.getX() > startX && e.getX() < endX &&e.getY() 
        > startY && e.getY() < endY)
            return true;
        return false;
    }
}
