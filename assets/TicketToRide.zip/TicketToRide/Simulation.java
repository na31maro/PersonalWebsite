import java.awt.*;
import javax.swing.*;
import java.awt.event.*;
import java.awt.image.*;
import java.applet.*;
import java.util.*;
import java.awt.geom.*;
/////////////////////////////////////////////////////////////////////////////

/**
 * This class will help simulate the gameplay/applet of Ticket To Ride.
 *
 * @author Group 6
 * @version 1.0
 */
public class Simulation extends JApplet implements MouseMotionListener, 
ActionListener {
    //represents those playing current game
    protected Player players[] = new Player[5];
    private Player curPlayer;
    //Debug Player and Fields
    //     private Player James = new Player(1);
    //     protected Player players[] = {James};
    //     private Player curPlayer = James;

    //Board 
    private Board board = new Board();

    //Used to create a custom cursor in paint
    boolean mouseEntered = false;
    Toolkit toolkit = Toolkit.getDefaultToolkit();
    Image image = toolkit.getImage("cursor.png");
    Cursor trainCursor = toolkit.createCustomCursor(image , new Point(getX(), 
                getY()), "img");

    private boolean mouseClickCoords = false;
    //City Click Info
    private String city1 = "";
    private String city2 = "";
    private int cityCount = 0;
    private CityClicks cityClick = new CityClicks();

    //controls showing start menu screen
    private boolean menu = true;
    private boolean hover2 = false;
    private boolean hover3 = false;
    private boolean hover4 = false;
    private boolean rulesHover = false;

    //Main screen button hovers
    private boolean myTechHov = false;
    private boolean myDestHov = false;
    private boolean buyTechHov = false;
    private boolean buyDestHov = false;
    private boolean drawRandoCard = false;
    private boolean trade = false;
    private boolean buyRouteHov = false;

    //Train Card hover buttons
    private boolean playerRedCard = false;
    private boolean playerWhiteCard = false;
    private boolean playerBlackCard = false;
    private boolean playerRainbowCard = false;
    private boolean playerYellowCard = false;
    private boolean playerOrangeCard = false;
    private boolean playerBlueCard = false;
    private boolean playerGreenCard = false;
    private boolean playerPinkCard = false;

    //Visible Card Image Array
    private Image[] visCardsImage = new Image[5];

    //how many cards have been 
    //drawn by the player this turn
    private int drawCount = 0;
    private int blindCount = 0;

    //tells whether the player can buy technology
    private boolean preTurn = true;

    //city hover fields
    private boolean hasCityHover = false;
    DrawString curCityHover;

    private CityHovers citHov = new CityHovers();
    //initiates setup phase
    private boolean setup = true;

    //control cycle of turns
    private int playerIndex = 0;
    private int endGameCounter = -1;
    private boolean closeToEnd = false;

    //initialize objects of classes 
    //that contain data we need to access
    private AdvancedTech advTech = new AdvancedTech();
    private ImageToolkit imLib = new ImageToolkit();

    private TrainDeck trainDeck = new TrainDeck();
    private Destination dest = new Destination();

    //tells whether trade button has been clicked or not
    private boolean isTrade = false;

    //keeps track of train cards players
    //have used excluding extra rainbows
    private ArrayList<String> discards = new ArrayList<String>();

    //keeps track of cards
    //a player has put up
    //to traxde for a rainbow
    private ArrayList<String> trades = new ArrayList<String>();

    String soundfile = "startGame.mp3";
    String soundfile1 = "clicker.wav";
    String soundfile2 = "trading.mp3";
    String soundfile3 = "buyTech.wav";
    String soundfile4 = "buying.wav";
    String soundfile5 = "error.wav";
    //Double Buffering
    Graphics bg; // The graphics for the screen before it is printed 
    Image offscreen; // The image of the screen

    //tells whether deck has been reshuffled yet
    private boolean deckRefilled = false;

    /**
     * Called by the browser or applet viewer to inform this JApplet that it
     * has been loaded into the system. It is always called before the first
     * time that the start method is called.
     */
    public void init() {
        JRootPane rootPane = this.getRootPane();
        rootPane.putClientProperty("defeatSystemEventQueueCheck", 
            Boolean.TRUE);
        addMouseListener(new MouseAdapter() {
                //handle mouse clicks.
                //delegate to other methods

                /**
                 * This method handles a mouse clicked event
                 * and delegates to which method the mouse clicked
                 * event goes to based on what event is currently
                 * being played in the game at the time of 
                 * the mouse click.
                 *
                 * @param e MouseEvent where the player clicks.
                 */
                public void mouseClicked(MouseEvent e) {
                    //Play sound
                    play(getDocumentBase(), soundfile1);
                    if (menu)
                        menuClick(e);
                    else {
                        mainMenuButtons(e);

                        citySelection(e);
                    }
                    if (mouseClickCoords) {
                        showStatus(e.getX() + " " + e.getY());
                    }
                }
            });
        addMouseListener(new MouseAdapter() {
                /**
                 * allows for a custom cursor to be created
                 * whenever the mouse enters the applet window
                 * 
                 * @param e event when mouse enters a component
                 */
                public void mouseEntered(MouseEvent e){
                    mouseEntered = true;
                    repaint();
                }
            });

        addMouseMotionListener(this);
        //         James.setPColor(Color.RED);
        //Double Buffering
        offscreen = createImage(getWidth(), getHeight());//Creating offscreen
        bg = offscreen.getGraphics();
        //         if(!menu){
        //             doSetup();
        //         }
        //display initial menu screen
        // 3 clickable spaces for # of players
    }

    //////////////////////////////////////////////////////////////////////
    //////////////////////////////////////////////////////////////////////
    ////////////////////Mouse Click Methods///////////////////////////////
    //////////////////////////////////////////////////////////////////////
    //////////////////////////////////////////////////////////////////////
    //////////////////////////////////////////////////////////////////////
    //////////////////////////////////////////////////////////////////////
    //////////////////////////////////////////////////////////////////////
    //////////////////////////////////////////////////////////////////////
    //////////////////////////////////////////////////////////////////////
    //////////////////////////////////////////////////////////////////////
    //////////////////////////////////////////////////////////////////////
    //////////////////////////////////////////////////////////////////////
    //////////////////////////////////////////////////////////////////////
    //////////////////////////////////////////////////////////////////////

    /**
     * This method determines which city the player
     * clicks on and keeps track of it and adds it
     * to the global field.
     *
     * @param e MouseEvent where the user clicks on
     *          the gameboard.
     */
    public void citySelection(MouseEvent e) {
        if (cityCount == 0 && !cityClick.checkCityClick(e).equals("")) {
            city1 = cityClick.checkCityClick(e);
            cityCount++;
        } 
        else if (cityCount == 1 && !cityClick.checkCityClick(e).equals("")){
            city2 = cityClick.checkCityClick(e);
            cityCount++;
        } else {
            city1 = "";
            city2 = "";
            cityCount = 0;
        }
        showStatus(city1 + " " + city2);

    }

    /**
     * This method returns the cards to the player who chose
     * them if that player clicks outside the card boxes to cancel
     * the trade (for a locomotive card).
     */
    public void returnCards() {
        for (String s : trades) {
            if (s.equals("red"))
                curPlayer.trainCards[0]++;
            else if (s.equals("blue"))
                curPlayer.trainCards[1]++;
            else if (s.equals("yellow"))
                curPlayer.trainCards[2]++;
            else if (s.equals("green"))
                curPlayer.trainCards[3]++;
            else if (s.equals("orange"))
                curPlayer.trainCards[4]++;
            else if (s.equals("pink"))
                curPlayer.trainCards[5]++;
            else if (s.equals("black"))
                curPlayer.trainCards[6]++;
            else
                curPlayer.trainCards[7]++;
        }
        repaint();
        trades = new ArrayList<String>();
    }

    /**
     * This method undergoes when a player
     * selects one of the main menu buttons, suchs as
     * "My Tech", "Buy Tech", "My Destinations",
     * "Buy Destinations", or wishes to draw a random card,
     * pick one of the visible cards, or trade in 5 train
     * cards for a locomotive.
     *
     * @param e MouseEvent where the user clicks
     */
    public void mainMenuButtons(MouseEvent e) {
        //Main Screen Buttons:
        if (locateClick(e, 787, 1010, 410, 463)) {
            ImageIcon[] techs = myTech();
            JFrame playerTechs = new JFrame();
            playerTechs.add(new techPanel(techs));
            playerTechs.pack();
            playerTechs.setVisible(true);
        }
        if (locateClick(e, 789, 1012, 477, 527)) {
            String[] destsHeld = playerDests();
            JFrame destF = new JFrame();
            destF.add(new destPanel(destsHeld, 175, 215));
            destF.pack();
            destF.setVisible(true);
        }
        if (locateClick(e, 1026, 1250, 410, 463)) {
            if (preTurn) {
                int buyTechs = JOptionPane.showConfirmDialog(null,
                        "Are you sure you want to buy technology? " +
                        "(you must trade for locomotives beforehand)",
                        "Buy technology?", JOptionPane.YES_NO_OPTION);
                if (buyTechs == JOptionPane.YES_OPTION) {
                    if (buyTech())
                        preTurn = false;
                }
            } else
            {
                JOptionPane.showMessageDialog(null, 
                    "Can only buy tech cards at beginning of turn");
                //Play sound
                play(getDocumentBase(), soundfile5);
            }
        }
        if (locateClick(e, 1025, 1248, 475, 527)) {
            if (drawCount == 0) {
                int buyDest = JOptionPane.showConfirmDialog(null, 
                        "Use your turn to draw more Destination Cards?", 
                        "Draw more Destination Cards?",
                        JOptionPane.YES_NO_OPTION);
                if (buyDest == JOptionPane.YES_OPTION) {
                    //Play sound
                    play(getDocumentBase(), soundfile4);
                    addDests();
                    endTurn();
                }
            } else
            {
                JOptionPane.showMessageDialog(null, 
                    "Cannot draw destinations"+
                    " if train card has already been drawn");
                //Play sound
                play(getDocumentBase(), soundfile5);
            }
        }

        //Buy Route Button
        if (locateClick(e, 82, 223, 159, 216)) {
            if (drawCount == 0 &&
            board.addPath(city1, city2, players[playerIndex], discards))
                endTurn();
            repaint();
        }

        //Big Train Card?
        if (locateClick(e, 795, 963, 15, 318)) {
            drawTCard(curPlayer);
            drawCount++;
            blindCount++;
            preTurn = false;
            drawEndTurn();
            repaint();
        }

        //Trade Mode 
        if (isTrade)
            if (isTrade(e)) {
            } else {
                isTrade = false;
                JOptionPane.showMessageDialog(this,
                    "Trade Cancelled", "Trade Message",
                    JOptionPane.INFORMATION_MESSAGE,
                    null);
                //Play sound
                play(getDocumentBase(), soundfile2);
                returnCards();
            }
        if (locateClick(e, 657, 760, 489, 526)) {
            JOptionPane.showMessageDialog(this,
                "Select 4 normal cards to convert" +
                " to a Locomotive",
                "Trade Message",
                JOptionPane.INFORMATION_MESSAGE,
                null);
            isTrade = true;
        }

        //Train Card Buttons:   
        if (locateClick(e, 660, 829, 545, 654)) {
            //debug("Red Train Card Pressed");

        }
        if (locateClick(e, 661, 828, 665, 771)) {
            //debug("White Train Card pressed");

        }
        if (locateClick(e, 658, 828, 787, 893)) {
            //debug("Black Train Card pressed");

        }
        if (locateClick(e, 859, 1030, 542, 651)) {
        }
        //debug("Rainbow Train Card pressed");
        if (locateClick(e, 861, 1030, 665, 771)) {
            //debug("Yellow Train Card pressed");

        }
        if (locateClick(e, 861, 1030, 787, 893)) {
            //debug("Orange Train Card pressed");

        }
        if (locateClick(e, 1077, 1248, 547, 654)) {
            //debug("Blue Train Card pressed");

        }
        if (locateClick(e, 1077, 1248, 665, 771)) {
            //debug("Green Train Card pressed");

        }
        if (locateClick(e, 1077, 1248, 787, 893)) {
            //debug("Pink Train Card pressed");

        }

        //Draw Displayed Card Buttons
        if (locateClick(e, 644, 770, 16, 86)) {
            pickVisCard(0, curPlayer);
            preTurn = false;
            drawEndTurn();
        }
        if (locateClick(e, 644, 770, 87, 157)) {
            pickVisCard(1, curPlayer);
            preTurn = false;
            drawEndTurn();
        }
        if (locateClick(e, 644, 770, 158, 228)) {
            pickVisCard(2, curPlayer);
            preTurn = false;
            drawEndTurn();
        }
        if (locateClick(e, 644, 770, 229, 296)) {
            pickVisCard(3, curPlayer);
            preTurn = false;
            drawEndTurn();
        }
        if (locateClick(e, 644, 770, 297, 490)) {
            pickVisCard(4, curPlayer);
            preTurn = false;
            drawEndTurn();
        }
    }

    /**
     * This method determines if a turn is ended when
     * a player draws cards.
     */
    public void drawEndTurn() {
        if (curPlayer.tech.waterTenders && blindCount == 3)
            endTurn();

        else if (curPlayer.tech.waterTenders && blindCount == 2) {
        } else if (drawCount == 2)
            endTurn();
    }

    /**
     * handles the necessary steps to trade in cards for a locomotive
     *
     * @param e MouseEvent where the user clicks
     * @return false if the trade is unsuccessful
     */
    public boolean isTrade(MouseEvent e) {
        if (locateClick(e, 660, 829, 545, 654)) {
            //debug("Red Train Card Pressed");
            if (isTrade && curPlayer.trainCards[0] > 0) {
                trades.add("red");
                curPlayer.trainCards[0]--;
                if ((curPlayer.tech.booster && trades.size() == 3) ||
                trades.size() == 4) {
                    isTrade = false;
                    for (String s : trades) {
                        discards.add(s);
                    }
                    curPlayer.trainCards[8]++;
                    curPlayer.extraR++;
                    trades = new ArrayList<String>();
                }
                repaint();

                return true;
            }
            return false;
        } else if (locateClick(e, 661, 828, 665, 771)) {
            //debug("White Train Card pressed");
            if (isTrade && curPlayer.trainCards[7] > 0) {
                trades.add("white");
                curPlayer.trainCards[7]--;
                if ((curPlayer.tech.booster && trades.size() == 3) ||
                trades.size() == 4) {
                    isTrade = false;
                    for (String s : trades) {
                        discards.add(s);
                    }
                    curPlayer.trainCards[8]++;

                    curPlayer.extraR++;
                    trades = new ArrayList<String>();
                }
                repaint();
                return true;
            }
            return false;
        } else if (locateClick(e, 658, 828, 787, 893)) {
            //debug("Black Train Card pressed");
            if (isTrade && curPlayer.trainCards[6] > 0) {
                trades.add("black");
                curPlayer.trainCards[6]--;
                if ((curPlayer.tech.booster && trades.size() == 3) ||
                trades.size() == 4) {
                    isTrade = false;
                    for (String s : trades) {
                        discards.add(s);
                    }
                    curPlayer.trainCards[8]++;

                    curPlayer.extraR++;
                    trades = new ArrayList<String>();
                }
                repaint();
                return true;
            }
            return false;
        } else if (locateClick(e, 861, 1030, 665, 771)) {
            //debug("Yellow Train Card pressed");
            if (isTrade && curPlayer.trainCards[2] > 0) {
                trades.add("yellow");
                curPlayer.trainCards[2]--;
                if ((curPlayer.tech.booster && trades.size() == 3) ||
                trades.size() == 4) {
                    isTrade = false;
                    for (String s : trades) {
                        discards.add(s);
                    }
                    curPlayer.trainCards[8]++;

                    curPlayer.extraR++;
                    trades = new ArrayList<String>();
                }
                repaint();
                return true;
            }
            return false;
        } else if (locateClick(e, 861, 1030, 787, 893)) {
            //debug("Orange Train Card pressed");
            if (isTrade && curPlayer.trainCards[4] > 0) {
                trades.add("orange");
                curPlayer.trainCards[4]--;
                if ((curPlayer.tech.booster && trades.size() == 3) ||
                trades.size() == 4) {
                    isTrade = false;
                    for (String s : trades) {
                        discards.add(s);
                    }
                    curPlayer.trainCards[8]++;

                    curPlayer.extraR++;
                    trades = new ArrayList<String>();
                }
                repaint();
                return true;
            }
            return false;
        } else if (locateClick(e, 1077, 1248, 547, 654)) {
            //debug("Blue Train Card pressed");
            if (isTrade && curPlayer.trainCards[1] > 0) {
                trades.add("blue");
                curPlayer.trainCards[1]--;
                if ((curPlayer.tech.booster && trades.size() == 3) ||
                trades.size() == 4) {
                    isTrade = false;
                    for (String s : trades) {
                        discards.add(s);
                    }
                    curPlayer.trainCards[8]++;

                    curPlayer.extraR++;
                    trades = new ArrayList<String>();
                }
                repaint();
                return true;
            }
            return false;
        } else if (locateClick(e, 1077, 1248, 665, 771)) {
            //debug("Green Train Card pressed");
            if (isTrade && curPlayer.trainCards[3] > 0) {
                trades.add("green");
                curPlayer.trainCards[3]--;
                if ((curPlayer.tech.booster && trades.size() == 3) ||
                trades.size() == 4) {
                    isTrade = false;
                    for (String s : trades) {
                        discards.add(s);
                    }
                    curPlayer.trainCards[8]++;

                    curPlayer.extraR++;
                    trades = new ArrayList<String>();
                }
                repaint();
                return true;
            }
            return false;
        } else if (locateClick(e, 1077, 1248, 787, 893)) {
            //debug("Pink Train Card pressed");
            if (isTrade && curPlayer.trainCards[5] > 0) {
                trades.add("pink");
                curPlayer.trainCards[5]--;
                if ((curPlayer.tech.booster && trades.size() == 3) || 
                trades.size() == 4) {
                    isTrade = false;
                    for (String s : trades) {
                        discards.add(s);
                    }
                    curPlayer.trainCards[8]++;

                    curPlayer.extraR++;
                    trades = new ArrayList<String>();
                }
                repaint();
                return true;
            }
            return false;
        } else return false;
    }

    /**
     * This method detemines whether the MouseEvent is
     * within the range of the rectangular boundaries of
     * the paramater.
     *
     * @param e      MouseEvent where the player clicked
     * @param startX coordinate in the rectangle the method
     *               is checking the MouseEvent is in
     * @param endX   coordinate in the rectangle the method
     *               is checking the MouseEvent is in
     * @param startY coordinate in the rectangle the method
     *               is checking the MouseEvent is in
     * @param endY   coordinate in the rectangle the method
     *               is checking the MouseEvent is in
     * @return false if the MouseEvent is not within the
     * rectangular boundary
     */
    public boolean locateClick(MouseEvent e, 
    int startX, int endX, int startY, int endY) {
        if (e.getX() > startX && e.getX() < endX &&
        e.getY() > startY && e.getY() < endY)
            return true;
        return false;
    }

    /**
     * This method detemines how many
     * players are in the game based
     * on the option the player clicked at
     * the startup-menu screen
     *
     * @param e MouseEvent where the user clicks
     */
    public void menuClick(MouseEvent e) {
        if (locateClick(e, 520, 740, 275, 325)) {
            players = new Player[2];
            players[0] = new Player(1);
            players[1] = new Player(2);
            curPlayer = players[0];
            menu = false;
            repaint();
            doSetup();
        } else if (locateClick(e, 520, 740, 425, 475)) {
            players = new Player[3];
            players[0] = new Player(1);
            players[1] = new Player(2);
            players[2] = new Player(3);
            curPlayer = players[0];
            menu = false;
            repaint();
            doSetup();
        } else if (locateClick(e, 520, 740, 575, 625)) {
            players = new Player[4];
            players[0] = new Player(1);
            players[1] = new Player(2);
            players[2] = new Player(3);
            players[3] = new Player(4);
            curPlayer = players[0];
            menu = false;
            repaint();
            doSetup();
        } else if (locateClick(e, 600, 680, 680, 710)) {
            ImageIcon rules = new ImageIcon(imLib.ruleSheet);
            JFrame label1 = new JFrame();
            label1.add(new rulePanel(rules));
            label1.pack();
            label1.setVisible(true);

        }
    }

    /**
     * This method allows a player to use
     * a turn to draw 1-3 more dest cards.
     */
    public void addDests() {
        String dest1 = dest.drawDest();
        String dest2 = dest.drawDest();
        String dest3 = dest.drawDest();
        //destFrame.setVisible(true);
        String[] options = {dest1, dest2, dest3};

        JFrame destF = new JFrame();
        destF.add(new destPanel(options, 225, 300));

        destF.pack();
        destF.setVisible(true);

        while (options.length > 0) {

            String op = (String) JOptionPane.showInputDialog(null,
                    "select the destination card you want from the menu", 
                    "Must pick at least 1",
                    JOptionPane.QUESTION_MESSAGE,
                    null, options, options[0]);
            while (op == null && options.length > 2)
                op = (String) JOptionPane.showInputDialog(null,
                    "select the destination card you want from the menu",
                    "Must pick at least 1",
                    JOptionPane.QUESTION_MESSAGE,
                    null, options, options[0]);
            if (options.length > 0 && op == null) {
                for (String s : options)
                    dest.destinationDeck.add(s);

                destF.setVisible(false);
                break;
            }
            if (op.equals(dest1)) {
                dest.chooseCard(players[playerIndex], dest1);
                String[] nOptions = new String[options.length - 1];
                int nIndex = 0;
                for (int j = 0; j < options.length; j++) {
                    if (options[j].equals(dest1)) {
                    } else {
                        nOptions[nIndex] = options[j];
                        nIndex++;
                    }
                }
                options = nOptions;
            } else if (op.equals(dest2)) {
                dest.chooseCard(players[playerIndex], dest2);
                String[] nOptions = new String[options.length - 1];
                int nIndex = 0;
                for (int j = 0; j < options.length; j++) {
                    if (options[j].equals(dest2)) {
                    } else {
                        nOptions[nIndex] = options[j];
                        nIndex++;
                    }
                }
                options = nOptions;
            } else if (op.equals(dest3)) {
                dest.chooseCard(players[playerIndex], dest3);
                String[] nOptions = new String[options.length - 1];
                int nIndex = 0;
                for (int j = 0; j < options.length; j++) {
                    if (options[j].equals(dest3)) {
                    } else {
                        nOptions[nIndex] = options[j];
                        nIndex++;
                    }
                }
                options = nOptions;
            }
        }

        destF.setVisible(false);
    }

    /**
     * This method is activated when a user clicks
     * on the "My Tech" button and then displays the users
     * currently owned Technology.
     *
     * @return ImageIcon arrayList of Image Icons of
     * the currently owned technologies.
     */
    public ImageIcon[] myTech() {
        ArrayList<ImageIcon> technologies = new ArrayList<ImageIcon>();
        if (curPlayer.tech.boiler)
            technologies.add(new ImageIcon(imLib.boiler.getScaledInstance(175, 
                        100, java.awt.Image.SCALE_SMOOTH)));

        if (curPlayer.tech.booster) {
            technologies.add(new ImageIcon(imLib.booster.getScaledInstance(
                        175, 100, java.awt.Image.SCALE_SMOOTH)));
        }
        if (curPlayer.tech.dieselPower) {
            technologies.add(new ImageIcon(imLib.dieselPower.
                    getScaledInstance(175,100, java.awt.Image.SCALE_SMOOTH)));
        }
        if (curPlayer.tech.doubleHeading) {
            technologies.add(new ImageIcon(imLib.doubeHeading.
                    getScaledInstance(175, 100, java.awt.Image.SCALE_SMOOTH)));
        }
        if (curPlayer.tech.equalising) {
            technologies.add(new ImageIcon(imLib.equalisingBeam.
                    getScaledInstance(175, 100, java.awt.Image.SCALE_SMOOTH)));
        }
        if (curPlayer.tech.irelandFranceCon) {
            technologies.add(new ImageIcon(imLib.ireland_FranceCon.
                    getScaledInstance(175, 100, java.awt.Image.SCALE_SMOOTH)));
        }
        if (curPlayer.tech.mechanicalStoker) {
            technologies.add(new ImageIcon(imLib.mechanicalStoker.
                    getScaledInstance(175, 100, java.awt.Image.SCALE_SMOOTH)));
        }
        if (curPlayer.tech.propellers) {
            technologies.add(new ImageIcon(imLib.propellers.
                    getScaledInstance(175, 100, java.awt.Image.SCALE_SMOOTH)));
        }
        if (curPlayer.tech.rightOfWay) {
            technologies.add(new ImageIcon(imLib.rightOfWay.
                    getScaledInstance(175, 100, java.awt.Image.SCALE_SMOOTH)));
        }
        if (curPlayer.tech.riskyContracts) {
            technologies.add(new ImageIcon(imLib.riskyContracts.
                    getScaledInstance(175, 100, java.awt.Image.SCALE_SMOOTH)));
        }
        if (curPlayer.tech.ScotlandCon) {
            technologies.add(new ImageIcon(imLib.scotlandConcession.
                    getScaledInstance(175, 100, java.awt.Image.SCALE_SMOOTH)));
        }
        if (curPlayer.tech.steamTurbine) {
            technologies.add(new ImageIcon(imLib.steamTurbine.
                    getScaledInstance(175, 100, java.awt.Image.SCALE_SMOOTH)));
        }
        if (curPlayer.tech.superHeated) {
            technologies.add(new ImageIcon(imLib.superheatedSteamBoiler.
                    getScaledInstance(175, 100, java.awt.Image.SCALE_SMOOTH)));
        }
        if (curPlayer.tech.thermoCompressor) {
            technologies.add(new ImageIcon(imLib.thermoCompressor.
                    getScaledInstance(175, 100, java.awt.Image.SCALE_SMOOTH)));
        }
        if (curPlayer.tech.waterTenders) {
            technologies.add(new ImageIcon(imLib.waterTenders.
                    getScaledInstance(175, 100, java.awt.Image.SCALE_SMOOTH)));
        }
        if (curPlayer.tech.walesCon) {
            technologies.add(new ImageIcon(imLib.walesCon.
                    getScaledInstance(175, 100, java.awt.Image.SCALE_SMOOTH)));
        }
        ImageIcon[] finalTechs = new ImageIcon[technologies.size()];
        for (int i = 0; i < technologies.size(); i++) {
            finalTechs[i] = technologies.get(i);
        }
        return finalTechs;
    }

    /**
     * This method returns an array of Strings representing
     * all the src/Destination Cards
     * the current player is holding.
     */
    public String[] playerDests() {
        ArrayList<String> dests = new ArrayList<String>();
        if (dest.aberdeen_glasgow == players[playerIndex].pNum)
            dests.add("aberdeen_glasgow");
        if (dest.aberystwyth_cardiff == players[playerIndex].pNum)
            dests.add("aberystwyth_cardiff");
        if (dest.belfast_dublin == players[playerIndex].pNum)
            dests.add("belfast_dublin");
        if (dest.belfast_manchester == players[playerIndex].pNum)
            dests.add("belfast_manchester");
        if (dest.birmingham_cambridge == players[playerIndex].pNum)
            dests.add("birmingham_cambridge");
        if (dest.birmingham_london == players[playerIndex].pNum)
            dests.add("birmingham_london");
        if (dest.bristol_southampton == players[playerIndex].pNum)
            dests.add("bristol_southampton");
        if (dest.cambridge_london == players[playerIndex].pNum)
            dests.add("cambridge_london");
        if (dest.cardiff_london == players[playerIndex].pNum)
            dests.add("cardiff_london");
        if (dest.cardiff_reading == players[playerIndex].pNum)
            dests.add("cardiff_reading");
        if (dest.cork_leeds == players[playerIndex].pNum)
            dests.add("cork_leeds");
        if (dest.dublin_london == players[playerIndex].pNum)
            dests.add("dublin_london");
        if (dest.dundalk_carlisle == players[playerIndex].pNum)
            dests.add("dundalk_carlisle");
        if (dest.edinburgh_birmingham == players[playerIndex].pNum)
            dests.add("edinburgh_birmingham");
        if (dest.edinburgh_london == players[playerIndex].pNum)
            dests.add("edinburgh_london");

        if (dest.fortwilliam_edinburgh == players[playerIndex].pNum)
            dests.add("fortwilliam_edinburgh");
        if (dest.galway_barrow == players[playerIndex].pNum)
            dests.add("galway_barrow");
        if (dest.galway_dublin == players[playerIndex].pNum)
            dests.add("galway_dublin");
        if (dest.glasgow_france == players[playerIndex].pNum)
            dests.add("glasgow_france");
        if (dest.glasgow_manchester == players[playerIndex].pNum)
            dests.add("glasgow_manchester");
        if (dest.holyhead_cardiff == players[playerIndex].pNum)
            dests.add("holyhead_cardiff");
        if (dest.iverness_belfast == players[playerIndex].pNum)
            dests.add("iverness_belfast");
        if (dest.iverness_leeds == players[playerIndex].pNum)
            dests.add("iverness_leeds");
        if (dest.leeds_france == players[playerIndex].pNum)
            dests.add("leeds_france");
        if (dest.leeds_london == players[playerIndex].pNum)
            dests.add("leeds_london");
        if (dest.leeds_manchester == players[playerIndex].pNum)
            dests.add("leeds_manchester");
        if (dest.limerick_cardiff == players[playerIndex].pNum)
            dests.add("limerick_cardiff");
        if (dest.liverpool_hull == players[playerIndex].pNum)
            dests.add("liverpool_hull");
        if (dest.liverpool_llandrindod == players[playerIndex].pNum)
            dests.add("liverpool_llandrindod");
        if (dest.liverpool_southampton == players[playerIndex].pNum)
            dests.add("liverpool_southampton");

        if (dest.london_brighton == players[playerIndex].pNum)
            dests.add("london_brighton");
        if (dest.london_france == players[playerIndex].pNum)
            dests.add("london_france");
        if (dest.londonderry_birmingham == players[playerIndex].pNum)
            dests.add("londonderry_birmingham");
        if (dest.londonderry_dublin == players[playerIndex].pNum)
            dests.add("londonderry_dublin");
        if (dest.londonderry_stranraer == players[playerIndex].pNum)
            dests.add("londonderry_stranraer");
        if (dest.manchester_london == players[playerIndex].pNum)
            dests.add("manchester_london");
        if (dest.manchester_norwich == players[playerIndex].pNum)
            dests.add("manchester_norwich");
        if (dest.manchester_plymouth == players[playerIndex].pNum)
            dests.add("manchester_plymouth");
        if (dest.newcastle_hull == players[playerIndex].pNum)
            dests.add("newcastle_hull");
        if (dest.newcastle_southampton == players[playerIndex].pNum)
            dests.add("newcastle_southampton");
        if (dest.northampton_dover == players[playerIndex].pNum)
            dests.add("northampton_dover");
        if (dest.norwich_ipswich == players[playerIndex].pNum)
            dests.add("norwich_ipswich");
        if (dest.nottingham_ipswich == players[playerIndex].pNum)
            dests.add("nottingham_ipswich");
        if (dest.penzance_london == players[playerIndex].pNum)
            dests.add("penzance_london");
        if (dest.plymouth_reading == players[playerIndex].pNum)
            dests.add("plymouth_reading");
        if (dest.rosslare_aberystwyth == players[playerIndex].pNum)
            dests.add("rosslare_aberystwyth");

        if (dest.rosslare_carmarthen == players[playerIndex].pNum)
            dests.add("rosslare_carmarthen");
        if (dest.sligo_holyhead == players[playerIndex].pNum)
            dests.add("sligo_holyhead");
        if (dest.southampton_london == players[playerIndex].pNum)
            dests.add("southampton_london");
        if (dest.stornoway_aberdeen == players[playerIndex].pNum)
            dests.add("stornoway_aberdeen");
        if (dest.stornoway_glasgow == players[playerIndex].pNum)
            dests.add("stornoway_glasgow");
        if (dest.stranraer_tullamore == players[playerIndex].pNum)
            dests.add("stranraer_tullamore");
        if (dest.ullapool_dundee == players[playerIndex].pNum)
            dests.add("ullapool_dundee");
        if (dest.wick_dundee == players[playerIndex].pNum)
            dests.add("wick_dundee");
        if (dest.wick_edinburgh == players[playerIndex].pNum)
            dests.add("wick_edinburgh");
        String[] finDests = new String[dests.size()];
        for (int i = dests.size() - 1; i >= 0; i--)
            finDests[i] = dests.remove(i);
        return finDests;
    }

    /**
     * This method is called when a player
     * wishes to buy a Technology card and
     * handles all the necessary steps for buying
     * the technology.
     * 
     * @return whether buying technology was successful or not
     * true if it was, false if not
     */
    public boolean buyTech() {
        //Play sound
        play(getDocumentBase(), soundfile3);
        int tech = techFirstPage();
        if (tech == -1) return false;
        else if (tech == 0 && curPlayer.trainCards[8] > 1 && 
        !curPlayer.tech.boiler) {
            curPlayer.tech.boiler = true;
            curPlayer.trainCards[8] -= 2;
            for (int i = 0; i < 2; i++)
                if (curPlayer.extraR > 0)
                    curPlayer.extraR--;
                else
                    discards.add("rainbow");
            return true;
        } else if (tech == 1 && curPlayer.trainCards[8] > 1 && 
        !curPlayer.tech.booster) {
            curPlayer.tech.booster = true;
            curPlayer.trainCards[8] -= 2;
            for (int i = 0; i < 2; i++)
                if (curPlayer.extraR > 0)
                    curPlayer.extraR--;
                else
                    discards.add("rainbow");
            return true;
        } else if (tech == 2 && curPlayer.trainCards[8] > 2 && 
        advTech.diesel_power > 0 && !curPlayer.tech.dieselPower) {
            advTech.diesel_power--;
            curPlayer.tech.dieselPower = true;
            curPlayer.trainCards[8] -= 3;
            for (int i = 0; i < 3; i++)
                if (curPlayer.extraR > 0)
                    curPlayer.extraR--;
                else
                    discards.add("rainbow");
            return true;
        } else if (tech == 3 && curPlayer.trainCards[8] > 3 && 
        !curPlayer.tech.doubleHeading) {
            curPlayer.tech.doubleHeading = true;
            curPlayer.trainCards[8] -= 4;
            for (int i = 0; i < 4; i++)
                if (curPlayer.extraR > 0)
                    curPlayer.extraR--;
                else
                    discards.add("rainbow");
        } else if (tech == 4 && curPlayer.trainCards[8] > 1 && 
        advTech.equalising_beam > 0 && 
        !curPlayer.tech.equalising && !deckRefilled) {
            advTech.equalising_beam--;
            curPlayer.tech.equalising = true;
            curPlayer.trainCards[8] -= 2;
            for (int i = 0; i < 2; i++)
                if (curPlayer.extraR > 0)
                    curPlayer.extraR--;
                else
                    discards.add("rainbow");
            return true;
        } else if (tech == 5 && curPlayer.trainCards[8] > 0 && 
        !curPlayer.tech.irelandFranceCon) {
            curPlayer.tech.irelandFranceCon = true;
            curPlayer.trainCards[8] -= 1;
            for (int i = 0; i < 1; i++)
                if (curPlayer.extraR > 0)
                    curPlayer.extraR--;
                else
                    discards.add("rainbow");
            return true;
        } else if (tech == 6 && curPlayer.trainCards[8] > 0 && 
        !curPlayer.tech.mechanicalStoker) {
            curPlayer.tech.mechanicalStoker = true;
            curPlayer.trainCards[8] -= 1;
            for (int i = 0; i < 1; i++)
                if (curPlayer.extraR > 0)
                    curPlayer.extraR--;
                else
                    discards.add("rainbow");
            return true;
        } else if (tech == 7 && curPlayer.trainCards[8] > 1 && 
        !curPlayer.tech.propellers) {
            curPlayer.tech.propellers = true;
            curPlayer.trainCards[8] -= 2;
            for (int i = 0; i < 2; i++)
                if (curPlayer.extraR > 0)
                    curPlayer.extraR--;
                else
                    discards.add("rainbow");
            return true;
        } else if (tech == 8 && curPlayer.trainCards[8] > 3 &&
        players.length > 2) {
            curPlayer.tech.rightOfWay = true;
            curPlayer.trainCards[8] -= 4;
            for (int i = 0; i < 4; i++)
                if (curPlayer.extraR > 0)
                    curPlayer.extraR--;
                else
                    discards.add("rainbow");
            return true;
        } else if (tech == 9 && curPlayer.trainCards[8] > 1 && 
        advTech.risky_contracts > 0 && 
        !curPlayer.tech.riskyContracts && !deckRefilled) {
            advTech.risky_contracts--;
            curPlayer.tech.riskyContracts = true;
            curPlayer.trainCards[8] -= 2;
            for (int i = 0; i < 2; i++)
                if (curPlayer.extraR > 0)
                    curPlayer.extraR--;
                else
                    discards.add("rainbow");
            return true;
        } else if (tech == 10 && curPlayer.trainCards[8] > 0 && 
        !curPlayer.tech.ScotlandCon) {
            curPlayer.tech.ScotlandCon = true;
            curPlayer.trainCards[8] -= 1;
            for (int i = 0; i < 1; i++)
                if (curPlayer.extraR > 0)
                    curPlayer.extraR--;
                else
                    discards.add("rainbow");
            return true;
        } else if (tech == 11 && curPlayer.trainCards[8] > 1 && 
        !curPlayer.tech.steamTurbine) {
            curPlayer.tech.steamTurbine = true;
            curPlayer.trainCards[8] -= 2;
            for (int i = 0; i < 2; i++)
                if (curPlayer.extraR > 0)
                    curPlayer.extraR--;
                else
                    discards.add("rainbow");
            return true;
        } else if (tech == 12 && curPlayer.trainCards[8] > 1 && 
        !curPlayer.tech.superHeated) {
            curPlayer.tech.superHeated = true;
            curPlayer.trainCards[8] -= 2;
            for (int i = 0; i < 2; i++)
                if (curPlayer.extraR > 0)
                    curPlayer.extraR--;
                else
                    discards.add("rainbow");
            return true;
        } else if (tech == 13 && curPlayer.trainCards[8] > 0) {
            curPlayer.tech.thermoCompressor = true;
            curPlayer.trainCards[8] -= 1;
            for (int i = 0; i < 1; i++)
                if (curPlayer.extraR > 0)
                    curPlayer.extraR--;
                else
                    discards.add("rainbow");
            return true;
        } else if (tech == 14 && curPlayer.trainCards[8] > 1 && 
        advTech.water_tenders > 0 && !curPlayer.tech.waterTenders) {
            curPlayer.tech.waterTenders = true;
            curPlayer.trainCards[8] -= 2;
            advTech.water_tenders--;
            for (int i = 0; i < 2; i++)
                if (curPlayer.extraR > 0)
                    curPlayer.extraR--;
                else
                    discards.add("rainbow");
            return true;
        } else if (tech == 15 && curPlayer.trainCards[8] > 0 && 
        !curPlayer.tech.walesCon) {
            curPlayer.tech.walesCon = true;
            curPlayer.trainCards[8] -= 1;
            for (int i = 0; i < 1; i++)
                if (curPlayer.extraR > 0)
                    curPlayer.extraR--;
                else
                    discards.add("rainbow");
            return true;
        }
        return false;
    }

    /**
     * This method is called upon when a user
     * presses the button, "Buy Technology" and
     * displays the first page of technology
     * cards a player can choose from.  This method
     * can tell which card is choosen based on
     * whether or not the player has clicked on the button
     * for a cooresponding technology card.
     *
     * @return int the number of the technolgy card pressed.
     */
    public int techFirstPage() {
        ImageIcon im0 = new ImageIcon(imLib.boiler.
                getScaledInstance(175, 100, java.awt.Image.SCALE_SMOOTH));
        ImageIcon im1 = new ImageIcon(imLib.booster.
                getScaledInstance(175, 100, java.awt.Image.SCALE_SMOOTH));
        ImageIcon im2 = new ImageIcon(imLib.dieselPower.
                getScaledInstance(175, 100, java.awt.Image.SCALE_SMOOTH));
        ImageIcon im3 = new ImageIcon(imLib.doubeHeading.
                getScaledInstance(175, 100, java.awt.Image.SCALE_SMOOTH));
        ImageIcon im4 = new ImageIcon(imLib.next.
                getScaledInstance(175, 100, java.awt.Image.SCALE_SMOOTH));
        ImageIcon[] techs1 = {im0, im1, im2, im3, im4};
        int tech = JOptionPane.showOptionDialog(null,
                "", "Which technology will you buy?",
                JOptionPane.DEFAULT_OPTION, JOptionPane.QUESTION_MESSAGE,
                null, techs1, techs1[0]);

        if (tech == 4)
            return techSecondPage();
        else
            return tech;
    }

    /**
     * This method is called upon when a user
     * presses the button, "Buy Technology" and
     * displays the second page of technology
     * cards a player can choose from.  This method
     * can tell which card is choosen based on
     * whether or not the player has clicked on the button
     * for a cooresponding technology card.
     *
     * @return int the number of the technolgy card pressed.
     */
    public int techSecondPage() {
        ImageIcon im5 = new ImageIcon(imLib.prev.
                getScaledInstance(175, 100, java.awt.Image.SCALE_SMOOTH));
        ImageIcon im6 = new ImageIcon(imLib.equalisingBeam.
                getScaledInstance(175, 100, java.awt.Image.SCALE_SMOOTH));
        ImageIcon im7 = new ImageIcon(imLib.ireland_FranceCon.
                getScaledInstance(175, 100, java.awt.Image.SCALE_SMOOTH));
        ImageIcon im8 = new ImageIcon(imLib.mechanicalStoker.
                getScaledInstance(175, 100, java.awt.Image.SCALE_SMOOTH));
        ImageIcon im9 = new ImageIcon(imLib.next.
                getScaledInstance(175, 100, java.awt.Image.SCALE_SMOOTH));
        ImageIcon[] techs2 = {im5, im6, im7, im8, im9};
        int tech = JOptionPane.showOptionDialog(null,
                "", "Which technology will you buy?",
                JOptionPane.DEFAULT_OPTION, JOptionPane.QUESTION_MESSAGE,
                null, techs2, techs2[0]);
        if (tech == -1)
            return tech;
        else if (tech == 0)
            return techFirstPage();
        else if (tech == 4) {
            return techThirdPage();
        } else
            return tech + 3;
    }

    /**
     * This method is called upon when a user
     * presses the button, "Buy Technology" and
     * displays the third page of technology
     * cards a player can choose from.  This method
     * can tell which card is choosen based on
     * whether or not the player has clicked on the button
     * for a cooresponding technology card.
     *
     * @return int the number of the technolgy card pressed.
     */
    public int techThirdPage() {
        ImageIcon im10 = new ImageIcon(imLib.prev.
                getScaledInstance(175, 100, java.awt.Image.SCALE_SMOOTH));
        ImageIcon im11 = new ImageIcon(imLib.propellers.
                getScaledInstance(175, 100, java.awt.Image.SCALE_SMOOTH));
        ImageIcon im12 = new ImageIcon(imLib.rightOfWay.
                getScaledInstance(175, 100, java.awt.Image.SCALE_SMOOTH));
        ImageIcon im13 = new ImageIcon(imLib.riskyContracts.
                getScaledInstance(175, 100, java.awt.Image.SCALE_SMOOTH));
        ImageIcon im14 = new ImageIcon(imLib.next.
                getScaledInstance(175, 100, java.awt.Image.SCALE_SMOOTH));
        ImageIcon[] techs3 = {im10, im11, im12, im13, im14};
        int tech = JOptionPane.showOptionDialog(null,
                "", "Which technology will you buy?",
                JOptionPane.DEFAULT_OPTION, JOptionPane.QUESTION_MESSAGE,
                null, techs3, techs3[0]);
        if (tech == -1) return tech;
        else if (tech == 0)
            return techSecondPage();
        else if (tech == 4) {
            return techForthPage();
        } else
            return tech + 6;
    }

    /**
     * This method is called upon when a user
     * presses the button, "Buy Technology" and
     * displays the fourth page of technology
     * cards a player can choose from.  This method
     * can tell which card is choosen based on
     * whether or not the player has clicked on the button
     * for a cooresponding technology card.
     *
     * @return int the number of the technolgy card pressed.
     */
    public int techForthPage() {
        ImageIcon im15 = new ImageIcon(imLib.prev.
                getScaledInstance(175, 100, java.awt.Image.SCALE_SMOOTH));
        ImageIcon im16 = new ImageIcon(imLib.scotlandConcession.
                getScaledInstance(175, 100, java.awt.Image.SCALE_SMOOTH));
        ImageIcon im17 = new ImageIcon(imLib.steamTurbine.
                getScaledInstance(175, 100, java.awt.Image.SCALE_SMOOTH));
        ImageIcon im18 = new ImageIcon(imLib.superheatedSteamBoiler.
                getScaledInstance(175, 100, java.awt.Image.SCALE_SMOOTH));
        ImageIcon im19 = new ImageIcon(imLib.next.
                getScaledInstance(175, 100, java.awt.Image.SCALE_SMOOTH));
        ImageIcon[] techs4 = {im15, im16, im17, im18, im19};
        int tech = JOptionPane.showOptionDialog(null,
                "", "Which technology will you buy?",
                JOptionPane.DEFAULT_OPTION, JOptionPane.QUESTION_MESSAGE,
                null, techs4, techs4[0]);
        if (tech == -1) return tech;
        else if (tech == 0)
            return techThirdPage();
        else if (tech == 4) {
            return techFifthPage();
        } else
            return tech + 9;
    }

    /**
     * This method is called upon when a user
     * presses the button, "Buy Technology" and
     * displays the fifth page of technology
     * cards a player can choose from.  This method
     * can tell which card is choosen based on
     * whether or not the player has clicked on the button
     * for a cooresponding technology card.
     *
     * @return int the number of the technolgy card pressed.
     */
    public int techFifthPage() {
        ImageIcon im20 = new ImageIcon(imLib.prev.
                getScaledInstance(175, 100, java.awt.Image.SCALE_SMOOTH));
        ImageIcon im21 = new ImageIcon(imLib.thermoCompressor.
                getScaledInstance(175, 100, java.awt.Image.SCALE_SMOOTH));
        ImageIcon im22 = new ImageIcon(imLib.waterTenders.
                getScaledInstance(175, 100, java.awt.Image.SCALE_SMOOTH));
        ImageIcon im23 = new ImageIcon(imLib.walesCon.
                getScaledInstance(175, 100, java.awt.Image.SCALE_SMOOTH));
        ImageIcon im24 = new ImageIcon(imLib.next.
                getScaledInstance(175, 100, java.awt.Image.SCALE_SMOOTH));
        ImageIcon[] techs5 = {im20, im21, im22, im23, im24};
        int tech = JOptionPane.showOptionDialog(null,
                "", "Which technology will you buy?",
                JOptionPane.DEFAULT_OPTION, JOptionPane.QUESTION_MESSAGE,
                null, techs5, techs5[0]);
        if (tech == -1) return tech;
        else if (tech == 0)
            return techForthPage();
        else if (tech == 4) {
            return techFirstPage();
        } else
            return tech + 12;
    }

    /**
     * This method is necessary 
     * to implement the mouseMotionListener interface
     * it is unused
     * 
     * @param e represents all asscoaited data when the mouse is dragged
     */
    public void mouseDragged(MouseEvent e) {
    }

    /**
     * Called by the browser or applet viewer to inform this JApplet that it
     * should start its execution. It is called after the init method and
     * each time the JApplet is revisited in a Web page.
     */
    public void start() {
        repaint();
    }

    /**
     * Called by the browser or applet viewer to inform this JApplet that
     * it should stop its execution. It is called when the Web page that
     * contains this JApplet has been replaced by another page, and also
     * just before the JApplet is to be destroyed.
     */
    public void stop() {
        // provide any code that needs to be run when page
        // is replaced by another page or before JApplet is destroyed 
    }

    //methods that run applet
    //and do the major logic

    /**
     * This method is called when a
     * player has finished their turn.
     */
    public void endTurn() {
        drawCount = 0;
        blindCount = 0;
        preTurn = true;
        curPlayer.tech.rightOfWay = false;
        curPlayer.tech.thermoCompressor = false;
        if (closeToEnd)
            endGameCounter--;
        else if (players[playerIndex].getNumTrainsLeft() < 3) {
            closeToEnd = true;
            endGameCounter = players.length;
        }
        if (closeToEnd && endGameCounter == 0)
            endGame();
        if (playerIndex == players.length - 1)
            playerIndex = 0;
        else
            playerIndex++;
        curPlayer = players[playerIndex];
        repaint();
    }

    /**
     * This method will be called upon when the game
     * has ended, which is when a player runs out of
     * trains.
     */
    public void endGame(){

        // commented out all below
        //probably what was giving issue. 
        //adding/sub points for dest cards

        //The ending Destination calculations are 
        //below and are not working 100% so we've 
        //commented them out

        //         destToPlayer();
        //         for(int j = 0; j<players.length; j++){
        //             for(int i=0; i<players[j].pDestList.size(); i++){         
        //                 if (board.routeChecker(1, players[j].pDestList, i)){
        //                     if (players[j].tech.doubleHeading){
        //                         players[j].addPoints(2);
        //                     }
        //                     players[j].addPoints(
        //                         destToPoints(players[j].pDestList.get(i)));
        //                 }
        //                 else{
        //                     players[j].addPoints(-1*
        //                         destToPoints(players[j].pDestList.get(i)));
        //                 }}}

        int winIndex = -1;
        int maxPoints = -1;
        for(int i = 0; i < players.length; i++){
            if (players[i].points > maxPoints){
                maxPoints = players[i].points;
                winIndex = i+1;
            }
        }
        JOptionPane.showMessageDialog(null, "Player " + winIndex+ " wins!");
        System.exit(0);    

    }

    /**
     * This method will convert the destination structure
     * into an arraylist for each player. 
     * 
     */
    public void destToPlayer(){
        if(dest.aberdeen_glasgow!=0)
            players[dest.aberdeen_glasgow-1].pDestList.add("aberdeen_glasgow");
        if(dest.aberystwyth_cardiff!=0)
            players[dest.aberystwyth_cardiff-1].
            pDestList.add("aberystwyth_cardiff");
        if(dest.belfast_dublin!=0)
            players[dest.belfast_dublin-1].pDestList.add("belfast_dublin");
        if(dest.belfast_manchester!=0)
            players[dest.belfast_manchester-1].
            pDestList.add("belfast_manchester");
        if(dest.birmingham_cambridge!=0)
            players[dest.birmingham_cambridge-1].
            pDestList.add("birmingham_cambridge");
        if(dest.birmingham_london!=0)
            players[dest.birmingham_london-1].
            pDestList.add("birmingham_london");
        if(dest.bristol_southampton!=0)
            players[dest.bristol_southampton-1].
            pDestList.add("bristol_southampton");     
        if(dest.cambridge_london!=0)
            players[dest.cambridge_london-1].pDestList.add("cambridge_london");
        if(dest.cardiff_london!=0)
            players[dest.cardiff_london-1].pDestList.add("cardiff_london");
        if(dest.cardiff_reading!=0)
            players[dest.cardiff_reading-1].pDestList.add("cardiff_reading");
        if(dest.cork_leeds!=0)
            players[dest.cork_leeds-1].pDestList.add("cork_leeds");
        if(dest.dublin_london!=0)
            players[dest.dublin_london-1].pDestList.add("dublin_london");
        if(dest.dundalk_carlisle!=0)
            players[dest.dundalk_carlisle-1].
            pDestList.add("dundalk_carlisle");
        if(dest.edinburgh_birmingham!=0)
            players[dest.edinburgh_birmingham-1].
            pDestList.add("edinburgh_birmingham");
        if(dest.edinburgh_london!=0)
            players[dest.edinburgh_london-1].
            pDestList.add("edinburgh_london");
        if(dest.fortwilliam_edinburgh!=0)
            players[dest.fortwilliam_edinburgh-1].
            pDestList.add("fortwilliam_edinburgh");
        if(dest.galway_barrow!=0)
            players[dest.galway_barrow-1].pDestList.add("galway_barrow");
        if(dest.galway_dublin!=0)
            players[dest.galway_dublin-1].pDestList.add("galway_dublin");
        if(dest.glasgow_france!=0)
            players[dest.glasgow_france-1].pDestList.add("glasgow_france");
        if(dest.glasgow_manchester!=0)
            players[dest.glasgow_manchester-1].
            pDestList.add("glasgow_manchester");
        if(dest.holyhead_cardiff!=0)
            players[dest.holyhead_cardiff-1].pDestList.add("holyhead_cardiff");
        if(dest.iverness_belfast!=0)
            players[dest.iverness_belfast-1].pDestList.add("iverness_belfast");
        if(dest.iverness_leeds!=0)
            players[dest.iverness_leeds-1].pDestList.add("iverness_leeds");
        if(dest.leeds_france!=0)
            players[dest.leeds_france-1].pDestList.add("leeds_france");
        if(dest.leeds_london!=0)
            players[dest.leeds_london-1].pDestList.add("leeds_london");
        if (dest.leeds_manchester!=0)
            players[dest.leeds_manchester-1].pDestList.add("leeds_manchester");
        if (dest.limerick_cardiff!=0)
            players[dest.limerick_cardiff-1].pDestList.add("limerick_cardiff");
        if (dest.liverpool_hull!=0)
            players[dest.liverpool_hull-1].pDestList.add("liverpool_hull");
        if (dest.liverpool_llandrindod!=0)
            players[dest.liverpool_llandrindod-1].
            pDestList.add("liverpool_llandrindod");
        if (dest.liverpool_southampton!=0)
            players[dest.liverpool_southampton-1].
            pDestList.add("liverpool_southampton");
        if (dest.london_brighton!=0) 
            players[dest.london_brighton-1].pDestList.add("london_brighton");
        if (dest.london_france!=0)
            players[dest.london_france-1].pDestList.add("london_france");
        if(dest.londonderry_birmingham!=0)
            players[dest.londonderry_birmingham-1].
            pDestList.add("londonderry_birmingham");
        if (dest.londonderry_dublin!=0)
            players[dest.londonderry_dublin-1].
            pDestList.add("londonderry_dublin"); 
        if (dest.londonderry_stranraer!=0)
            players[dest.londonderry_stranraer-1].
            pDestList.add("londonderry_stranraer");
        if (dest.manchester_london!=0)
            players[dest.manchester_london-1].
            pDestList.add("manchester_london");
        if (dest.manchester_norwich!=0)
            players[dest.manchester_norwich-1].
            pDestList.add("manchester_norwich"); 
        if (dest.manchester_plymouth!=0)
            players[dest.manchester_plymouth-1].
            pDestList.add("manchester_plymouth");
        if (dest.newcastle_hull!=0)
            players[dest.newcastle_hull-1].pDestList.add("newcastle_hull");
        if (dest.newcastle_southampton!=0)
            players[dest.newcastle_southampton-1].
            pDestList.add("newcastle_southampton");
        if (dest.northampton_dover!=0)
            players[dest.northampton_dover-1].
            pDestList.add("northampton_dover");
        if (dest.norwich_ipswich!=0)
            players[dest.norwich_ipswich-1].pDestList.add("norwich_ipswich");   
        if (dest.nottingham_ipswich!=0)
            players[dest.nottingham_ipswich-1].
            pDestList.add("nottingham_ipswich");
        if (dest.penzance_london!=0)
            players[dest.penzance_london-1].pDestList.add("penzance_london");
        if (dest.plymouth_reading!=0)
            players[dest.plymouth_reading-1].pDestList.add("plymouth_reading");
        if (dest.rosslare_aberystwyth!=0)
            players[dest.rosslare_aberystwyth-1].
            pDestList.add("rosslare_aberystwyth");
        if (dest.rosslare_carmarthen!=0)
            players[dest.rosslare_carmarthen-1].
            pDestList.add("rosslare_carmarthen");
        if(dest.sligo_holyhead!=0)
            players[dest.sligo_holyhead-1].pDestList.add("sligo_holyhead");
        if(dest.southampton_london!=0)
            players[dest.southampton_london-1].
            pDestList.add("southampton_london");
        if(dest.stornoway_aberdeen!=0)
            players[dest.stornoway_aberdeen-1].
            pDestList.add("stornoway_aberdeen");
        if(dest.stornoway_glasgow!=0)
            players[dest.stornoway_glasgow-1].
            pDestList.add("stornoway_glasgow");
        if(dest.stranraer_tullamore!=0)
            players[dest.stranraer_tullamore-1].
            pDestList.add("stranraer_tullamore");
        if(dest.ullapool_dundee!=0)
            players[dest.ullapool_dundee-1].
            pDestList.add("ullapool_dundee");
        if(dest.wick_dundee!=0)
            players[dest.wick_dundee-1].pDestList.add("wick_dundee");   
        if(dest.wick_edinburgh!=0)
            players[dest.wick_edinburgh-1].pDestList.add("wick_edinburgh");
    }

    //////////////////////////////////////////////////////////////////////
    //////////////////////////////////////////////////////////////////////
    ////////////////////////Mouse Moved Methods///////////////////////////
    //////////////////////////////////////////////////////////////////////
    //////////////////////////////////////////////////////////////////////
    //////////////////////////////////////////////////////////////////////
    //////////////////////////////////////////////////////////////////////
    //////////////////////////////////////////////////////////////////////
    //////////////////////////////////////////////////////////////////////
    //////////////////////////////////////////////////////////////////////
    //////////////////////////////////////////////////////////////////////
    //////////////////////////////////////////////////////////////////////
    //////////////////////////////////////////////////////////////////////
    //////////////////////////////////////////////////////////////////////
    //////////////////////////////////////////////////////////////////////

    /**
     * This method is used to implement the hovers
     * that take place when the player has the mouse
     * over a certian part of the applet.
     *
     * @param e MouseEvent where the mouse is curently
     *          located
     */
    public void mouseMoved(MouseEvent e) {
        if (menu) {
            menuHover(e);
        }
        //else if (setup){}
        else if (false) {
        } else {

            if (citHov.checkCityHover(e) != null 
            && hasCityHover == false) {
                hasCityHover = true;
                curCityHover = citHov.checkCityHover(e);
                repaint();

            } else if (citHov.checkCityHover(e) == null 
            && hasCityHover == true) {
                hasCityHover = false;
                curCityHover = null;
                repaint();
            }

            mainHover(e);
        }
    }

    /**
     * This method helps with the hovers present
     * on the menu screen
     *
     * @param e MouseEvent where the mouse is currently
     *          located.
     */
    public void menuHover(MouseEvent e) {
        hover2 = locateClick(e, 520, 740, 275, 325);
        hover3 = locateClick(e, 520, 740, 425, 475);
        hover4 = locateClick(e, 520, 740, 575, 625);
        rulesHover = locateClick(e, 600, 680, 680, 710);
        repaint();
    }

    /**
     * This method helps allow the
     * gameboard to have hovers, and buttons,
     * over the buttons (My tech, Buy Tech, etc.)
     * and cards present on the gameboard.
     *
     * @param e MouseEvent where the mouse is
     *          currently located.
     */
    public void mainHover(MouseEvent e) {
        if (locateClick(e, 787, 1010, 410, 463) && myTechHov) {
        } else if (locateClick(e, 787, 1010, 410, 463)) {
            myTechHov = true;
            repaint();
        } else if (myTechHov) {
            myTechHov = false;
            repaint();
        }

        if (locateClick(e, 789, 1012, 477, 527) && myDestHov) {
        } else if (locateClick(e, 789, 1012, 477, 527)) {
            myDestHov = true;
            repaint();
        } else if (myDestHov) {
            myDestHov = false;
            repaint();
        }

        if (locateClick(e, 1026, 1250, 410, 463) && buyTechHov) {
        } else if (locateClick(e, 1026, 1250, 410, 463)) {
            buyTechHov = true;
            repaint();
        } else if (buyTechHov) {
            buyTechHov = false;
            repaint();
        }

        if (locateClick(e, 1025, 1248, 475, 527) && buyDestHov) {
        } else if (locateClick(e, 1025, 1248, 475, 527)) {
            buyDestHov = true;
            repaint();
        } else if (buyDestHov) {
            buyDestHov = false;
            repaint();
        }

        if (locateClick(e, 795, 963, 15, 318) && drawRandoCard) {
        } else if (locateClick(e, 795, 963, 15, 318)) {
            drawRandoCard = true;
            repaint();
        } else if (drawRandoCard) {
            drawRandoCard = false;
            repaint();

        }

        if (locateClick(e, 657, 760, 489, 526) && trade) {
        } else if (locateClick(e, 657, 760, 489, 526)) {
            trade = true;
            repaint();
        } else if (trade) {
            trade = false;
            repaint();

        }

        if (locateClick(e, 82, 223, 159, 216) && buyRouteHov) {
        } else if (locateClick(e, 82, 223, 159, 216)) {
            buyRouteHov = true;
            repaint();
        } else if (buyRouteHov) {
            buyRouteHov = false;
            repaint();

        }

        ////Train Cards Hover and Buttons
        if (locateClick(e, 660, 829, 545, 654) && playerRedCard) {
        } else if (locateClick(e, 660, 829, 545, 654)) {
            playerRedCard = true;
            repaint();
        } else if (playerRedCard) {
            playerRedCard = false;

            repaint();

        }

        if (locateClick(e, 661, 828, 665, 771) && playerWhiteCard) {
        } else if (locateClick(e, 661, 828, 665, 771)) {
            playerWhiteCard = true;
            repaint();
        } else if (playerWhiteCard) {
            playerWhiteCard = false;

            repaint();

        }

        if (locateClick(e, 658, 828, 787, 893) && playerBlackCard) {
        } else if (locateClick(e, 658, 828, 787, 893)) {
            playerBlackCard = true;
            repaint();
        } else if (playerBlackCard) {
            playerBlackCard = false;

            repaint();

        }

        if (locateClick(e, 859, 1030, 542, 651) && playerRainbowCard) {
        } else if (locateClick(e, 859, 1030, 542, 651)) {
            playerRainbowCard = true;
            repaint();
        } else if (playerRainbowCard) {
            playerRainbowCard = false;

            repaint();

        }

        if (locateClick(e, 861, 1030, 665, 771) && playerYellowCard) {
        } else if (locateClick(e, 861, 1030, 665, 771)) {
            playerYellowCard = true;
            repaint();
        } else if (playerYellowCard) {
            playerYellowCard = false;

            repaint();

        }

        if (locateClick(e, 861, 1030, 787, 893) && playerOrangeCard) {
        } else if (locateClick(e, 861, 1030, 787, 893)) {
            playerOrangeCard = true;
            repaint();
        } else if (playerOrangeCard) {
            playerOrangeCard = false;

            repaint();

        }

        if (locateClick(e, 1077, 1248, 547, 654) && playerBlueCard) {
        } else if (locateClick(e, 1077, 1248, 547, 654)) {
            playerBlueCard = true;
            repaint();
        } else if (playerBlueCard) {
            playerBlueCard = false;

            repaint();

        }

        if (locateClick(e, 1077, 1248, 665, 771) && playerGreenCard) {
        } else if (locateClick(e, 1077, 1248, 665, 771)) {
            playerGreenCard = true;
            repaint();
        } else if (playerGreenCard) {
            playerGreenCard = false;
            repaint();

        }

        if (locateClick(e, 1077, 1248, 787, 893) && playerPinkCard) {
        } else if (locateClick(e, 1077, 1248, 787, 893)) {
            playerPinkCard = true;
            repaint();
        } else if (playerPinkCard) {
            playerPinkCard = false;
            repaint();

        }

    }
    //////////////////////////////////////////////////////////////////////
    //////////////////////////////////////////////////////////////////////
    //////////////////////////Paint Methods///////////////////////////////
    //////////////////////////////////////////////////////////////////////
    //////////////////////////////////////////////////////////////////////
    //////////////////////////////////////////////////////////////////////
    //////////////////////////////////////////////////////////////////////
    //////////////////////////////////////////////////////////////////////
    //////////////////////////////////////////////////////////////////////
    //////////////////////////////////////////////////////////////////////
    //////////////////////////////////////////////////////////////////////
    //////////////////////////////////////////////////////////////////////
    //////////////////////////////////////////////////////////////////////
    //////////////////////////////////////////////////////////////////////
    //////////////////////////////////////////////////////////////////////

    /**
     * Paint method for applet.
     *
     * @param g the Graphics object for this applet
     */
    public void paint(Graphics g) {
        //Painting a cursor
        if (mouseEntered) setCursor(trainCursor);

        //super.paint(g);
        if (menu)
            paintMenu(bg);
        else {
            paintStandardUI(bg);
            if (!menu)
                paintCityRoutes(bg);
            paintMainHover(bg);
            if (hasCityHover)
                paintCityHover(bg);
        }

        if (!menu) {

        }
        g.drawImage(offscreen, 0, 0, this);
    }
    ////////////////////////////////////////////////////////////////////////////////
    ////////////////////////////////////////////////////////////////////////////////
    ///////////////////////////////Drawing Routes///////////////////////////////////
    ////////////////////////////////////////////////////////////////////////////////
    ////////////////////////////////////////////////////////////////////////////////
    /**
     * paintCityRoutes paints the lines that represent
     * which routes each player has. The lines will be drawn
     * the color of each player.
     * 
     * @param g the Graphics object for this applet
     */
    public void paintCityRoutes(Graphics g) {
        //Painting a cursor
        if (mouseEntered) setCursor(trainCursor); 

        Graphics2D g2 = (Graphics2D) g;
        for (int i = 0; i < board.numPaths; i++) {
            Board.CityNode.NeighborNode curRoute = 
                board.getNeigh(board.pathList[i][4], board.pathList[i][5]);

            g2.setColor(curRoute.ownedBy.pColor);
            g2.setStroke(new BasicStroke(10));
            //Drawing all the curved routes
            // if(Stornoway to Fort William)
            if((board.pathList[i][0] == 413 && board.pathList[i][2] == 401) 
            ||
            (board.pathList[i][0] == 401 && board.pathList[i][2] == 413 )){ 
                //Play sound
                play(getDocumentBase(), soundfile4);
                g2.draw(new Line2D.Float(board.pathList[i][0], 
                        board.pathList[i][1], 364, 56));
                g2.draw(new Line2D.Float(364, 56, 349, 119));
                g2.draw(new Line2D.Float(349, 119,board.pathList[i][2], 
                        board.pathList[i][3]));
            }
            //if Ullapool to Wick

            else if((board.pathList[i][0] == 449 && board.pathList[i][2] == 574) 
            ||
            (board.pathList[i][0] == 574 && board.pathList[i][2] == 449 )){ 
                //Play sound
                play(getDocumentBase(), soundfile4);
                g2.draw(new Line2D.Float(board.pathList[i][0], 
                        board.pathList[i][1], 496, 70));
                g2.draw(new Line2D.Float(496, 70, 532, 68));
                g2.draw(new Line2D.Float(532, 68,board.pathList[i][2], 
                        board.pathList[i][3]));
            }
            //if Inverness to Aberdeen
            else if((board.pathList[i][0] == 565 && board.pathList[i][2] == 483) 
            ||
            (board.pathList[i][0] == 483 && board.pathList[i][2] == 565 )){ 
                //Play sound
                play(getDocumentBase(), soundfile4);
                g2.draw(new Line2D.Float(board.pathList[i][0], 
                        board.pathList[i][1], 549, 173));
                g2.draw(new Line2D.Float(549, 173, 526, 147));
                g2.draw(new Line2D.Float(179, 608,board.pathList[i][2], 
                        board.pathList[i][3]));
            }
            //if Aberdeen to Edinburgh
            else if((board.pathList[i][0] == 565 && board.pathList[i][2] == 467) 
            ||
            (board.pathList[i][0] == 467 && board.pathList[i][2] == 565 )){ 
                //Play sound
                play(getDocumentBase(), soundfile4);
                g2.draw(new Line2D.Float(board.pathList[i][0], 
                        board.pathList[i][1], 554, 270));
                g2.draw(new Line2D.Float(554, 270, 520, 308));
                g2.draw(new Line2D.Float(520, 308,board.pathList[i][2], 
                        board.pathList[i][3]));
            }
            //if Stranraer to Carlisle 
            else if((board.pathList[i][0] == 430 && board.pathList[i][2] == 335) 
            ||
            (board.pathList[i][0] == 335 && board.pathList[i][2] == 430 )){ 
                //Play sound
                play(getDocumentBase(), soundfile4);
                g2.draw(new Line2D.Float(board.pathList[i][0], 
                        board.pathList[i][1], 349, 376));
                g2.draw(new Line2D.Float(349, 376, 382, 392));
                g2.draw(new Line2D.Float(382, 392,board.pathList[i][2], 
                        board.pathList[i][3]));
            }
            //if Londonderry to Dandalk
            else if((board.pathList[i][0] == 230 && board.pathList[i][2] == 221) 
            ||
            (board.pathList[i][0] == 221 && board.pathList[i][2] == 230 )){ 
                //Play sound
                play(getDocumentBase(), soundfile4);
                g2.draw(new Line2D.Float(board.pathList[i][0], 
                        board.pathList[i][1], 208, 332));
                g2.draw(new Line2D.Float(208, 332,board.pathList[i][2], 
                        board.pathList[i][3]));
            }
            // if Newcastle to Hull
            else if((board.pathList[i][0] == 502 && board.pathList[i][2] == 518) 
            ||
            (board.pathList[i][0] == 518 && board.pathList[i][2] == 502 )){ 
                //Play sound
                play(getDocumentBase(), soundfile4);
                g2.draw(new Line2D.Float(board.pathList[i][0], 
                        board.pathList[i][1], 576, 484));
                g2.draw(new Line2D.Float(576, 484, 572, 449));
                g2.draw(new Line2D.Float(572, 449,board.pathList[i][2], 
                        board.pathList[i][3]));
            }
            //if(Barrow to Leeds )
            else if((board.pathList[i][0] == 145 && board.pathList[i][2] == 228) 
            ||
            (board.pathList[i][0] == 228 && board.pathList[i][2] == 145 )){ 
                //Play sound
                play(getDocumentBase(), soundfile4);
                g2.draw(new Line2D.Float(board.pathList[i][0], 
                        board.pathList[i][1], 436, 453));
                g2.draw(new Line2D.Float(436, 453,board.pathList[i][2], 
                        board.pathList[i][3]));
            }
            //if Howhead to Liverpool
            else if((board.pathList[i][0] == 286 && board.pathList[i][2] == 361) 
            ||
            (board.pathList[i][0] == 361 && board.pathList[i][2] == 286 )){ 
                //Play sound
                play(getDocumentBase(), soundfile4);
                g2.draw(new Line2D.Float(board.pathList[i][0], 
                        board.pathList[i][1], 330, 457));
                g2.draw(new Line2D.Float(330, 457,board.pathList[i][2], 
                        board.pathList[i][3]));
            }
            //if Hull to Norwich
            else if((board.pathList[i][0] == 518 && board.pathList[i][2] == 583) 
            ||
            (board.pathList[i][0] == 583 && board.pathList[i][2] == 518 )){ 
                //Play sound
                play(getDocumentBase(), soundfile4);
                g2.draw(new Line2D.Float(board.pathList[i][0], 
                        board.pathList[i][1], 524, 614));
                g2.draw(new Line2D.Float(524, 614,board.pathList[i][2], 
                        board.pathList[i][3]));
            }
            //if Llandrindod Well to Birmingham
            else if((board.pathList[i][0] == 307 && board.pathList[i][2] == 391) 
            ||
            (board.pathList[i][0] == 391 && board.pathList[i][2] == 307 )){ 
                //Play sound
                play(getDocumentBase(), soundfile4);
                g2.draw(new Line2D.Float(board.pathList[i][0], 
                        board.pathList[i][1], 352, 589));
                g2.draw(new Line2D.Float(352, 589,board.pathList[i][2], 
                        board.pathList[i][3]));
            }
            //if Penzance to Plymouth 
            else if((board.pathList[i][0] == 90 && board.pathList[i][2] == 186) 
            ||
            (board.pathList[i][0] == 186 && board.pathList[i][2] == 90 )){ 
                //Play sound
                play(getDocumentBase(), soundfile4);
                g2.draw(new Line2D.Float(board.pathList[i][0], 
                        board.pathList[i][1], 112, 757));
                g2.draw(new Line2D.Float(112, 757, 148, 758));
                g2.draw(new Line2D.Float(148, 758,board.pathList[i][2], 
                        board.pathList[i][3]));
            }
            //if Rosslare to Carmarthen            
            else if((board.pathList[i][0] == 145 && board.pathList[i][2] == 228) 
            ||
            (board.pathList[i][0] == 228 && board.pathList[i][2] == 145 )){ 
                //Play sound
                play(getDocumentBase(), soundfile4);
                g2.draw(new Line2D.Float(board.pathList[i][0], 
                        board.pathList[i][1], 152, 589));
                g2.draw(new Line2D.Float(152, 589,board.pathList[i][2], 
                        board.pathList[i][3]));
            }
            //If new york to southampton 
            else if((board.pathList[i][0] == 29 && board.pathList[i][2] == 362)
            ||
            (board.pathList[i][0] == 362 && board.pathList[i][2] == 29 )){ 
                //Play sound
                play(getDocumentBase(), soundfile4);
                g2.draw(new Line2D.Float(board.pathList[i][0], 
                        board.pathList[i][1], 199, 837));
                g2.draw(new Line2D.Float(199, 837,board.pathList[i][2], 
                        board.pathList[i][3]));
            }
            else{ //draw a straight line
                //Play sound
                play(getDocumentBase(), soundfile4);
                g2.draw(new Line2D.Float(board.pathList[i][0],
                        board.pathList[i][1],
                        board.pathList[i][2],
                        board.pathList[i][3]));
            }
        }
        g2.setStroke(new BasicStroke(1));
    }

    /**
     * This method paints the initial menu screen
     * with clickable options for the number
     * of players.
     *
     * @param g the Graphics object for this applet
     */
    public void paintMenu(Graphics g) {
        //Painting a cursor
        if (mouseEntered) setCursor(trainCursor);

        g.drawImage(imLib.menuI, 0, 0, getWidth(), getHeight(), this);
        FontMetrics f = g.getFontMetrics();

        if (hover2) {
            f = g.getFontMetrics();
            g.setColor(Color.YELLOW);
            g.drawRect(getWidth() / 2 - f.stringWidth("2 Players") - 70, 
                287, 250, 50);
        } else if (hover3) {
            f = g.getFontMetrics();
            g.setColor(Color.YELLOW);
            g.drawRect(getWidth() / 2 - f.stringWidth("3 Players") - 70, 
                437, 250, 50);
        } else if (hover4) {
            f = g.getFontMetrics();
            g.setColor(Color.YELLOW);
            g.drawRect(getWidth() / 2 - f.stringWidth("4 Players") - 70, 
                587, 250, 50);
        } else if (hover4) {
            f = g.getFontMetrics();
            g.setColor(Color.YELLOW);
            g.drawRect(getWidth() / 2 - f.stringWidth("4 Players") - 70, 
                587, 250, 50);
        } else if (rulesHover) {
            f = g.getFontMetrics();
            g.setColor(Color.YELLOW);
            g.drawRect(getWidth() / 2 - f.stringWidth("Rules"), 680, 70, 25);
        }
        g.setFont(new Font("Arial", Font.BOLD, 48));
        //Can't have this for some reason. 
        //f = g.getFontMetrics();
        g.setColor(Color.WHITE);

        f = g.getFontMetrics();
        g.drawString("2 Players",
            getWidth() / 2 - f.stringWidth("2 Players") / 2, 325);
        g.drawString("3 Players", 
            getWidth() / 2 - f.stringWidth("3 Players") / 2, 475);
        g.drawString("4 Players", 
            getWidth() / 2 - f.stringWidth("4 Players") / 2, 625);
        g.setFont(new Font("Arial", Font.BOLD, 24));
        f = g.getFontMetrics();
        g.drawString("Rules",
            getWidth() / 2 - f.stringWidth("Rules") / 2, 700);
        g.setFont(new Font("Arial", Font.PLAIN, 12));
        //Play sound
        play(getDocumentBase(), soundfile);
    }

    /**
     * This method allow for Hover graphics to
     * be present when the mouse is over a city
     * and prints out a hovered string of the city
     * name.
     *
     * @param g the Graphics object for this applet.
     */
    public void paintCityHover(Graphics g) {
        //Painting a cursor
        if (mouseEntered) setCursor(trainCursor);

        FontMetrics f = g.getFontMetrics();
        Font hoverFont = new Font("Courier New", Font.BOLD, 18);
        g.setColor(Color.BLACK);
        g.setFont(hoverFont);
        g.drawString(curCityHover.getName(), 
            curCityHover.getX(), curCityHover.getY());
        g.setFont(f.getFont());
    }

    /**
     * This method paints out the normal UI with no pop ups
     * shows map, player cards, etc.
     *
     * @param g th Graphics object for this applet.
     */
    public void paintStandardUI(Graphics g) {
        //Painting a cursor
        if (mouseEntered) setCursor(trainCursor);

        g.drawImage(imLib.background, 0, 0, 1265, 905, this);
        for (int i = 0; i < 5; i++) {
            switch (trainDeck.faceUpTrains[i]) {
                case "black":
                visCardsImage[i] = imLib.blackTrain;
                break;
                case "blue":
                visCardsImage[i] = imLib.blueTrain;
                break;
                case "green":
                visCardsImage[i] = imLib.greenTrain;
                break;
                case "rainbow":
                visCardsImage[i] = imLib.rainbowTrain;
                break;
                case "orange":
                visCardsImage[i] = imLib.orangeTrain;
                break;
                case "pink":
                visCardsImage[i] = imLib.pinkTrain;
                break;
                case "red":
                visCardsImage[i] = imLib.redTrain;
                break;
                case "white":
                visCardsImage[i] = imLib.whiteTrain;
                break;
                case "yellow":
                visCardsImage[i] = imLib.yellowTrain;
                break;
                default:
                visCardsImage[i] = imLib.trainCard;
                break;
            }
        }

        //Paint Visible Cards
        //====================
        g.drawImage(visCardsImage[0], 644, 17, this);
        g.drawImage(visCardsImage[1], 644, 87, this);
        g.drawImage(visCardsImage[2], 644, 157, this);
        g.drawImage(visCardsImage[3], 644, 227, this);
        g.drawImage(visCardsImage[4], 644, 297, this);

        //Player Hand Indicators
        //======================
        g.setColor(Color.GRAY);
        //Red Train Square
        g.fillRect(657, 543, 25, 25);
        //White Train Square
        g.fillRect(657, 664, 25, 25);
        //Black Train Square
        g.fillRect(657, 785, 25, 25);
        //Gold Train Square 
        g.fillRect(857, 543, 25, 25);
        //Yellow Train Square
        g.fillRect(857, 664, 25, 25);
        //Orange Train Square
        g.fillRect(857, 785, 25, 25);
        //Blue Train Square
        g.fillRect(1075, 543, 25, 25);
        //Green Train Square
        g.fillRect(1075, 664, 25, 25);
        //Pink Train Square
        g.fillRect(1075, 785, 25, 25);

        g.setColor(Color.WHITE);
        //Red Count
        g.drawString("" + players[playerIndex].trainCards[0], 665, 558);
        //White Count
        g.drawString("" + players[playerIndex].trainCards[7], 665, 679);
        //Black Count
        g.drawString("" + players[playerIndex].trainCards[6], 665, 802);
        //Gold Count
        g.drawString("" + players[playerIndex].trainCards[8], 865, 558);
        //Yellow Count
        g.drawString("" + players[playerIndex].trainCards[2], 865, 679);
        //Orange Count
        g.drawString("" + players[playerIndex].trainCards[4], 865, 802);
        //Blue Count
        g.drawString("" + players[playerIndex].trainCards[1], 1083, 558);
        //Green Count
        g.drawString("" + players[playerIndex].trainCards[3], 1083, 679);
        //Pink Count
        g.drawString("" + players[playerIndex].trainCards[5], 1083, 802);

        //Player's Turn Indicator by Color
        g.setColor(players[playerIndex].getPColor());
        g.fillOval(971, 348, 50, 50);
        g.setColor(Color.WHITE);
        g.drawString(players[playerIndex].pNum + "", 986, 383);

        //Paint Trains Remaining
        g.setColor(players[playerIndex].getPColor());
        g.drawString("Trains Left: " +
            players[playerIndex].numTrainsLeft, 1162, 123);
        //Score Menu       
        for (int i = 0; i < players.length; i++) {
            g.setColor(players[i].pColor);
            g.drawString("Player " + players[i].pNum + ": " +
                players[i].points, 1157, 54 + (i * 10));
        }

    }

    /**
     * This method helps with the hovers
     * over the buttons and cards by drawing
     * the yellow rectangles around each button
     * or card when the mouse is currently over
     * the respective card/button.
     *
     * @param g the Graphics object for the applet.
     */
    public void paintMainHover(Graphics g) {
        //Painting a cursor
        if (mouseEntered) setCursor(trainCursor);

        g.setColor(Color.YELLOW);
        if (myTechHov)
            g.drawRect(782, 405, 235, 63);
        if (myDestHov)
            g.drawRect(784, 472, 235, 63);
        if (buyTechHov)
            g.drawRect(1021, 405, 235, 63);
        if (buyDestHov)
            g.drawRect(1020, 470, 235, 63);
        if (drawRandoCard)
            g.drawRect(792, 12, 173, 307);
        if (trade)
            g.drawRect(657, 489, 103, 40);
        if (buyRouteHov)
            g.drawRect(82, 159, 144, 59);

        //Train Cards
        if (playerRedCard)
            g.drawRect(655, 540, 180, 118);
        if (playerWhiteCard)
            g.drawRect(656, 660, 180, 118);
        if (playerBlackCard)
            g.drawRect(653, 782, 180, 118);
        if (playerRainbowCard)
            g.drawRect(854, 537, 180, 118);
        if (playerYellowCard)
            g.drawRect(856, 660, 180, 118);
        if (playerOrangeCard)
            g.drawRect(856, 782, 180, 118);
        if (playerBlueCard)
            g.drawRect(1072, 542, 180, 118);
        if (playerGreenCard)
            g.drawRect(1072, 660, 180, 118);
        if (playerPinkCard)
            g.drawRect(1072, 782, 180, 118);

    }
    //////////////////////////////////////////////////////////////////////
    //////////////////////////////////////////////////////////////////////
    //////////////////////////Game Logic//////////////////////////////////
    //////////////////////////////////////////////////////////////////////
    //////////////////////////////////////////////////////////////////////
    //////////////////////////////////////////////////////////////////////
    //////////////////////////////////////////////////////////////////////
    //////////////////////////////////////////////////////////////////////
    //////////////////////////////////////////////////////////////////////
    //////////////////////////////////////////////////////////////////////
    //////////////////////////////////////////////////////////////////////
    //////////////////////////////////////////////////////////////////////
    //////////////////////////////////////////////////////////////////////
    //////////////////////////////////////////////////////////////////////
    //////////////////////////////////////////////////////////////////////

    /**
     * This method deals with the initial
     * setup of the game, selecting the number of players,
     * their colors, etc.  It also calls upon another
     * method that allows each player to choose their destination
     * cards.
     */
    public void doSetup() {
        JFrame chooseColor = new JFrame("Choose your color");
        Object[] possibilities = {"red", "blue", "yellow", "green", "black"};
        ImageIcon im = new ImageIcon();
        for (int i = 0; i < players.length; i++) {
            int p = i + 1;
            String s = (String) JOptionPane.showInputDialog(chooseColor, 
                    "Player " + p +
                    " choose a color", "Choose a color", 
                    JOptionPane.PLAIN_MESSAGE, im, possibilities, "red");
            while (s == null)
                s = (String) JOptionPane.showInputDialog(chooseColor,
                    "Player " + p + " choose a color", "Choose a color",
                    JOptionPane.PLAIN_MESSAGE, im, possibilities, "red");
            if (s.equals("red")) {
                players[i].pColor = Color.RED;
                Object[] nPossibilities = new Object[5 - (i + 1)];
                int nIndex = 0;
                for (int j = 0; j < possibilities.length; j++) {
                    if (((String) possibilities[j]).equals("red")) {
                    } else {
                        nPossibilities[nIndex] = possibilities[j];
                        nIndex++;
                    }
                }
                possibilities = nPossibilities;
            } else if (s.equals("blue")) {
                players[i].pColor = Color.BLUE;
                Object[] nPossibilities = new Object[5 - (i + 1)];
                int nIndex = 0;
                for (int j = 0; j < possibilities.length; j++) {
                    if (((String) possibilities[j]).equals("blue")) {

                    } else {
                        nPossibilities[nIndex] = possibilities[j];
                        nIndex++;
                    }
                }
                possibilities = nPossibilities;
            } else if (s.equals("black")) {
                players[i].pColor = Color.BLACK;
                Object[] nPossibilities = new Object[5 - (i + 1)];
                int nIndex = 0;
                for (int j = 0; j < possibilities.length; j++) {
                    if (((String) possibilities[j]).equals("black")) {

                    } else {
                        nPossibilities[nIndex] = possibilities[j];
                        nIndex++;
                    }
                }
                possibilities = nPossibilities;
            } else if (s.equals("yellow")) {
                players[i].pColor = Color.YELLOW;
                Object[] nPossibilities = new Object[5 - (i + 1)];
                int nIndex = 0;
                for (int j = 0; j < possibilities.length; j++) {
                    if (((String) possibilities[j]).equals("yellow")) {

                    } else {
                        nPossibilities[nIndex] = possibilities[j];
                        nIndex++;
                    }
                }
                possibilities = nPossibilities;
            } else if (s.equals("green")) {
                players[i].pColor = Color.GREEN;
                Object[] nPossibilities = new Object[5 - (i + 1)];
                int nIndex = 0;
                for (int j = 0; j < possibilities.length; j++) {
                    if (((String) possibilities[j]).equals("green")) {

                    } else {
                        nPossibilities[nIndex] = possibilities[j];
                        nIndex++;
                    }
                }
                possibilities = nPossibilities;
            }
        }
        for (int i = 0; i < players.length; i++) {
            for (int j = 0; j < 4; j++) {
                drawTCard(players[i]);
            }
        }
        for (int i = 0; i < players.length; i++) {
            players[i].trainCards[8] += 1;
            trainDeck.removeRainbow();
        }
        //Play sound
        play(getDocumentBase(), soundfile);
        chooseDests();
        setup = false;
    }

    /**
     * obligatory method for implementing the actionlistener interface
     * unused
     * @param e represents the action performed- clicking button, etc
     */
    public void actionPerformed(ActionEvent e) {

    }

    /**
     * This method takes in an int number
     * that cooresponds to a respective trian
     * card that allows for a player to receive
     * that train card.
     *
     * @param card number that cooresponds to a
     *             specific train card.
     * @return Image the image of the Train Card
     */
    public Image getTCard(int card) {
        if (card == 0)
            return imLib.redTrain;
        else if (card == 1)
            return imLib.blueTrain;
        else if (card == 2)
            return imLib.yellowTrain;
        else if (card == 3)
            return imLib.greenTrain;
        else if (card == 4)
            return imLib.orangeTrain;
        else if (card == 5)
            return imLib.pinkTrain;
        else if (card == 6)
            return imLib.blackTrain;
        else if (card == 7)
            return imLib.whiteTrain;
        else
            return imLib.rainbowTrain;
    }

    /**
     * This method takes in a String
     * that cooresponds to a respective trian
     * card that allows for a player to receive
     * that train card.
     *
     * @param s String that cooresponds to a
     *          specific train card.
     * @return Image the image of the train Card
     */
    public Image getTCard(String s) {
        if (s.equals("red"))
            return imLib.redTrain;
        else if (s.equals("blue"))
            return imLib.blueTrain;
        else if (s.equals("yellow"))
            return imLib.yellowTrain;
        else if (s.equals("green"))
            return imLib.greenTrain;
        else if (s.equals("orange"))
            return imLib.orangeTrain;
        else if (s.equals("pink"))
            return imLib.pinkTrain;
        else if (s.equals("black"))
            return imLib.blackTrain;
        else if (s.equals("white"))
            return imLib.whiteTrain;
        else
            return imLib.rainbowTrain;
    }

    /**
     * This method makes it possible for a player
     * to choose the Destinations.  This is done
     * during the setup of the game and when
     * a player wishes to draw more during
     * gameplay.
     */
    public void chooseDests() {
        for (int i = 0; i < players.length; i++) {
            String dest1 = dest.drawDest();
            String dest2 = dest.drawDest();
            String dest3 = dest.drawDest();
            String dest4 = dest.drawDest();
            String dest5 = dest.drawDest();

            //destFrame.setVisible(true);
            String[] options = {dest1, dest2, dest3, dest4, dest5};

            JFrame destF = new JFrame();
            destF.add(new destPanel(options, 225, 300));

            destF.pack();
            destF.setVisible(true);

            while (options.length > 0) {

                String op = (String) JOptionPane.showInputDialog(null,
                        "select the destination card you want from the menu", 
                        "Must pick at least 3",
                        JOptionPane.QUESTION_MESSAGE,
                        null, options, options[0]);
                //Play sound
                play(getDocumentBase(), soundfile4);
                while (op == null && options.length > 2)
                    op = (String) JOptionPane.showInputDialog(null,
                        "select the destination card you want " +
                        "from the menu", "Must pick at least 3",
                        JOptionPane.QUESTION_MESSAGE,
                        null, options, options[0]);
                if (options.length > 0 && op == null) {
                    for (String s : options)
                        dest.destinationDeck.add(s);

                    destF.setVisible(false);
                    break;
                }
                if (op.equals(dest1)) {
                    dest.chooseCard(players[i], dest1);
                    String[] nOptions = new String[options.length - 1];
                    int nIndex = 0;
                    for (int j = 0; j < options.length; j++) {
                        if (options[j].equals(dest1)) {
                        } else {
                            nOptions[nIndex] = options[j];
                            nIndex++;
                        }
                    }
                    options = nOptions;
                } else if (op.equals(dest2)) {
                    dest.chooseCard(players[i], dest2);
                    String[] nOptions = new String[options.length - 1];
                    int nIndex = 0;
                    for (int j = 0; j < options.length; j++) {
                        if (options[j].equals(dest2)) {
                        } else {
                            nOptions[nIndex] = options[j];
                            nIndex++;
                        }
                    }
                    options = nOptions;
                } else if (op.equals(dest3)) {
                    dest.chooseCard(players[i], dest3);
                    String[] nOptions = new String[options.length - 1];
                    int nIndex = 0;
                    for (int j = 0; j < options.length; j++) {
                        if (options[j].equals(dest3)) {
                        } else {
                            nOptions[nIndex] = options[j];
                            nIndex++;
                        }
                    }
                    options = nOptions;
                } else if (op.equals(dest4)) {
                    dest.chooseCard(players[i], dest4);
                    String[] nOptions = new String[options.length - 1];
                    int nIndex = 0;
                    for (int j = 0; j < options.length; j++) {
                        if (options[j].equals(dest4)) {
                        } else {
                            nOptions[nIndex] = options[j];
                            nIndex++;
                        }
                    }
                    options = nOptions;
                } else if (op.equals(dest5)) {
                    dest.chooseCard(players[i], dest5);
                    String[] nOptions = new String[options.length - 1];
                    int nIndex = 0;
                    for (int j = 0; j < options.length; j++) {
                        if (options[j].equals(dest5)) {
                        } else {
                            nOptions[nIndex] = options[j];
                            nIndex++;
                        }
                    }
                    options = nOptions;
                }
            }

            destF.setVisible(false);
        }
    }

    /**
     * This method returns an image of
     * the respective Destination Card
     * to better display it in the applet.
     *
     * @param card String of the title of the
     *             destination card that the method
     *             will return
     * @return Image the image of the destination
     * card.
     */
    public Image getDCard(String card) {
        if (card.equals("aberdeen_glasgow"))
            return imLib.aberdeen_glasgow;
        else if (card.equals("aberystwyth_cardiff"))
            return imLib.aberystwyth_cardiff;
        else if (card.equals("belfast_dublin"))
            return imLib.belfast_dublin;
        else if (card.equals("belfast_manchester"))
            return imLib.belfast_manchester;
        else if (card.equals("birmingham_cambridge"))
            return imLib.birmingham_cambridge;
        else if (card.equals("birmingham_london"))
            return imLib.birmingham_london;
        else if (card.equals("bristol_southampton"))
            return imLib.bristol_southampton;
        else if (card.equals("cambridge_london"))
            return imLib.cambridge_london;
        else if (card.equals("cardiff_london"))
            return imLib.cardiff_london;
        else if (card.equals("cardiff_reading"))
            return imLib.cardiff_reading;
        else if (card.equals("cork_leeds"))
            return imLib.cork_leeds;
        else if (card.equals("dublin_london"))
            return imLib.dublin_london;
        else if (card.equals("dundalk_carlisle"))
            return imLib.dundalk_carlisle;
        else if (card.equals("edinburgh_birmingham"))
            return imLib.edinburgh_birmingham;
        else if (card.equals("edinburgh_london"))
            return imLib.edinburgh_london;

        else if (card.equals("fortwilliam_edinburgh"))
            return imLib.fortwilliam_edinburgh;
        else if (card.equals("galway_barrow"))
            return imLib.galway_barrow;
        else if (card.equals("galway_dublin"))
            return imLib.galway_dublin;
        else if (card.equals("glasgow_france"))
            return imLib.glasgow_france;
        else if (card.equals("glasgow_manchester"))
            return imLib.glasgow_manchester;
        else if (card.equals("holyhead_cardiff"))
            return imLib.holyhead_cardiff;
        else if (card.equals("iverness_belfast"))
            return imLib.iverness_belfast;
        else if (card.equals("iverness_leeds"))
            return imLib.iverness_leeds;
        else if (card.equals("leeds_france"))
            return imLib.leeds_france;
        else if (card.equals("leeds_london"))
            return imLib.leeds_london;
        else if (card.equals("leeds_manchester"))
            return imLib.leeds_manchester;
        else if (card.equals("limerick_cardiff"))
            return imLib.limerick_cardiff;
        else if (card.equals("liverpool_hull"))
            return imLib.liverpool_hull;
        else if (card.equals("liverpool_llandrindod"))
            return imLib.liverpool_llandrindod;
        else if (card.equals("liverpool_southampton"))
            return imLib.liverpool_southampton;

        else if (card.equals("london_france"))
            return imLib.london_france;
        else if (card.equals("londonderry_birmingham"))
            return imLib.londonderry_birmingham;
        else if (card.equals("londonderry_dublin"))
            return imLib.londonderry_dublin;
        else if (card.equals("londonderry_stranraer"))
            return imLib.londonderry_stranraer;
        else if (card.equals("manchester_london"))
            return imLib.manchester_london;
        else if (card.equals("manchester_norwich"))
            return imLib.manchester_norwich;
        else if (card.equals("manchester_plymouth"))
            return imLib.manchester_plymouth;
        else if (card.equals("newcastle_hull"))
            return imLib.newcastle_hull;
        else if (card.equals("newcastle_southampton"))
            return imLib.newcastle_southampton;
        else if (card.equals("northampton_dover"))
            return imLib.northampton_dover;
        else if (card.equals("norwich_ipswich"))
            return imLib.norwich_ipswich;
        else if (card.equals("nottingham_ipswich"))
            return imLib.nottingham_ipswich;
        else if (card.equals("penzance_london"))
            return imLib.penzance_london;
        else if (card.equals("plymouth_reading"))
            return imLib.plymouth_reading;
        else if (card.equals("rosslare_aberystwyth"))
            return imLib.rosslare_aberystwyth;

        else if (card.equals("rosslare_carmarthen"))
            return imLib.rosslare_carmarthen;
        else if (card.equals("sligo_holyhead"))
            return imLib.sligo_holyhead;
        else if (card.equals("southampton_london"))
            return imLib.southampton_london;
        else if (card.equals("stornoway_aberdeen"))
            return imLib.stornoway_aberdeen;
        else if (card.equals("stornoway_glasgow"))
            return imLib.stornoway_glasgow;
        else if (card.equals("stranraer_tullamore"))
            return imLib.stranraer_tullamore;
        else if (card.equals("ullapool_dundee"))
            return imLib.ullapool_dundee;
        else if (card.equals("wick_dundee"))
            return imLib.wick_dundee;
        else
            return imLib.wick_edinburgh;
    }

    /**
     * This method is called upon
     * to refill the deck of Train
     * Cards when it is empty and drawn from
     */
    public void refillDeck() {
        for (String s : discards)
            trainDeck.deck.add(s);
        Collections.shuffle(trainDeck.deck);
        deckRefilled = true;
    }

    /**
     * This method allows for a player to draw
     * a Train Card.
     *
     * @param p the player that is drawing the card.
     */
    public void drawTCard(Player p) {
        if (trainDeck.deck.size() == 0)
            refillDeck();
        String s = trainDeck.drawTrainCard();

        if (!setup) {
            ImageIcon icon = new ImageIcon(getTCard(s));
            int playerNum = playerIndex + 1;
            JOptionPane.showMessageDialog(null, "", 
                "Player " + playerNum + " Draw",
                JOptionPane.PLAIN_MESSAGE, icon);
        }

        if (s.equals("red"))
            p.trainCards[0] += 1;
        else if (s.equals("blue"))
            p.trainCards[1] += 1;
        else if (s.equals("yellow"))
            p.trainCards[2] += 1;
        else if (s.equals("green"))
            p.trainCards[3] += 1;
        else if (s.equals("orange"))
            p.trainCards[4] += 1;
        else if (s.equals("pink"))
            p.trainCards[5] += 1;
        else if (s.equals("black"))
            p.trainCards[6] += 1;
        else if (s.equals("white"))
            p.trainCards[7] += 1;
        else if (s.equals("rainbow"))
            p.trainCards[8] += 1;

    }
    //////////////////////////////////////////////////////////////////////
    //////////////////////////////////////////////////////////////////////
    //////////////////////////Temp Place///////////////////////////////
    //////////////////////////////////////////////////////////////////////
    //////////////////////////////////////////////////////////////////////
    //////////////////////////////////////////////////////////////////////
    //////////////////////////////////////////////////////////////////////
    //////////////////////////////////////////////////////////////////////
    //////////////////////////////////////////////////////////////////////
    //////////////////////////////////////////////////////////////////////
    //////////////////////////////////////////////////////////////////////
    //////////////////////////////////////////////////////////////////////
    //////////////////////////////////////////////////////////////////////
    //////////////////////////////////////////////////////////////////////
    //////////////////////////////////////////////////////////////////////

    /**
     * This method alters the current player's hand to add
     * the faceup card they selected. It will also will replace the card
     * that was selected with a new one.
     *
     * @param p     the current player
     * @param index the specific card number that is
     *              face up (visible) and to be selected.
     */
    public void pickVisCard(int index, Player p) {
        if (trainDeck.faceUpTrains[index].equals("red")) {
            if (drawCount < 2) {
                p.trainCards[0] += 1;
                drawCount++;

                if (trainDeck.deck.size() == 0)
                    refillDeck();
                trainDeck.faceUpTrains[index] = trainDeck.drawTrainCard();
            }
        } else if (trainDeck.faceUpTrains[index].equals("blue") 
        && drawCount < 2) {
            p.trainCards[1] += 1;
            drawCount++;

            if (trainDeck.deck.size() == 0)
                refillDeck();
            trainDeck.faceUpTrains[index] = trainDeck.drawTrainCard();
        } else if (trainDeck.faceUpTrains[index].equals("yellow") 
        && drawCount < 2) {
            p.trainCards[2] += 1;
            drawCount++;

            if (trainDeck.deck.size() == 0)
                refillDeck();
            trainDeck.faceUpTrains[index] = trainDeck.drawTrainCard();
        } else if (trainDeck.faceUpTrains[index].equals("green") && 
        drawCount < 2) {
            p.trainCards[3] += 1;
            drawCount++;

            if (trainDeck.deck.size() == 0)
                refillDeck();
            trainDeck.faceUpTrains[index] = trainDeck.drawTrainCard();
        } else if (trainDeck.faceUpTrains[index].equals("orange") &&
        drawCount < 2) {
            p.trainCards[4] += 1;
            drawCount++;

            if (trainDeck.deck.size() == 0)
                refillDeck();
            trainDeck.faceUpTrains[index] = trainDeck.drawTrainCard();
        } else if (trainDeck.faceUpTrains[index].equals("pink") && 
        drawCount < 2) {
            p.trainCards[5] += 1;
            drawCount++;

            if (trainDeck.deck.size() == 0)
                refillDeck();
            trainDeck.faceUpTrains[index] = trainDeck.drawTrainCard();
        } else if (trainDeck.faceUpTrains[index].equals("black") && 
        drawCount < 2) {
            p.trainCards[6] += 1;
            drawCount++;

            if (trainDeck.deck.size() == 0)
                refillDeck();
            trainDeck.faceUpTrains[index] = trainDeck.drawTrainCard();
        } else if (trainDeck.faceUpTrains[index].equals("white") && 
        drawCount < 2) {
            p.trainCards[7] += 1;
            drawCount++;

            if (trainDeck.deck.size() == 0)
                refillDeck();
            trainDeck.faceUpTrains[index] = trainDeck.drawTrainCard();
        } else if (trainDeck.faceUpTrains[index].equals("rainbow")) {
            if (drawCount == 0) {
                p.trainCards[8] += 1;
                drawCount += 2;

                if (trainDeck.deck.size() == 0)
                    refillDeck();
                trainDeck.faceUpTrains[index] = trainDeck.drawTrainCard();
            }
        }

        repaint();
    }

    /**
     * This method pops a JOptionPane with a the
     * message of a passed in string.
     *
     * @param s any string.
     */
    public void debug(String s) {
        JOptionPane.showMessageDialog(this,
            s, "Inane custom dialog",
            JOptionPane.INFORMATION_MESSAGE,
            null);
    }

    /**
     * this method converts a string representing a destination card
     * to the number of points it gives or takes away when completed
     * or not
     * 
     * @param s the name of the destination card
     * @return the number of points associated with that card
     */
    public int destToPoints(String s){
        int answer = 0;
        switch (s) 
        {
            case "aberdeen_glasgow" : answer = 5;  
            break;

            case "aberystwyth_cardiff" : answer = 2; 
            break;

            //////////////////////  

            case "belfast_dublin" : answer = 4; 
            break;

            case "belfast_manchester" : answer = 9; 
            break;

            case "birmingham_cambridge" : answer = 2; 
            break;

            case "birmingham_london" : answer = 4; 
            break;  

            case "bristol_southampton" : answer = 2; 
            break;

            case "cambridge_london" : answer = 3; 
            break;

            case "cardiff_london" : answer = 8; 
            break;

            case "cardiff_reading" : answer = 4; 
            break;

            case "cork_leeds" : answer = 13; 
            break;

            case "dublin_cork" : answer = 6; 
            break;

            case "dublin_london" : answer = 15; 
            break;

            case "dundalk_carlisle" : answer = 7; 
            break;

            case "edinburgh_birmingham" : answer = 12; 
            break;

            case "edinburgh_london" : answer = 15; 
            break;

            case "fortwilliam_edinburgh" : answer = 3; 
            break;

            case "galway_barrow" : answer = 12; 
            break;

            case "galway_dublin" : answer = 5; 
            break;

            //21    
            case "glasgow_dublin" : answer = 9; 
            break;

            case "glasgow_france" : answer = 19; 
            break;

            case "glasgow_manchester" : answer = 11; 
            break;

            case "holyhead_cardiff" : answer = 4; 
            break;

            case "iverness_belfast" : answer = 10; 
            break;

            case "iverness_leeds" : answer = 13; 
            break;

            case "leeds_france" : answer = 10; 
            break;

            case "leeds_london" : answer = 6; 
            break;

            case "leeds_manchester" : answer = 1; 
            break;

            case "limerick_cardiff" : answer = 12; 
            break;

            //31

            case "liverpool_hull" : answer = 3; 
            break;

            case "liverpool_llandrindod" : answer = 6; 
            break;

            case "liverpool_southampton" : answer = 6; 
            break;

            case "london_brighton" : answer = 3; 
            break;

            case "london_france" : answer = 7; 
            break;

            case "londonderry_birmingham" : answer = 15; 
            break;

            case "londonderry_dublin" : answer = 6; 
            break;

            case "londonderry_stranraer" : answer = 4; 
            break;

            case "manchester_london" : answer = 6; 
            break;

            case "manchester_norwich" : answer = 6; 
            break;

            //41
            case "manchester_plymouth" : answer = 8; 
            break;

            case "newcastle_hull" : answer = 3; 
            break;

            case "newcastle_southampton" : answer = 7; 
            break;

            case "northampton_dover" : answer = 3; 
            break;

            case "norwich_ipswich" : answer = 1; 
            break;

            case "nottingham_ipswich" : answer = 3; 
            break;

            case "penzance_london" : answer = 10; 
            break;

            case "plymouth_reading" : answer = 5; 
            break;

            case "rosslare_aberystwyth" : answer = 4; 
            break;

            case "rosslare_carmarthen" : answer = 6; 
            break;

            //51

            case "sligo_holyhead" : answer = 9; 
            break;

            case "southampton_london" : answer = 4; 
            break;

            case "stornoway_aberdeen" : answer = 5; 
            break;

            case "stornoway_glasgow" : answer = 7; 
            break;

            case "stranraer_tullamore" : answer = 6; 
            break;

            case "ullapool_dundee" : answer = 4; 
            break;

            case "wick_dundee" : answer = 4; 
            break;

            case "wick_edinburgh" : answer = 5; 
            break;

            default: answer = -1;
            break;

        }// end swit
        return answer;
    }

    /**
     * This class shows the Destination Cards a
     * player can choose from at the start of the game
     * and when a player wishes to purchase more destination
     * cards.
     */
    private class destPanel extends JPanel {
        /**
         * constructor for destpanel objects
         * fills the panel with pictures of destination cards
         * 
         * @param imgs[] array representing destination cards as strings
         * @param x the width we change each image to
         * @param y the height we change each image to
         */
        public destPanel(String[] imgs, int x, int y) {
            ImageIcon[] imgIcons = new ImageIcon[imgs.length];
            for (int i = 0; i < imgs.length; i++) {
                imgIcons[i] = new ImageIcon(getDCard(imgs[i]).
                    getScaledInstance(x, y, java.awt.Image.SCALE_SMOOTH));
            }
            for (ImageIcon i : imgIcons) {
                JLabel label1 = new JLabel(i);
                add(label1);
            }
        }
    }

    /**
     * This class is used when a player wishes to view
     * his or her technology cards by clicking on the
     * "My Technologies" button.
     */
    private class techPanel extends JPanel {
        /**
         * constructor for techpanel objects
         * fills the panel with pictures of technology cards
         * 
         * @param imgs[] array of technology card imageicons
         */
        public techPanel(ImageIcon[] imgs) {
            for (ImageIcon i : imgs) {
                JLabel label1 = new JLabel(i);
                add(label1);
            }
        }
    }

    /**
     * This class will allow the player to view
     * the rules of the game.
     */
    private class rulePanel extends JPanel {
        /**
         * constructor for techpanel objects
         * puts rules image in a panel
         * 
         * @param img the image of the rules sheets
         */
        public rulePanel(ImageIcon img) {
            JLabel label1 = new JLabel(img);
            add(label1, BorderLayout.CENTER);
        }
    }
}
