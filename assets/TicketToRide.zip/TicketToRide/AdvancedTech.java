
/**
 * This class helps keep track
 * of the advanced technology cards.  Those
 * of which that only have a limited number of 
 * cards to be bought.
 * 
 * @author Group 6
 * 
 * @version 1.0
 */
public class AdvancedTech
{
    //Int values that represent
    //how many of the limited
    //tech cards are left to be bought.
    
    protected int water_tenders = 2;
    protected int risky_contracts = 1;
    protected int equalising_beam = 1;
    protected int diesel_power = 1;
}
