import java.util.*;
//////////////////////////////////////////
/**
 * This program will do three things:
 * populate and shuffle a deck
 * draw a random train card from the deck
 * choose five random cards to place as faced up cards
 * 
 * @author Firmin 
 * @version 4/14/16
 */
public class TrainDeck {
    protected ArrayList<String> deck = new ArrayList<String>();
    protected String newCard = "";
    protected String[] faceUpTrains = new String[5];

    /**
     * Constructor for objects of class TrainDeck that initially populates
     * and shuffle the deck, then chooses five radom cards to be placed up 
     */
    public TrainDeck()
    {
        //Initially populate and shuffle the deck
        buildDeck();
        //choose 5 cards to place face up
        for(int k = 0; k < 5; k++)
        {
            faceUpTrains[k] = drawTrainCard();
        }
    }

    /**
     * This method will build a full deck with all 12 of the normal colored 
     * train tickets. It will then add 20 locotmotive (rainbow)
     * train tickets
     * to the deck.
     * 
     */
    public void buildDeck()
    {
        //add 12 train cards to the deck
        for(int i = 0; i < 12; i++)
        {
            deck.add("red");
            deck.add("blue");
            deck.add("black"); 
            deck.add("green");
            deck.add("orange");
            deck.add("pink"); 
            deck.add("white");
            deck.add("yellow");
        }
        //add 20 locomotive (rainbow) cards to the deck
        for(int j = 0; j < 20; j++)
        {
            deck.add("rainbow");
        }

        Collections.shuffle(deck);
    }   

    /**
     * This method will do two things:
     * Handle drawing a single (random) card from the deck
     * Draw one random train ticket from the deck

     * 
     * @return newCard  the color of the card that has been drawn
     */
    public String drawTrainCard()
    {

        newCard = deck.get(0);
        deck.remove(0);
        return newCard;

    }

    /**
     * This method will take in which one of the five faced up cards are
     * picked up by the player. It will then replace that card with a random
     * train card from the deck and remove the previous card.
     * 
     * @param  trainLocation    the card that is picked up
     */
    public void pickVisibleTrain(int trainLocation)
    {
        faceUpTrains[trainLocation] = drawTrainCard();
    }

    
    /**
     * This method removes a locomotive card from
     * the the main deck of train cards.  This method
     * is used to take away the correct number of 
     * locomotive cards from the deck as there are 
     * number of players at the start of the game, in
     * order to correctly take into account that
     * each player gets one locomotive card at the 
     * start of the game.
     */
    public void removeRainbow(){
        deck.remove("rainbow");
        Collections.shuffle(deck);
    }
} 