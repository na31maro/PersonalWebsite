import java.awt.*;
/**
 * This class will store each
 * image of the game into variables
 * for easier access.
 * 
 * @author Nick Marotta
 * @version 4/14/16
 */
public class ImageToolkit 
{
    //Map Image    
    protected Image map;
    
    protected Image menuI;
    
    protected Image background;
    
    protected Image next;
    
    protected Image prev;
    
    protected Image ruleSheet;
    
    protected Image boiler;
    protected Image booster;
    protected Image dieselPower;
    protected Image doubeHeading;
    protected Image equalisingBeam;
    protected Image ireland_FranceCon;
    protected Image mechanicalStoker;
    protected Image propellers;
    protected Image rightOfWay;
    protected Image riskyContracts;
    protected Image scotlandConcession;
    protected Image steamTurbine;
    protected Image superheatedSteamBoiler;
    protected Image thermoCompressor;
    protected Image waterTenders;
    protected Image walesCon;

    //Trains Images
    protected Image blackTrain ;
    protected Image blueTrain ;
    protected Image greenTrain;
    protected Image rainbowTrain;
    protected Image orangeTrain;
    protected Image pinkTrain;
    protected Image redTrain;
    protected Image trainCard;
    protected Image whiteTrain;
    protected Image yellowTrain;

    //Destinations Images
    protected Image aberdeen_glasgow;
    protected Image aberystwyth_cardiff;
    protected Image belfast_dublin;
    protected Image belfast_manchester;
    protected Image birmingham_cambridge;
    protected Image birmingham_london;
    protected Image bristol_southampton;
    protected Image cambridge_london;
    protected Image cardiff_london;
    protected Image cardiff_reading;
    protected Image cork_leeds;
    protected Image dublin_cork;
    protected Image dublin_london;
    protected Image dundalk_carlisle;
    protected Image edinburgh_birmingham;
    protected Image edinburgh_london;

    protected Image fortwilliam_edinburgh;
    protected Image galway_barrow;
    protected Image galway_dublin;
    protected Image glasgow_dublin;
    protected Image glasgow_france;
    protected Image glasgow_manchester;
    protected Image holyhead_cardiff;
    protected Image iverness_belfast;
    protected Image iverness_leeds;
    protected Image leeds_france;
    protected Image leeds_london;
    protected Image leeds_manchester;
    protected Image limerick_cardiff;
    protected Image liverpool_hull;
    protected Image liverpool_llandrindod;
    protected Image liverpool_southampton;

    protected Image london_brighton;
    protected Image london_france;
    protected Image londonderry_birmingham;
    protected Image londonderry_dublin;
    protected Image londonderry_stranraer;
    protected Image manchester_london;
    protected Image manchester_norwich;
    protected Image manchester_plymouth;
    protected Image newcastle_hull;
    protected Image newcastle_southampton;
    protected Image northampton_dover;
    protected Image norwich_ipswich;
    protected Image nottingham_ipswich;
    protected Image penzance_london;
    protected Image plymouth_reading;
    protected Image rosslare_aberystwyth ;

    protected Image rosslare_carmarthen;
    protected Image sligo_holyhead;
    protected Image southampton_london;
    protected Image stornoway_aberdeen;
    protected Image stornoway_glasgow;
    protected Image stranraer_tullamore;
    protected Image ullapool_dundee;
    protected Image wick_dundee;
    protected Image wick_edinburgh;

    protected Image destination_Card;
////////////////////////
    /**
     * Constructor for the ImageToolkit. 
     * Initializes all images for TTR. 
     */
    public ImageToolkit(){
        Toolkit toolkit = Toolkit.getDefaultToolkit();
        //Map
        map = toolkit.getImage("final_map.jpg");

        menuI = toolkit.getImage("cover.jpg");
        
        background = toolkit.getImage("background.jpg");
        
        next =  toolkit.getImage("NextPage.png");
        
        prev = toolkit.getImage("PrevPage.png");
        
        ruleSheet = toolkit.getImage("rulesheet.png");
        
        boiler= toolkit.getImage("technologies/boiler lagging.jpg");
        booster= toolkit.getImage("technologies/booster.jpg");
        dieselPower= toolkit.getImage("technologies/diesel power.jpg");
        doubeHeading= toolkit.getImage("technologies/double heading.jpg");
        equalisingBeam= toolkit.getImage("technologies/equalising beam.jpg");
        ireland_FranceCon = 
        toolkit.getImage("technologies/ireland_France concession.jpg");
        mechanicalStoker = 
        toolkit.getImage("technologies/mechanical stoker.jpg");
        propellers= toolkit.getImage("technologies/propellers.jpg");
        rightOfWay= toolkit.getImage("technologies/right of way.jpg");
        riskyContracts= toolkit.getImage("technologies/risky contracts.jpg");
        scotlandConcession=
        toolkit.getImage("technologies/scotland concession.jpg");
        steamTurbine= toolkit.getImage("technologies/steam turbine.jpg");
        superheatedSteamBoiler=
        toolkit.getImage("technologies/superheated steam boiler.jpg");
        thermoCompressor= 
        toolkit.getImage("technologies/thermo compressor.jpg");
        waterTenders= toolkit.getImage("technologies/water tenders.jpg");
        walesCon = 
        toolkit.getImage("technologies/wales concession.jpg");
        //Trains Images
        blackTrain= toolkit.getImage("Train cards/black train.jpg");
        blueTrain= toolkit.getImage("Train cards/blue train.jpg");
        greenTrain= toolkit.getImage("Train cards/green train.jpg");
        rainbowTrain= toolkit.getImage("Train cards/locamotive.jpg");
        orangeTrain= toolkit.getImage("Train cards/orange train.jpg");
        pinkTrain= toolkit.getImage("Train cards/pinktrain.jpg");
        redTrain= toolkit.getImage("Train cards/red train.jpg");
        trainCard= toolkit.getImage("Train cards/train card.jpg");
        whiteTrain= toolkit.getImage("Train cards/white train.jpg");
        yellowTrain= toolkit.getImage("Train cards/yellow train.jpg");

        //Destinations Images
        aberdeen_glasgow= 
        toolkit.getImage("Destination Cards/aberdeen_glasgow.jpg");
        aberystwyth_cardiff= 
        toolkit.getImage("Destination Cards/aberystwyth_cardiff.jpg");
        belfast_dublin= 
        toolkit.getImage("Destination Cards/belfast_dublin.jpg");
        belfast_manchester= 
        toolkit.getImage("Destination Cards/belfast_manchester.jpg");
        birmingham_cambridge= 
        toolkit.getImage("Destination Cards/birmingham_cambridge.jpg");
        birmingham_london= 
        toolkit.getImage("Destination Cards/birmingham_london.jpg");
        bristol_southampton= 
        toolkit.getImage("Destination Cards/bristol_southampton.jpg");
        cambridge_london= 
        toolkit.getImage("Destination Cards/cambridge_london.jpg");
        cardiff_london= 
        toolkit.getImage("Destination Cards/cardiff_london.jpg");
        cardiff_reading= 
        toolkit.getImage("Destination Cards/cardiff_reading.jpg");
        cork_leeds= 
        toolkit.getImage("Destination Cards/cork_leeds.jpg");
        dublin_cork= 
        toolkit.getImage("Destination Cards/dublin_cork.jpg");
        dublin_london= 
        toolkit.getImage("Destination Cards/dublin_london.jpg");
        dundalk_carlisle= 
        toolkit.getImage("Destination Cards/dundalk_carlisle.jpg");
        edinburgh_birmingham= 
        toolkit.getImage("Destination Cards/edinburgh_birmingham.jpg");
        edinburgh_london= 
        toolkit.getImage("Destination Cards/edinburgh_london.jpg");

        fortwilliam_edinburgh= 
        toolkit.getImage("Destination Cards/fortwilliam_edinburgh.jpg");
        galway_barrow= 
        toolkit.getImage("Destination Cards/galway_barrow.jpg");
        galway_dublin= 
        toolkit.getImage("Destination Cards/galway_dublin.jpg");
        glasgow_dublin= 
        toolkit.getImage("Destination Cards/glasgow_dublin.jpg");
        glasgow_france= 
        toolkit.getImage("Destination Cards/glasgow_france.jpg");
        glasgow_manchester= 
        toolkit.getImage("Destination Cards/glasgow_manchester.jpg");
        holyhead_cardiff= 
        toolkit.getImage("Destination Cards/holyhead_cardiff.jpg");
        iverness_belfast= 
        toolkit.getImage("Destination Cards/iverness_belfast.jpg");
        iverness_leeds= 
        toolkit.getImage("Destination Cards/iverness_leeds.jpg");
        leeds_france= 
        toolkit.getImage("Destination Cards/leeds_france.jpg");
        leeds_london= 
        toolkit.getImage("Destination Cards/leeds_london.jpg");
        leeds_manchester= 
        toolkit.getImage("Destination Cards/leeds_manchester.jpg");
        limerick_cardiff= 
        toolkit.getImage("Destination Cards/limerick_cardiff.jpg");
        liverpool_hull= 
        toolkit.getImage("Destination Cards/liverpool_hull.jpg");
        liverpool_llandrindod= 
        toolkit.getImage("Destination Cards/liverpool_llandrindod.jpg");
        liverpool_southampton= 
        toolkit.getImage("Destination Cards/liverpool_southampton.jpg");

        london_brighton= 
        toolkit.getImage("Destination Cards/london_brighton.jpg");
        london_france= 
        toolkit.getImage("Destination Cards/london_france.jpg");
        londonderry_birmingham= 
        toolkit.getImage("Destination Cards/londonderry_birmingham.jpg");
        londonderry_dublin= 
        toolkit.getImage("Destination Cards/londonderry_dublin.jpg");
        londonderry_stranraer= 
        toolkit.getImage("Destination Cards/londonderry_stranraer.jpg");
        manchester_london= 
        toolkit.getImage("Destination Cards/manchester_london.jpg");
        manchester_norwich= 
        toolkit.getImage("Destination Cards/manchester_norwich.jpg");
        manchester_plymouth= 
        toolkit.getImage("Destination Cards/manchester_plymouth.jpg");
        newcastle_hull= 
        toolkit.getImage("Destination Cards/newcastle_hull.jpg");
        newcastle_southampton= 
        toolkit.getImage("Destination Cards/newcastle_southampton.jpg");
        northampton_dover= 
        toolkit.getImage("Destination Cards/northampton_dover.jpg");
        norwich_ipswich= 
        toolkit.getImage("Destination Cards/norwich_ipswich.jpg");
        nottingham_ipswich= 
        toolkit.getImage("Destination Cards/nottingham_ipswich.jpg");
        penzance_london= 
        toolkit.getImage("Destination Cards/penzance_london.jpg");
        plymouth_reading= 
        toolkit.getImage("Destination Cards/plymouth_reading.jpg");
        rosslare_aberystwyth= 
        toolkit.getImage("Destination Cards/rosslare_aberystwyth.jpg");

        rosslare_carmarthen= 
        toolkit.getImage("Destination Cards/rosslare_carmarthen.jpg");
        sligo_holyhead= 
        toolkit.getImage("Destination Cards/sligo_holyhead.jpg");
        southampton_london= 
        toolkit.getImage("Destination Cards/southampton_london.jpg");
        stornoway_aberdeen= 
        toolkit.getImage("Destination Cards/stornoway_aberdeen.jpg");
        stornoway_glasgow= 
        toolkit.getImage("Destination Cards/stornoway_glasgow.jpg");
        stranraer_tullamore= 
        toolkit.getImage("Destination Cards/stranraer_tullamore.jpg");
        ullapool_dundee= 
        toolkit.getImage("Destination Cards/ullapool_dundee.jpg");
        wick_dundee= 
        toolkit.getImage("Destination Cards/wick_dundee.jpg");
        wick_edinburgh= 
        toolkit.getImage("Destination Cards/wick_edinburgh.jpg");
    }
}
