import java.util.*;
/**
 * This class will hold int values
 * that will determine if a player
 * contains the destination card.  Also,
 * helps create the deck of destination
 * cards than will allow a card to be removed
 * the top of the deck when a player wishes
 * to do so.
 * 
 * @author Jordan McKosky
 * @version 1.0
 */
public class Destination
{
    //int variables that determine if a
    //player has a certain destination card.

    //If a player has a destination card,
    //the int variable will be true.
    protected int aberdeen_glasgow = 0;
    protected int aberystwyth_cardiff = 0;
    protected int belfast_dublin = 0;
    protected int belfast_manchester = 0;
    protected int birmingham_cambridge = 0;
    protected int birmingham_london = 0;
    protected int bristol_southampton = 0;
    protected int cambridge_london = 0;
    protected int cardiff_london = 0;
    protected int cardiff_reading = 0;
    protected int cork_leeds = 0;
    protected int dublin_cork = 0;
    protected int dublin_london = 0;
    protected int dundalk_carlisle = 0;
    protected int edinburgh_birmingham = 0;
    protected int edinburgh_london = 0;

    protected int fortwilliam_edinburgh = 0;
    protected int galway_barrow = 0;
    protected int galway_dublin = 0;
    protected int glasgow_dublin = 0;
    protected int glasgow_france = 0;
    protected int glasgow_manchester = 0;
    protected int holyhead_cardiff = 0;
    protected int iverness_belfast = 0;
    protected int iverness_leeds = 0;
    protected int leeds_france = 0;
    protected int leeds_london = 0;
    protected int leeds_manchester = 0;
    protected int limerick_cardiff = 0;
    protected int liverpool_hull = 0;
    protected int liverpool_llandrindod = 0;
    protected int liverpool_southampton = 0;

    protected int london_brighton = 0;
    protected int london_france = 0;
    protected int londonderry_birmingham = 0;
    protected int londonderry_dublin = 0;
    protected int londonderry_stranraer = 0;
    protected int manchester_london = 0;
    protected int manchester_norwich = 0;
    protected int manchester_plymouth = 0;
    protected int newcastle_hull = 0;
    protected int newcastle_southampton = 0;
    protected int northampton_dover = 0;
    protected int norwich_ipswich = 0;
    protected int nottingham_ipswich = 0;
    protected int penzance_london = 0;
    protected int plymouth_reading = 0;
    protected int rosslare_aberystwyth = 0;

    protected int rosslare_carmarthen = 0;
    protected int sligo_holyhead = 0;
    protected int southampton_london = 0;
    protected int stornoway_aberdeen = 0;
    protected int stornoway_glasgow = 0;
    protected int stranraer_tullamore = 0;
    protected int ullapool_dundee = 0;
    protected int wick_dundee = 0;
    protected int wick_edinburgh = 0;
    
    //Represents the deck of destination cards.
    protected ArrayList<String> destinationDeck = new ArrayList<String>();
    
    /**
     * This method creates the deck of destination cards
     * and then shuffles the deck at the end of the method.
     */
    public Destination(){
        destinationDeck.add(new String("aberdeen_glasgow"));
        destinationDeck.add(new String ("aberystwyth_cardiff"));
        destinationDeck.add(new String ("belfast_dublin"));
        destinationDeck.add(new String ("belfast_manchester"));
        destinationDeck.add(new String ("birmingham_cambridge"));
        destinationDeck.add(new String ("birmingham_london"));
        destinationDeck.add(new String ("bristol_southampton"));
        destinationDeck.add(new String ("cambridge_london"));
        destinationDeck.add(new String ("cardiff_london"));
        destinationDeck.add(new String ("cardiff_reading"));
        destinationDeck.add(new String ("cork_leeds"));
        destinationDeck.add(new String ("dublin_london"));
        destinationDeck.add(new String ("dundalk_carlisle"));
        destinationDeck.add(new String ("edinburgh_birmingham"));
        destinationDeck.add(new String ("edinburgh_london"));

        destinationDeck.add(new String ("fortwilliam_edinburgh"));
        destinationDeck.add(new String ("galway_barrow"));
        destinationDeck.add(new String ("galway_dublin"));
        destinationDeck.add(new String ("glasgow_france"));
        destinationDeck.add(new String ("glasgow_manchester"));
        destinationDeck.add(new String ("holyhead_cardiff"));
        destinationDeck.add(new String ("iverness_belfast"));
        destinationDeck.add(new String ("iverness_leeds"));
        destinationDeck.add(new String ("leeds_france"));
        destinationDeck.add(new String ("leeds_london"));
        destinationDeck.add(new String ("leeds_manchester"));
        destinationDeck.add(new String ("limerick_cardiff"));
        destinationDeck.add(new String ("liverpool_hull"));
        destinationDeck.add(new String ("liverpool_llandrindod"));
        destinationDeck.add(new String ("liverpool_southampton"));

        destinationDeck.add(new String ("london_brighton"));
        destinationDeck.add(new String ("london_france"));
        destinationDeck.add(new String ("londonderry_birmingham"));
        destinationDeck.add(new String ("londonderry_dublin"));
        destinationDeck.add(new String ("londonderry_stranraer"));
        destinationDeck.add(new String ("manchester_london"));
        destinationDeck.add(new String ("manchester_norwich"));
        destinationDeck.add(new String ("manchester_plymouth"));
        destinationDeck.add(new String ("newcastle_hull"));
        destinationDeck.add(new String ("newcastle_southampton"));
        destinationDeck.add(new String ("northampton_dover"));
        destinationDeck.add(new String ("norwich_ipswich"));
        destinationDeck.add(new String ("nottingham_ipswich"));
        destinationDeck.add(new String ("penzance_london"));
        destinationDeck.add(new String ("plymouth_reading"));
        destinationDeck.add(new String ("rosslare_aberystwyth"));

        destinationDeck.add(new String ("rosslare_carmarthen"));
        destinationDeck.add(new String ("sligo_holyhead"));
        destinationDeck.add(new String ("southampton_london"));
        destinationDeck.add(new String ("stornoway_aberdeen"));
        destinationDeck.add(new String ("stornoway_glasgow"));
        destinationDeck.add(new String ("stranraer_tullamore"));
        destinationDeck.add(new String ("ullapool_dundee"));
        destinationDeck.add(new String ("wick_dundee"));
        destinationDeck.add(new String ("wick_edinburgh"));

        Collections.shuffle(destinationDeck);
    }

    
    /**
     * This method draws the destination card at the
     * top of the destination card deck.
     * 
     * @return the name of the destination card
     */
    public String drawDest(){
        return destinationDeck.remove(0);    
    }

    
    /**
     * this method assigns a player a destination card
     * 
     * @param p the player who will acquire this card
     * @param card the name of the card the player will acquire
     */
    public void chooseCard(Player p, String card){
        if(card.equals("aberdeen_glasgow"))
            aberdeen_glasgow = p.pNum;
        else if (card.equals("aberystwyth_cardiff"))
            aberystwyth_cardiff = p.pNum;
        else if (card.equals("belfast_dublin"))
            belfast_dublin = p.pNum;
        else if (card.equals("belfast_manchester"))
            belfast_manchester = p.pNum;
        else if (card.equals("birmingham_cambridge"))
            birmingham_cambridge = p.pNum;
        else if (card.equals("birmingham_london"))
            birmingham_london = p.pNum;
        else if (card.equals("bristol_southampton"))
            bristol_southampton = p.pNum;
        else if (card.equals("cambridge_london"))
            cambridge_london = p.pNum;
        else if (card.equals("cardiff_london"))
            cardiff_london = p.pNum;
        else if (card.equals("cardiff_reading"))
            cardiff_reading = p.pNum;
        else if (card.equals("cork_leeds"))
            cork_leeds = p.pNum;
        else if (card.equals("dublin_london"))
            dublin_london = p.pNum;
        else if (card.equals("dundalk_carlisle"))
            dundalk_carlisle = p.pNum;
        else if (card.equals("edinburgh_birmingham"))
            edinburgh_birmingham = p.pNum;
        else if (card.equals("edinburgh_london"))
            edinburgh_london = p.pNum;

        else if (card.equals("fortwilliam_edinburgh"))
            fortwilliam_edinburgh = p.pNum;
        else if (card.equals("galway_barrow"))
            galway_barrow = p.pNum;
        else if (card.equals("galway_dublin"))
            galway_dublin = p.pNum;
        else if (card.equals("glasgow_france"))
            glasgow_france = p.pNum;
        else if (card.equals("glasgow_manchester"))
            glasgow_manchester = p.pNum;
        else if (card.equals("holyhead_cardiff"))
            holyhead_cardiff = p.pNum;
        else if (card.equals("iverness_belfast"))
            iverness_belfast = p.pNum;
        else if (card.equals("iverness_leeds"))
            iverness_leeds = p.pNum;
        else if (card.equals("leeds_france"))
            leeds_france = p.pNum;
        else if (card.equals("leeds_london"))
            leeds_london = p.pNum;
        else if (card.equals("leeds_manchester"))
            leeds_manchester = p.pNum;
        else if (card.equals("limerick_cardiff"))
            limerick_cardiff = p.pNum;
        else if (card.equals("liverpool_hull"))
            liverpool_hull = p.pNum;
        else if (card.equals("liverpool_llandrindod"))
            liverpool_llandrindod = p.pNum;
        else if (card.equals("liverpool_southampton"))
            liverpool_southampton = p.pNum;

        else if (card.equals("london_france"))
            london_france = p.pNum;
        else if (card.equals("londonderry_birmingham"))
            londonderry_birmingham = p.pNum;
        else if (card.equals("londonderry_dublin"))
            londonderry_dublin = p.pNum;
        else if (card.equals("londonderry_stranraer"))
            londonderry_stranraer = p.pNum;
        else if (card.equals("manchester_london"))
            manchester_london = p.pNum;
        else if (card.equals("manchester_norwich"))
            manchester_norwich = p.pNum;
        else if (card.equals("manchester_plymouth"))
            manchester_plymouth = p.pNum;
        else if (card.equals("newcastle_hull"))
            newcastle_hull = p.pNum;
        else if (card.equals("newcastle_southampton"))
            newcastle_southampton = p.pNum;
        else if (card.equals("northampton_dover"))
            northampton_dover = p.pNum;
        else if (card.equals("norwich_ipswich"))
            norwich_ipswich = p.pNum;
        else if (card.equals("nottingham_ipswich"))
            nottingham_ipswich = p.pNum;
        else if (card.equals("penzance_london"))
            penzance_london = p.pNum;
        else if (card.equals("plymouth_reading"))
            plymouth_reading = p.pNum;
        else if (card.equals("rosslare_aberystwyth"))
            rosslare_aberystwyth = p.pNum;

        else if (card.equals("rosslare_carmarthen"))
            rosslare_carmarthen = p.pNum;
        else if (card.equals("sligo_holyhead"))
            sligo_holyhead = p.pNum;
        else if (card.equals("southampton_london"))
            southampton_london = p.pNum;
        else if (card.equals("stornoway_aberdeen"))
            stornoway_aberdeen = p.pNum;
        else if (card.equals("stornoway_glasgow"))
            stornoway_glasgow = p.pNum;
        else if (card.equals("stranraer_tullamore"))
            stranraer_tullamore = p.pNum;
        else if (card.equals("ullapool_dundee"))
            ullapool_dundee = p.pNum;
        else if (card.equals("wick_dundee"))
            wick_dundee = p.pNum;
        else if (card.equals("wick_edinburgh"))
            wick_edinburgh = p.pNum;
    }
}
