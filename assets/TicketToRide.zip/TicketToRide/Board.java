import javax.swing.*;
import java.awt.*;
import java.util.*;
/**
 *This class will help represent the 
 *gameboard using an Adjacency list
 * 
 * @author group 6
 * @version 1.0
 */
public class Board
{

    // Array to hold city info for dfs ------ NOT CURRENTLY USED
    protected boolean [] visited = new boolean [49];

    // list holding coordinates of paths owned
    protected int [][] pathList = new int [106][6];
    // number of paths owned, for cycling through array, initialized to 0
    int numPaths = 0;

    //Adjacency List.

    /**
     * represents each city,
     * each has a list of nodes adjacent to it
     */
    public class CityNode{
        public CityNode[] next; 
        public String name;
        public boolean owned;
        public NeighborNode [] nextTown;
        /**
         * Constructor for objects of type CityNode
         * initilizes its name and creates empty nodes
         * for all neighbors
         * 
         * @param n the name of the city
         * @param num the number of cities adjacent to this
         */
        public CityNode(String n, int num){
            name = n;
            next = null; 
            owned = false;
            nextTown = new NeighborNode[num];

            for(int i = 0 ; i < num; i++)
            {
                nextTown[i] = new CityNode.NeighborNode();
            }// end for
        }
        /**
         * Represents cities adjacent to each primary city 
         */
        public class NeighborNode
        {
            public String name;
            public Player ownedBy;
            public int nTrains;
            public int nLocomotives;
            public Color pathColor;
            public boolean nScotland;
            public boolean nIreland;
            public boolean nWales;
        }// end NeighborNode
    }// end CityNode class
    CityNode[] cityList = new CityNode[49];

    /**
     * initializes every city on the board
     * as well as each's neighbor
     * both ways.
     * also stores vital information for 
     * each path such as color,
     * number of trains requires, etc
     */
    public Board(){

        //46 ish more
        cityList[0] = new CityNode("Stornoway", 3);
        cityList[1] = new CityNode("Ullapool", 4);
        cityList[2] = new CityNode("Wick", 4);
        cityList[3] = new CityNode("Fort William", 6);

        cityList[4] = new CityNode("Inverness", 5);
        cityList[5] = new CityNode("Aberdeen", 5);    
        cityList[6] = new CityNode("Londonderry", 6);
        cityList[7] = new CityNode("Glasgow", 4);
        cityList[8] = new CityNode("Edinburgh", 6);
        cityList[9] = new CityNode("Dundee", 4);
        cityList[10] = new CityNode("Sligo", 4);  

        cityList[11] = new CityNode("Belfast", 4);
        cityList[12] = new CityNode("Stranraer", 5);
        cityList[13] = new CityNode("Galway", 3);
        cityList[14] = new CityNode("Dundalk", 5);
        cityList[15] = new CityNode("Carlisle", 4);    
        cityList[16] = new CityNode("Newcastle", 5);
        cityList[17] = new CityNode("Limerick", 3);
        cityList[18] = new CityNode("Tullamore", 6);
        cityList[19] = new CityNode("Dublin", 4);
        cityList[20] = new CityNode("Barrow", 4);    
        cityList[21] = new CityNode("Cork", 4);
        cityList[22] = new CityNode("Rosslare", 6);
        cityList[23] = new CityNode("Howhead", 6);
        cityList[24] = new CityNode("Liverpool", 4);

        cityList[25] = new CityNode("Leeds", 6);    
        cityList[26] = new CityNode("Aberystwyth", 4);
        cityList[27] = new CityNode("Manchester", 4);
        cityList[28] = new CityNode("Hull", 4);
        cityList[29] = new CityNode("Carmarthen", 3);
        cityList[30] = new CityNode("Llandrindod Wells", 5);    
        cityList[31] = new CityNode("Birmingham", 6);
        cityList[32] = new CityNode("Nottingham", 6);
        cityList[33] = new CityNode("Cardiff", 5);
        cityList[34] = new CityNode("Northampton", 5);
        cityList[35] = new CityNode("Cambridge", 5); 

        cityList[36] = new CityNode("Norwich", 4);
        cityList[37] = new CityNode("Penzance", 4);
        cityList[38] = new CityNode("Plymouth", 3);
        cityList[39] = new CityNode("Bristol", 4);
        cityList[40] = new CityNode("Reading", 5);    
        cityList[41] = new CityNode("London", 7);
        cityList[42] = new CityNode("Ipswich", 3);
        cityList[43] = new CityNode("Southampton", 7);
        cityList[44] = new CityNode("Brighton", 3);
        cityList[45] = new CityNode("Dover", 3);    
        cityList[46] = new CityNode("West France", 1);
        cityList[47] = new CityNode("East France", 1);
        cityList[48] = new CityNode("New York", 1);

        //Stornoway - DONE DONE
        cityList[0].next = new CityNode[3];
        cityList[0].next[0] = cityList[1];
        cityList[0].next[1] = cityList[2];
        cityList[0].next[2] = cityList[3];

        String [] A = {"Ullapool", "Wick", "Fort William"};
        //number of trains needed for each route
        int[] tA = {1, 5, 5};
        //number of locomotives needed for each route
        int[] lA = {1, 2, 1};
        //color of each route
        Color [] cA = {Color.GRAY, Color.GRAY, Color.GRAY};

        boolean[] sA = {true, true, true};
        boolean[] iA = {false, false, false};
        boolean[] wA = {false, false, false};

        fillNeigh(A, 3, 0, tA, lA, cA, sA, iA, wA);
        //Ullapool - DONE DONE
        cityList[1].next = new CityNode[4];
        cityList[1].next[0] = cityList[3];
        cityList[1].next[1] = cityList[4];
        cityList[1].next[2] = cityList[0];
        cityList[1].next[3] = cityList[2];

        String [] B = {"Stornoway", "Fort William", "Inverness", "Wick"};

        int[] tB = {1, 2, 1, 3};
        int[] lB = {1,0,0,0};

        Color[] cB = {Color.GRAY, Color.PINK, Color.ORANGE, Color.YELLOW};

        boolean[] sB = {true, true, true, true};
        boolean[] iB = {false, false, false, false};
        boolean[] wB = {false, false, false, false};

        fillNeigh(B, 4, citySwitch("Ullapool"), tB, lB, cB, sB, iB, wB);

        //Wick - DONE DONE
        cityList[2].next = new CityNode[4];
        cityList[2].next[0] = cityList[0];
        cityList[2].next[1] = cityList[1];
        cityList[2].next[2] = cityList[4];
        cityList[2].next[3] = cityList[5];

        String [] C = {"Stornoway", "Ullapool", "Inverness", "Aberdeen"};

        int[] tC = {5,3,2,3};
        int[] lC = {2,0,0,1};
        Color[] cC = {Color.GRAY, Color.YELLOW, Color.RED, Color.GRAY};

        boolean[] sC = {true, true, true,true};
        boolean[] iC = {false, false, false,false};
        boolean[] wC = {false, false, false,false};

        fillNeigh(C, 4, citySwitch("Wick"),tC, lC, cC,sC, iC, wC);
        //Fort William - DONE DONE
        cityList[3].next = new CityNode[6];
        cityList[3].next[0] = cityList[1];
        cityList[3].next[1] = cityList[0];
        cityList[3].next[2] = cityList[4];
        cityList[3].next[3] = cityList[9];
        cityList[3].next[4] = cityList[7];
        cityList[3].next[5] = cityList[6];

        String [] D = {"Stornoway", "Ullapool", "Inverness", "Dundee",
                "Glasgow", "Londonderry"};
        int[] tD = {5,2,2, 3, 2, 5};
        int[] lD = {1, 0, 0, 0, 0, 1};
        Color[] cD = {Color.GRAY, Color.PINK, Color.BLACK, Color.GREEN,
                Color.ORANGE, Color.GRAY};

        boolean[] sD = {true, true, true,true,true,true};
        boolean[] iD = {false, false, false,false,false,true};
        boolean[] wD = {false, false, false,false,false,false};

        fillNeigh(D, 6, citySwitch("Fort William"), tD, lD, cD,sD,iD,wD);

        //Inverness - DONE DONE
        cityList[4].next = new CityNode[5];
        cityList[4].next[0] = cityList[1];
        cityList[4].next[1] = cityList[2];
        cityList[4].next[2] = cityList[5];
        cityList[4].next[3] = cityList[9];
        cityList[4].next[4] = cityList[3];

        String [] E = {"Ullapool", "Wick", "Aberdeen", "Dundee",
                "Fort William"};

        int[] tE = {1,2,3,3,2};
        int[] lE = {0,0,0,0,0};
        Color[] cE = {Color.ORANGE, Color.RED, Color.PINK, Color.BLUE,
                Color.BLACK};

        boolean[] sE = {true, true, true,true,true};
        boolean[] iE = {false, false, false,false,false};
        boolean[] wE = {false, false, false,false,false};

        fillNeigh(E, 5, citySwitch("Inverness"), tE, lE, cE,sE,iE,wE);

        //Aberdeen - DONE DONE
        cityList[5].next = new CityNode[5];
        cityList[5].next[0] = cityList[2];
        cityList[5].next[1] = cityList[4];
        cityList[5].next[2] = cityList[9];
        cityList[5].next[4] = cityList[8];
        cityList[5].next[3] = cityList[16];

        String [] F = {"Wick", "Inverness", "Dundee", "Edinburgh",
                "Newcastle"};

        int[] tF = {3,3,1,4,6};
        int[] lF = {1,0,0,1,1};
        Color[] cF = {Color.GRAY, Color.PINK, Color.WHITE, Color.GRAY,
                Color.GRAY};

        boolean[] sF = {true, true, true,true,true};
        boolean[] iF = {false, false, false,false,false};
        boolean[] wF = {false, false, false,false,false};

        fillNeigh(F, 5, citySwitch("Aberdeen"), tF, lF, cF,sF,iF,wF);

        //Londonderry - DONE DONE
        cityList[6].next = new CityNode[6];
        cityList[6].next[0] = cityList[10];
        cityList[6].next[1] = cityList[14];
        cityList[6].next[2] = cityList[11];
        cityList[6].next[3] = cityList[12];
        cityList[6].next[4] = cityList[3];
        cityList[6].next[5] = cityList[7];

        String [] G = {"Sligo", "Dundalk", "Belfast", "Stranraer",
                "Glasgow", "Fort William"};

        int[] tG = {2,3,2, 3, 4,5};
        int[] lG = {0,0,0,1,1,1};
        Color[] cG = {Color.GREEN, Color.PINK,Color.ORANGE,Color.GRAY,
                Color.GRAY, Color.GRAY };

        boolean[] sG = {false, false, false,true,true,true};
        boolean[] iG = {true, true, true,true,true,true};
        boolean[] wG = {false, false, false,false,false,false};

        fillNeigh(G, 6, citySwitch("Londonderry"), tG, lG, cG,sG,iG,wG);

        //Glasgow - DONE DONE
        cityList[7].next = new CityNode[4];
        cityList[7].next[0] = cityList[3];
        cityList[7].next[1] = cityList[8];
        cityList[7].next[2] = cityList[12];
        cityList[7].next[3] = cityList[6];

        String [] H = {"Fort William", "Edinburgh", "Stranraer",
                "Londonderry"};

        int[] tH = {2,1,2,4};
        int[] lH = {0,0,0,1};
        Color[] cH = {Color.ORANGE, Color.BLUE, Color.RED, Color.GRAY};

        boolean[] sH = {true, true, true,true};
        boolean[] iH = {false, false, false,true};
        boolean[] wH = {false, false, false,false};

        fillNeigh(H, 4, citySwitch("Glasgow"), tH, lH, cH,sH,iH,wH);
        //Edinburgh - DONE DONE
        cityList[8].next = new CityNode[6];
        cityList[8].next[0] = cityList[9];
        cityList[8].next[1] = cityList[5];
        cityList[8].next[2] = cityList[16];
        cityList[8].next[3] = cityList[15];
        cityList[8].next[4] = cityList[7];
        cityList[8].next[5] = cityList[12];

        String [] I = {"Dundee", "Aberdeen", "Newcastle", "Carlisle",
                "Stranraer", "Glasgow"};

        int[] tI = {1,4,3,2,3,1};
        int[] lI = {0,1,0,0,0,0};
        Color[] cI = {Color.YELLOW,Color.GRAY, Color.PINK,Color.ORANGE,
                Color.WHITE,Color.BLUE};

        boolean[] sI = {true, true, true,true,true,true};
        boolean[] iI = {false, false, false,false,false,false};
        boolean[] wI = {false, false, false,false,false,false};

        fillNeigh(I, 6, citySwitch("Edinburgh"), tI, lI, cI,sI,iI,wI);
        //Dundee - DONE DONE
        cityList[9].next = new CityNode[4];
        cityList[9].next[0] = cityList[3];
        cityList[9].next[1] = cityList[4];
        cityList[9].next[2] = cityList[5];
        cityList[9].next[3] = cityList[8];

        String [] J = {"Fort William", "Inverness", "Aberdeen", "Edinburgh"};

        int[] tJ = {3,3,1,1};
        int[] lJ = {0,0,0,0};
        Color[] cJ = {Color.GREEN, Color.BLUE, Color.WHITE, Color.YELLOW};

        boolean[] sJ = {true, true, true,true};
        boolean[] iJ = {false, false, false,false};
        boolean[] wJ = {false, false, false,false};

        fillNeigh(J, 4, citySwitch("Dundee"), tJ, lJ, cJ,sJ,iJ,wJ);
        //Sligo - DONE DONE
        cityList[10].next = new CityNode[4];
        cityList[10].next[0] = cityList[13];
        cityList[10].next[1] = cityList[6];
        cityList[10].next[2] = cityList[14];
        cityList[10].next[3] = cityList[18];

        String [] K = {"Londonderry", "Dundalk", "Tullamore", "Galway"};

        int[] tK = {2,3,3,2};
        int[] lK = {0,0,0,0};
        Color[] cK = {Color.GREEN,Color.BLACK,Color.BLUE,Color.ORANGE};

        boolean[] sK = {false, false, false, false};
        boolean[] iK = {true, true, true, true};
        boolean[] wK = {false, false, false,false};

        fillNeigh(K, 4, citySwitch("Sligo"), tK, lK, cK, sK, iK, wK);
        //Belfast - DONE DONE
        cityList[11].next = new CityNode[4];
        cityList[11].next[0] = cityList[6];
        cityList[11].next[1] = cityList[14];
        cityList[11].next[2] = cityList[12];
        cityList[11].next[3] = cityList[20];

        String [] L = {"Londonderry", "Stranraer", "Barrow", "Dundalk"};

        int[] tL = {2,1,4,1};
        int[] lL = {0,1,1,0};
        Color[] cL = {Color.ORANGE,Color.GRAY,Color.GRAY,Color.RED};

        boolean[] sL = {false, true, false,false};
        boolean[] iL = {true, true, true,true};
        boolean[] wL = {false, false, false,false};

        fillNeigh(L, 4, citySwitch("Belfast"), tL, lL, cL,sL,iL,wL);

        //Stranraer - DONE DONE
        cityList[12].next = new CityNode[5];
        cityList[12].next[0] = cityList[6];
        cityList[12].next[1] = cityList[11];
        cityList[12].next[2] = cityList[7];
        cityList[12].next[3] = cityList[15];
        cityList[12].next[4] = cityList[8];

        String [] M = {"Glasgow", "Londonderry", "Belfast", "Carlisle",
                "Edinburgh"};

        int[] tM = {2,3,1,3,3};
        int[] lM = {0,1,1,1,0};
        Color[] cM = {Color.RED, Color.GRAY, Color.GRAY, Color.GRAY,
                Color.WHITE};

        boolean[] sM = {true, true, true,true,true};
        boolean[] iM = {false, true, true,false,false};
        boolean[] wM = {false, false, false,false,false};

        fillNeigh(M, 5, citySwitch("Stranraer"), tM, lM, cM,sM,iM,wM);
        //Galway - DONE DONE
        cityList[13].next = new CityNode[3];
        cityList[13].next[0] = cityList[10];
        cityList[13].next[1] = cityList[18];
        cityList[13].next[2] = cityList[17];

        String [] N = {"Limerick", "Tullamore", "Sligo"};

        int[] tN = {1,2,2};
        int[] lN = {0,0,0};
        Color[] cN = {Color.YELLOW,Color.GRAY,Color.ORANGE};

        boolean[] sN = {false, false, false};
        boolean[] iN = {true, true, true};
        boolean[] wN = {false, false, false};

        fillNeigh(N, 3, citySwitch("Galway"), tN, lN, cN,sN,iN,wN);
        //Dundalk - DONE DONE
        cityList[14].next = new CityNode[5];
        cityList[14].next[0] = cityList[10];
        cityList[14].next[1] = cityList[6];
        cityList[14].next[2] = cityList[11];
        cityList[14].next[3] = cityList[19];
        cityList[14].next[4] = cityList[23];

        String [] O = {"Sligo", "Londonderry", "Belfast", "Howhead",
                "Dublin"};

        int[] tO = {3,3,1,3,1};
        int[] lO = {0,0,0,1,0};
        Color[] cO = {Color.BLACK,Color.PINK,Color.RED,Color.GRAY,
                Color.YELLOW};

        boolean[] sO = {false, false, false,false,false};
        boolean[] iO = {true, true, true,true,true};
        boolean[] wO = {false, false, false,true,false};

        fillNeigh(O, 5, citySwitch("Dundalk"), tO, lO, cO,sO,iO,wO);

        //Carlisle - DONE DONE
        cityList[15].next = new CityNode[4];
        cityList[15].next[0] = cityList[12];
        cityList[15].next[1] = cityList[8];
        cityList[15].next[2] = cityList[16];
        cityList[15].next[3] = cityList[20];

        String [] P = {"Stranraer", "Edinburgh", "Newcastle", "Barrow"};

        int[] tP = {3,2,1,1};
        int[] lP = {1,0,0,0};
        Color[] cP = {Color.GRAY, Color.ORANGE, Color.YELLOW, Color.RED};

        boolean[] sP = {true, true, true,false};
        boolean[] iP = {false, false, false,false};
        boolean[] wP = {false, false, false,false};

        fillNeigh(P, 4, citySwitch("Carlisle"), tP ,lP, cP,sP,iP,wP);
        //Newcastle - DONE DONE
        cityList[16].next = new CityNode[5];
        cityList[16].next[0] = cityList[15];
        cityList[16].next[1] = cityList[8];
        cityList[16].next[2] = cityList[5];
        cityList[16].next[3] = cityList[28];
        cityList[16].next[4] = cityList[25];

        String [] Q = {"Aberdeen", "Edinburgh", "Carlisle", "Leeds", "Hull"};

        int[] tQ = {6,3,1,2,5};
        int[] lQ = {1,0,0,0,1};
        Color[] cQ = {Color.GRAY,Color.PINK,Color.YELLOW,Color.WHITE,
                Color.GRAY};

        boolean[] sQ = {true, true, false,false,false};
        boolean[] iQ = {false, false, false,false,false};
        boolean[] wQ = {false, false, false,false,false};

        fillNeigh(Q, 5, citySwitch("Newcastle"), tQ, lQ, cQ,sQ,iQ,wQ);

        //Limerick - DONE DONE
        cityList[17].next = new CityNode[3];
        cityList[17].next[0] = cityList[13];
        cityList[17].next[1] = cityList[18];
        cityList[17].next[2] = cityList[24];

        String [] R = {"Galway", "Tullamore", "Cork"};

        int[] tR = {1,1,1};
        int[] lR = {0,0,0};
        Color[] cR = {Color.YELLOW, Color.GRAY, Color.PINK};

        boolean[] sR = {false, false, false};
        boolean[] iR = {true, true, true};
        boolean[] wR = {false, false, false};

        fillNeigh(R, 3, citySwitch("Limerick"), tR, lR, cR, sR, iR, wR);

        //Tullamore - DONE DONE
        cityList[18].next = new CityNode[6];
        cityList[18].next[0] = cityList[13];
        cityList[18].next[1] = cityList[10];
        cityList[18].next[2] = cityList[19];
        cityList[18].next[3] = cityList[22];
        cityList[18].next[4] = cityList[21];
        cityList[18].next[5] = cityList[17];

        String [] S = {"Sligo", "Galway", "Limerick", "Cork", "Rosslare",
                "Dublin"};

        int[] tS = {3,2,1,3,2,1};
        int[] lS = {0,0,0,0,0,0};
        Color[] cS = {Color.BLUE,Color.GRAY,Color.GRAY,Color.YELLOW,
                Color.RED,Color.GREEN};

        boolean[] sS = {false, false, false,false,false,false};
        boolean[] iS = {true, true, true,true,true,true};
        boolean[] wS = {false, false, false,false,false,false};

        fillNeigh(S, 6, citySwitch("Tullamore"), tS, lS, cS,sS,iS,wS);

        //Dublin - DONE DONE
        cityList[19].next = new CityNode[4];
        cityList[19].next[0] = cityList[18];
        cityList[19].next[1] = cityList[14];
        cityList[19].next[2] = cityList[23];
        cityList[19].next[3] = cityList[22];

        String [] T = {"Dundalk", "Tullamore", "Rosslare", "Howhead"};

        int[] tT = {1,1,2,2};
        int[] lT = {0,0,0,1};
        Color[] cT = {Color.YELLOW, Color.GREEN, Color.WHITE, Color.GRAY};

        boolean[] sT = {false, false, false,false};
        boolean[] iT = {true, true, true,true};
        boolean[] wT = {false, false, false,false};

        fillNeigh(T, 4, citySwitch("Dublin"), tT, lT, cT, sT, iT, wT);

        //Barrow - DONE DONE
        cityList[20].next = new CityNode[4];
        cityList[20].next[0] = cityList[11];
        cityList[20].next[1] = cityList[15];
        cityList[20].next[2] = cityList[25];
        cityList[20].next[3] = cityList[24];

        String [] U = {"Belfast", "Carlisle", "Leeds", "Liverpool"};

        int[] tU = {4,1,2,1};
        int[] lU = {1,0,0,1};
        Color[] cU = {Color.GRAY,Color.RED,Color.GREEN,Color.GRAY};

        boolean[] sU = {false, false, false,false};
        boolean[] iU = {true, false, false,false};
        boolean[] wU = {false, false, false,false};

        fillNeigh(U, 4, citySwitch("Barrow"), tU, lU, cU,sU,iU,wU);

        //Cork - DONE DONE
        cityList[21].next = new CityNode[4];
        cityList[21].next[0] = cityList[17];
        cityList[21].next[1] = cityList[18];
        cityList[21].next[2] = cityList[22];
        cityList[21].next[3] = cityList[37];

        String [] V = {"Limerick", "Tullamore", "Rosslare", "Penzance"};

        int[] tV = {1,3,2,6};
        int[] lV = {0,0,0,2};
        Color[] cV = {Color.PINK, Color.YELLOW, Color.BLUE, Color.GRAY};

        boolean[] sV = {false, false, false,false};
        boolean[] iV = {true, true, true,true};
        boolean[] wV = {false, false, false,false};

        fillNeigh(V, 4, citySwitch("Cork"), tV, lV, cV, sV, iV, wV);

        //Rosslare - DONE DONE
        cityList[22].next = new CityNode[6];
        cityList[22].next[0] = cityList[21];
        cityList[22].next[1] = cityList[18];
        cityList[22].next[2] = cityList[19];
        cityList[22].next[3] = cityList[23];
        cityList[22].next[4] = cityList[26];
        cityList[22].next[5] = cityList[29];
        String [] W = {"Cork", "Tullamore", "Dublin", "Howhead",
                "Aberystwyth", "Carmarthen"};

        int[] tW = {2,2,2,3,3,4};
        int[] lW = {0,0,0,1,1,1};
        Color[] cW = {Color.BLUE,Color.RED,Color.WHITE,Color.GRAY,
                Color.GRAY,Color.GRAY};

        boolean[] sW = {false, false, false,false,false,false};
        boolean[] iW = {true, true, true,true,true,true};
        boolean[] wW = {false, false, false,true,true,true};

        fillNeigh(W, 6, citySwitch("Rosslare"), tW, lW, cW,sW,iW,wW);

        //Howhead - DONE DONE
        cityList[23].next = new CityNode[6];
        cityList[23].next[0] = cityList[14];
        cityList[23].next[1] = cityList[19];
        cityList[23].next[2] = cityList[24];
        cityList[23].next[3] = cityList[26];
        cityList[23].next[4] = cityList[30];
        cityList[23].next[5] = cityList[22];

        String [] X = {"Liverpool", "Dundalk", "Dublin", "Rosslare",
                "Aberystwyth", "Llandrindod Wells"};

        int[] tX = {2,3,2,3,2,3};
        int[] lX = {1,1,1,1,1,0};
        Color[] cX = {Color.GRAY, Color.GRAY, Color.GRAY, Color.GRAY,
                Color.GRAY, Color.BLUE};

        boolean[] sX = {false, false, false,false, false, false};
        boolean[] iX = {false, true, true,true, false, false};
        boolean[] wX = {true, true, true,true, true, true};

        fillNeigh(X, 6, citySwitch("Howhead"), tX, lX, cX,sX,iX,wX);

        //Liverpool - DONE DONE
        cityList[24].next = new CityNode[4];
        cityList[24].next[0] = cityList[23];
        cityList[24].next[1] = cityList[20];
        cityList[24].next[2] = cityList[25];
        cityList[24].next[3] = cityList[27];

        String [] Y = {"Howhead", "Barrow", "Leeds", "Manchester"};

        int[] tY = {2,1,2,1};
        int[] lY = {1,1,0,0}; 
        Color[] cY = {Color.GRAY, Color.GRAY, Color.BLACK, Color.ORANGE};

        boolean[] sY = {false, false, false,false};
        boolean[] iY = {false, false, false,false};
        boolean[] wY = {true, false, false,false};

        fillNeigh(Y, 4, citySwitch("Liverpool"), tY, lY, cY,sY,iY,wY);

        //Leeds - DONE DONE
        cityList[25].next = new CityNode[6];
        cityList[25].next[0] = cityList[20];
        cityList[25].next[1] = cityList[16];
        cityList[25].next[2] = cityList[28];
        cityList[25].next[3] = cityList[32];
        cityList[25].next[4] = cityList[27];
        cityList[25].next[5] = cityList[24];

        String [] Z = {"Newcastle", "Hull", "Nottingham", "Manchester",
                "Liverpool", "Barrow"};

        int[] tZ = {2,1,2,1,2,2};
        int[] lZ = {0,0,0,0,0,0};
        Color[] cZ = {Color.WHITE, Color.YELLOW, Color.PINK, Color.BLUE,
                Color.BLACK, Color.GREEN};

        boolean[] sZ = {false, false, false,false,false,false};
        boolean[] iZ = {false, false, false,false,false,false};
        boolean[] wZ = {false, false, false,false,false,false};

        fillNeigh(Z, 6, citySwitch("Leeds"), tZ, lZ, cZ,sZ,iZ,wZ);

        //Aberystwyth -DONE DONE
        cityList[26].next = new CityNode[4];
        cityList[26].next[0] = cityList[22];
        cityList[26].next[1] = cityList[23];
        cityList[26].next[2] = cityList[30];
        cityList[26].next[3] = cityList[29];

        String [] A1 = {"Llandrindod Wells", "Howhead", "Rosslare",
                "Carmarthen"};

        int[] tA1 = {1,2,3,1};
        int[] lA1 = {0,1,1,0};
        Color[] cA1 = {Color.WHITE, Color.GRAY, Color.GRAY, Color.YELLOW};

        boolean[] sA1 = {false, false, false,false};
        boolean[] iA1 = {false, false, true,false};
        boolean[] wA1 = {true, true, true,true};

        fillNeigh(A1, 4, citySwitch("Aberystwyth"), tA1, lA1, cA1, sA1,
            iA1, wA1);

        //Manchester - DONE DONE
        cityList[27].next = new CityNode[4];
        cityList[27].next[0] = cityList[24];
        cityList[27].next[1] = cityList[25];
        cityList[27].next[2] = cityList[31];
        cityList[27].next[3] = cityList[30];

        String [] A2 = {"Liverpool", "Leeds", "Birmingham",
                "Llandrindod Wells"};

        int[] tA2 = {1,1,2,3};
        int[] lA2 = {0,0,0,0};
        Color[] cA2 = {Color.ORANGE, Color.BLUE, Color.BLACK, Color.GREEN};

        boolean[] sA2 = {false, false, false,false};
        boolean[] iA2 = {false, false, false,false};
        boolean[] wA2 = {false, false, false,true};

        fillNeigh(A2, 4, citySwitch("Manchester"), tA2, lA2, cA2,
            sA2,iA2,wA2);
        //Hull - DONE DONE
        cityList[28].next = new CityNode[4];
        cityList[28].next[0] = cityList[25];
        cityList[28].next[1] = cityList[16];
        cityList[28].next[2] = cityList[36];
        cityList[28].next[3] = cityList[32];

        String [] A3 = {"Newcastle", "Leeds", "Nottingham", "Norwich"};

        int[] tA3 = {5,1,2,4};
        int[] lA3 = {1,0,0,0};
        Color[] cA3 = {Color.GRAY, Color.YELLOW, Color.BLACK, Color.GRAY};

        boolean[] sA3 = {false, false, false,false};
        boolean[] iA3 = {false, false, false,false};
        boolean[] wA3 = {false, false, false,false};

        fillNeigh(A3, 4, citySwitch("Hull"), tA3, lA3, cA3, sA3, iA3, wA3);

        //Carmarthen -DONE DONE
        cityList[29].next = new CityNode[3];
        cityList[29].next[0] = cityList[22];
        cityList[29].next[1] = cityList[26];
        cityList[29].next[2] = cityList[33];

        String [] A4 = {"Rosslare", "Aberystwyth", "Cardiff"};

        int[] tA4 = {4,1,1};
        int[] lA4 = {1,0,0};
        Color[] cA4 = {Color.GRAY, Color.YELLOW, Color.RED};

        boolean[] sA4 = {false, false, false};
        boolean[] iA4 = {true, false, false};
        boolean[] wA4 = {true, true, true};

        fillNeigh(A4, 3, citySwitch("Carmarthen"), tA4, lA4,
            cA4, sA4,iA4,wA4);
        //Llandrindod Wells - DONE DONE
        cityList[30].next = new CityNode[5];
        cityList[30].next[0] = cityList[26];
        cityList[30].next[1] = cityList[23];
        cityList[30].next[2] = cityList[27];
        cityList[30].next[3] = cityList[31];
        cityList[30].next[4] = cityList[33];

        String [] A5 = {"Aberystwyth", "Howhead", "Manchester",
                "Birmingham", "Cardiff"};

        int[] tA5 = {1,3,3,2,1};
        int[] lA5 = {0,0,0,0,0};
        Color[] cA5 = {Color.WHITE, Color.BLUE, Color.GREEN, Color.RED,
                Color.PINK};

        boolean[] sA5 = {false, false, false,false,false};
        boolean[] iA5 = {false, false, false,false,false};
        boolean[] wA5 = {true, true, true,true,true};

        fillNeigh(A5, 5, citySwitch("Llandrindod Wells"), tA5, lA5, cA5,
            sA5, iA5, wA5);

        //Birmingham - DONE DONE
        cityList[31].next = new CityNode[6];
        cityList[31].next[0] = cityList[30];
        cityList[31].next[1] = cityList[27];
        cityList[31].next[2] = cityList[32];
        cityList[31].next[3] = cityList[34];
        cityList[31].next[4] = cityList[40];
        cityList[31].next[5] = cityList[33];

        String [] A6 = {"Llandrindod Wells", "Manchester", "Nottingham",
                "Northampton", "Reading", "Cardiff"};

        int[] tA6 = {2,2,1,1,2,3};
        int[] lA6 = {0,0,0,0,0,0};
        Color[] cA6 = {Color.RED, Color.BLACK, Color.GRAY, Color.GREEN,
                Color.GRAY, Color.BLUE};

        boolean[] sA6 = {false, false, false,false,false,false};
        boolean[] iA6 = {false, false, false,false,false,false};
        boolean[] wA6 = {true, false, false,false,false,true};

        fillNeigh(A6, 6, citySwitch("Birmingham"), tA6, lA6, cA6,sA6,
            iA6,wA6);
        //Nottingham - DONE DONE
        cityList[32].next = new CityNode[6];
        cityList[32].next[0] = cityList[25];
        cityList[32].next[1] = cityList[28];
        cityList[32].next[2] = cityList[36];
        cityList[32].next[3] = cityList[35];
        cityList[32].next[4] = cityList[34];
        cityList[32].next[5] = cityList[31];

        String [] A7 = {"Leeds", "Hull", "Cambridge", "Norwich",
                "Northampton", "Birmingham"};

        int[] tA7 = {2,2,2,4,1,1};
        int[] lA7 = {0,0,0,0,0,0};
        Color[] cA7 = {Color.PINK, Color.BLACK, Color.GRAY,
                Color.WHITE, Color.ORANGE, Color.GRAY};

        boolean[] sA7 = {false, false, false, false, false, false};
        boolean[] iA7 = {false, false, false, false, false, false};
        boolean[] wA7 = {false, false, false, false, false, false};

        fillNeigh(A7, 6, citySwitch("Nottingham"), tA7, lA7, cA7, sA7,
            iA7, wA7);

        //Cardiff - DONE DONE
        cityList[33].next = new CityNode[5];
        cityList[33].next[0] = cityList[29];
        cityList[33].next[1] = cityList[30];
        cityList[33].next[2] = cityList[37];
        cityList[33].next[3] = cityList[39];
        cityList[33].next[4] = cityList[31];

        String [] A8 = {"Carmarthen", "Llandrindod Wells", "Birmingham",
                "Bristol", "Penzance"};

        int[] tA8 = {1,1,3,1,5};
        int[] lA8 = {0,0,0,1,1};
        Color[] cA8 = {Color.RED, Color.PINK, Color.BLUE, Color.GRAY,
                Color.GRAY};

        boolean[] sA8 = {false, false, false,false, false};
        boolean[] iA8 = {false, false, false,false, false};
        boolean[] wA8 = {true, true, true,true, true};

        fillNeigh(A8, 5, citySwitch("Cardiff"), tA8, lA8, cA8, sA8, iA8,
            wA8);

        //Northampton DONE DONE
        cityList[34].next = new CityNode[5];
        cityList[34].next[0] = cityList[31];
        cityList[34].next[1] = cityList[32];
        cityList[34].next[2] = cityList[35];
        cityList[34].next[3] = cityList[41];
        cityList[34].next[4] = cityList[40];

        String [] A9 = {"Birmingham", "Nottingham", "Cambridge", "London",
                "Reading"};

        int[] tA9 = {1,1,1,1,1};
        int[] lA9 = {0,0,0,0,0};
        Color[] cA9 = {Color.GREEN, Color.ORANGE, Color.GRAY,
                Color.PINK, Color.RED};

        boolean[] sA9 = {false, false, false, false, false};
        boolean[] iA9 = {false, false, false,false, false};
        boolean[] wA9 = {false, false, false,false, false};

        fillNeigh(A9, 5, citySwitch("Northampton"), tA9, lA9 , cA9,
            sA9, iA9, wA9);

        //Cambridge DONE DONE
        cityList[35].next = new CityNode[5];
        cityList[35].next[0] = cityList[34];
        cityList[35].next[1] = cityList[41];
        cityList[35].next[2] = cityList[42];
        cityList[35].next[3] = cityList[32];
        cityList[35].next[4] = cityList[36];

        String [] B1 = {"Nottingham", "Norwich", "Ipswich", "London",
                "Northampton"};

        int[] tB1 = {2,2,1,1,1};
        int[] lB1 = {0,0,0,0,0};
        Color[] cB1 = {Color.GRAY,Color.RED,Color.BLACK,Color.YELLOW,
                Color.GRAY};

        boolean[] sB1 = {false, false, false, false, false};
        boolean[] iB1 = {false, false, false, false, false};
        boolean[] wB1 = {false, false, false, false, false};

        fillNeigh(B1, 5, citySwitch("Cambridge"), tB1, lB1, cB1, sB1,
            iB1, wB1);

        //Norwich DONE DONE
        cityList[36].next = new CityNode[4];
        cityList[36].next[0] = cityList[28];
        cityList[36].next[1] = cityList[32];
        cityList[36].next[2] = cityList[35];
        cityList[36].next[3] = cityList[42];

        String [] B2 = {"Hull", "Nottingham", "Cambridge", "Ipswich"};

        int[] tB2 = {4,2,2,1};
        int[] lB2 = {0,0,0,0};
        Color[] cB2 = {Color.GRAY,Color.WHITE,Color.RED,Color.GREEN};

        boolean[] sB2 = {false, false, false,false};
        boolean[] iB2 = {false, false, false,false};
        boolean[] wB2 = {false, false, false,false};

        fillNeigh(B2, 4, citySwitch("Norwich"),tB2,lB2,cB2,sB2,iB2,wB2);

        //Penzance DONE DONE
        cityList[37].next = new CityNode[3];
        cityList[37].next[0] = cityList[21];
        cityList[37].next[1] = cityList[33];
        cityList[37].next[2] = cityList[38];

        String [] B3 = {"Cork", "Cardiff", "Plymouth"};

        int[] tB3 = {6,5,2};
        int[] lB3 = {2,1,0};
        Color[] cB3 = {Color.GRAY,Color.GRAY,Color.BLACK};

        boolean[] sB3 = {false, false, false};
        boolean[] iB3 = {true, false, false};
        boolean[] wB3 = {false, true, false};

        fillNeigh(B3, 3, citySwitch("Penzance"),tB3,lB3,cB3,sB3,iB3,wB3);
        //Plymouth DONE DONE
        cityList[38].next = new CityNode[3];
        cityList[38].next[0] = cityList[37];
        cityList[38].next[1] = cityList[39];
        cityList[38].next[2] = cityList[43];

        String [] C1 = {"Penzance", "Bristol", "Southampton"};

        int[] tC1 = {2,3,5};
        int[] lC1 = {0,0,1};
        Color[] cC1 = {Color.BLACK,Color.YELLOW,Color.GRAY};

        boolean[] sC1 = {false, false, false, false};
        boolean[] iC1 = {false, false, false,false};
        boolean[] wC1 = {false, false, false,false};

        fillNeigh(C1, 3, citySwitch("Plymouth"),tC1,lC1,cC1,sC1,iC1,wC1);

        //Bristol DONE DONE
        cityList[39].next = new CityNode[4];
        cityList[39].next[0] = cityList[33];
        cityList[39].next[1] = cityList[38];
        cityList[39].next[2] = cityList[40];
        cityList[39].next[3] = cityList[43];

        String [] D1 = {"Cardiff", "Reading", "Southampton", "Plymouth"};

        int[] tD1 = {1,2,2,3};
        int[] lD1 = {1,0,0,0};
        Color[] cD1 = {Color.GRAY,Color.WHITE,Color.GREEN,Color.YELLOW};

        boolean[] sD1 = {false, false, false,false};
        boolean[] iD1 = {false, false, false,false};
        boolean[] wD1 = {true, false, false,false};

        fillNeigh(D1, 4,  citySwitch("Bristol"),tD1,lD1,cD1,sD1,iD1,wD1);

        //Reading DONE DONE
        cityList[40].next = new CityNode[5];
        cityList[40].next[0] = cityList[39];
        cityList[40].next[1] = cityList[43];
        cityList[40].next[2] = cityList[31];
        cityList[40].next[3] = cityList[34];
        cityList[40].next[4] = cityList[41];

        String [] E1 = {"Bristol", "Birmingham", "Northampton",
                "London", "Southampton"};

        int[] tE1 = {2,2,1,1,1};
        int[] lE1 = {0,0,0,0,0};
        Color[] cE1 = {Color.WHITE,Color.GRAY,Color.RED,Color.GREEN,
                Color.ORANGE};

        boolean[] sE1 = {false, false, false,false,false};
        boolean[] iE1 = {false, false, false,false,false};
        boolean[] wE1 = {false, false, false,false,false};

        fillNeigh(E1, 5,  citySwitch("Reading"), tE1,lE1,cE1,sE1,iE1,wE1);
        //London DONE DONE
        cityList[41].next = new CityNode[7];
        cityList[41].next[0] = cityList[40];
        cityList[41].next[1] = cityList[42];
        cityList[41].next[2] = cityList[34];
        cityList[41].next[3] = cityList[45];
        cityList[41].next[4] = cityList[35];
        cityList[41].next[5] = cityList[44];
        cityList[41].next[6] = cityList[43];

        String [] F1 = {"Cambridge", "Ipswich", "Dover", "Brighton",
                "Southampton", "Reading", "Northampton"};

        int[] tF1 = {1,1,2,1,2,1,1};
        int[] lF1 = {0,0,0,0,0,0,0};
        Color[] cF1 = {Color.YELLOW,Color.WHITE,Color.GRAY,Color.GRAY,
                Color.RED,Color.GREEN,Color.PINK};

        boolean[] sF1 = {false, false, false,false,false,false,false};
        boolean[] iF1 = {false, false, false,false,false,false,false};
        boolean[] wF1 = {false, false, false,false,false,false,false};

        fillNeigh(F1, 7,  citySwitch("London"),tF1,lF1,cF1,sF1,iF1,wF1);

        //Ipswich - DONE DONE
        cityList[42].next = new CityNode[3];
        cityList[42].next[0] = cityList[35];
        cityList[42].next[1] = cityList[41];
        cityList[42].next[2] = cityList[36];

        String [] G1 = {"Norwich", "Cambridge", "London"};

        int[] tG1 = {1,1,1};
        int[] lG1 = {0,0,0};
        Color[] cG1 = {Color.GREEN, Color.BLACK, Color.WHITE};

        boolean[] sG1 = {false, false, false};
        boolean[] iG1 = {false, false, false};
        boolean[] wG1 = {false, false, false};

        fillNeigh(G1, 3,  citySwitch("Ipswich"), tG1, lG1, cG1, sG1,iG1,wG1);
        //Southampton - DONE DONE
        cityList[43].next = new CityNode[7];
        cityList[43].next[0] = cityList[46];
        cityList[43].next[1] = cityList[38];
        cityList[43].next[2] = cityList[39];
        cityList[43].next[3] = cityList[40];
        cityList[43].next[4] = cityList[41];
        cityList[43].next[5] = cityList[44];
        cityList[43].next[6] = cityList[48];

        String [] H1 = {"Plymouth", "Bristol", "Reading", "London",
                "Brighton", "West France","New York"};

        int[] tH1 = {5,2,1,2,1,3,10};
        int[] lH1 = {1,0,0,0,0,1,3};
        Color[] cH1 = {Color.GRAY, Color.GREEN, Color.ORANGE, Color.RED,
                Color.BLUE, Color.GRAY, Color.GRAY};

        boolean[] sH1 = {false, false, false,false,false,false,false};
        boolean[] iH1 = {false, false, false,false,false,true,false};
        boolean[] wH1 = {false, false, false,false,false,false,false};

        fillNeigh(H1, 7,  citySwitch("Southampton"), tH1, lH1, cH1,sH1,
            iH1,wH1);
        //Brighton - DONE DONE
        cityList[44].next = new CityNode[3];
        cityList[44].next[0] = cityList[43];
        cityList[44].next[1] = cityList[41];
        cityList[44].next[2] = cityList[45];

        String [] I1 = {"Southampton", "London", "Dover"};

        int[] tI1 = {1,1,2};
        int[] lI1 = {0,0,0};
        Color[] cI1 = {Color.BLUE, Color.GRAY, Color.PINK};

        boolean[] sI1 = {false, false, false};
        boolean[] iI1 = {false, false, false};
        boolean[] wI1 = {false, false, false};

        fillNeigh(I1, 3,  citySwitch("Brighton"), tI1, lI1, cI1,sI1,iI1,wI1);

        //Dover - DONE DONE
        cityList[45].next = new CityNode[3];
        cityList[45].next[0] = cityList[47];
        cityList[45].next[1] = cityList[44];
        cityList[45].next[2] = cityList[41];

        String [] J1 = {"London", "Brighton", "East France"};

        int[] tJ1 = {2,2,2};
        int[] lJ1 = {0,0,1};
        Color[] cJ1 = {Color.GRAY, Color.PINK, Color.GRAY};

        boolean[] sJ1 = {false, false, false};
        boolean[] iJ1 = {false, false, true};
        boolean[] wJ1 = {false, false, false};

        fillNeigh(J1, 3,  citySwitch("Dover"), tJ1, lJ1, cJ1,sJ1,iJ1,wJ1);

        //West France DONE WORKING
        cityList[46].next = new CityNode[1];
        cityList[46].next[0] = cityList[43];

        String [] K1 = {"Southampton"};

        int[] tK1 = {3};
        int[] lK1 = {1};
        Color[] cK1 = {Color.GRAY};

        boolean[] sK1 = {false};
        boolean[] iK1 = {true};
        boolean[] wK1 = {false};

        fillNeigh(K1, 1,  citySwitch("West France"), tI1, lI1, cI1,
            sK1,iK1,wK1);

        //East France
        cityList[47].next = new CityNode[1];
        cityList[47].next[0] = cityList[45];

        String [] K2 = {"Dover"};

        int[] tK2 = {2};
        int[] lK2 = {1};
        Color[] cK2 = {Color.GRAY};

        boolean[] sK2 = {false};
        boolean[] iK2 = {true};
        boolean[] wK2 = {false};

        fillNeigh(K2, 1,  citySwitch("East France"), tK2, lK2, cK2,
            sK2,iK2,wK2);

        //New York
        cityList[48].next = new CityNode[1];
        cityList[48].next[0] = cityList[43];

        String[] K3 = {"Southampton"};

        int[] tK3 = {10};
        int[] lK3 = {3};
        Color[] cK3 = {Color.GRAY};

        boolean[] sK3 = {false};
        boolean[] iK3 = {false};
        boolean[] wK3 = {false};

        fillNeigh(K3, 1, citySwitch("New York"), tK3,lK3, cK3, sK3,
            iK3, wK3);
    }

    /**
     * fillNeigh cycles through an arrays of data about the second city 
     * in a path and stores it in that city's node
     * @param Arr is a string array containing the names of neighboring
     * cities
     * @param size is the size of the array being passed in
     * @param city is the city whose neighbors are being stored
     * @param trains is the array containing the number of spaces each
     * path is
     * @param locomotives is the array containing the number of 
     * locomotives required for each path
     * @param color is the array containing the color each path is
     * @param scotland is the array containing whether each path 
     * requires the scotland concession or not
     * @param locomotives is the array containing whether each path 
     * requires the ireland concession or not
     * @param color is the array containing whether each path requires 
     * the wales concession or not
     */
    public void fillNeigh(String [] Arr, int size, int city, int[] trains,
    int[] locomotives, Color[] color, boolean[] scotland,
    boolean[] ireland, boolean[] wales)
    {
        for(int i = 0; i < size; i++)
        {
            cityList[city].nextTown[i].name = Arr[i];
            cityList[city].nextTown[i].nTrains = trains[i];            
            cityList[city].nextTown[i].pathColor = color[i];
            cityList[city].nextTown[i].nLocomotives = locomotives[i];
            cityList[city].nextTown[i].nScotland = scotland[i];
            cityList[city].nextTown[i].nIreland = ireland[i];
            cityList[city].nextTown[i].nWales = wales[i];
        }// end for
    }// end fillNeigh

    /**
     * addPath takes in two city strings and decides whether
     * the current player
     * buys that path or not
     * @param one is name of first city that comprises the path in question
     * @param two is name of second city that comprises the path in question
     * @param p the player trying to buy the path
     * @param discards the collection of discarded train cards
     * 
     * @return whether the player can buy the path or not
     * true if they can, false otherwise
     */
    protected boolean addPath(String one, String two, Player p,
    ArrayList<String> discards)
    {
        int city1 = citySwitch(one);  
        int city2 = citySwitch(two); 
        boolean isPath1 = false;
        boolean isPath2 = false; 
        int index2 = -1;
        boolean firstOwned = false;
        // coordinates for cities are stored in two 2-D arrays
        int [] coord1 = coordSwitch(one);
        int [] coord2 = coordSwitch(two);

        // if city doesn't exist in game, return control
        if(city1 == -1 | city2 == -1)return false;

        for(int i = 0; i < cityList[city1].nextTown.length; i++)
        {
            if(cityList[city1].nextTown[i].name.equals(two))
            {
                if(cityList[city1].nextTown[i].ownedBy != null)
                    firstOwned = true;
                cityList[city1].nextTown[i].ownedBy = p;
                isPath1 = true;
                index2 = i;
                i = 99;
                continue;
            }// end if
        }// end for

        for(int i = 0; i < cityList[city2].nextTown.length; i++)
        {
            if(cityList[city2].nextTown[i].name.equals(one))
            {
                if(cityList[city2].nextTown[i].ownedBy != null && firstOwned)
                    return false;
                cityList[city2].nextTown[i].ownedBy = p;
                isPath2 = true;
                i = 99;
                continue;
            }// end if
        }// end for
        if(isPath1 && isPath2){
            if (cityList[city1].nextTown[index2].nTrains > p.numTrainsLeft){
                JOptionPane.showMessageDialog(null,
                    "You don't have enough trains left to buy this route");
                return false;
            }
            if(cityList[city1].nextTown[index2].nTrains > 3 &&
            cityList[city1].nextTown[index2].nTrains < 7 &&
            !p.tech.superHeated) {
                JOptionPane.showMessageDialog(null, 
                    "Must have super heated steam boiler technology "+
                    "for this route");
                return false;
            }
            if (cityList[city1].nextTown[index2].nTrains == 3 &&
            !p.tech.mechanicalStoker){
                JOptionPane.showMessageDialog(null,
                    "Must have mechanical stoker technology to buy this "
                    +"route");
                return false;
            }
            if (cityList[city1].nextTown[index2].nLocomotives > 0 &&
            !p.tech.propellers && !one.equals("New York") &&
            !two.equals("New York")){
                JOptionPane.showMessageDialog(null,
                    "Must have propellers technology to buy this route");
                return false;
            }
            if (cityList[city1].nextTown[index2].nLocomotives >
            p.trainCards[8]){
                JOptionPane.showMessageDialog(null, 
                    "Must have " +
                    (cityList[city1].nextTown[index2].nLocomotives-
                        p.trainCards[8]) + ""+
                        " more locomotives to buy this route");
                return false;
            }
            if (cityList[city1].nextTown[index2].nScotland &&
            !p.tech.ScotlandCon){
                JOptionPane.showMessageDialog(null,
                    "Must have Scotland concession to buy this route");
                return false;
            }
            if (cityList[city1].nextTown[index2].nWales &&
            !p.tech.walesCon){
                JOptionPane.showMessageDialog(null,
                    "Must have Wales concession to buy this route");
                return false;
            }
            if (cityList[city1].nextTown[index2].nIreland &&
            !p.tech.irelandFranceCon){
                JOptionPane.showMessageDialog(null,
                    "Must have Ireland/France concession to buy this route");
                return false;
            }
            if (!checkNumTrains(city1, index2, p)) return false;
            pathList[numPaths][0] = coord1[0];
            pathList[numPaths][1] = coord1[1];
            pathList[numPaths][2] = coord2[0];
            pathList[numPaths][3] = coord2[1];

            pathList[numPaths][4] = city1;
            pathList[numPaths][5] = city2;

            // increment number of paths
            numPaths++;
            //Remove trains from player 
            p.numTrainsLeft -= cityList[city1].nextTown[index2].nTrains;
            //Remove locomotive cards from player
            p.trainCards[8]-=cityList[city1].nextTown[index2].nLocomotives;
            //Handle synthesized locomotives vs real ones for discard
            for (int i = 0; i<cityList[city1].nextTown[index2].nLocomotives;
            i++)
                if (p.extraR >0)
                    p.extraR--;
                else
                    discards.add("rainbow");
            //Puts cards in discard pile
            removeCards(city1, index2, p, discards);
            //Adds extra point for boiler tech
            if(p.tech.boiler)
                p.addPoints(1);
            //If steamTurbine and locomotives on route, add 2 points
            if(p.tech.steamTurbine && 
            cityList[city1].nextTown[index2].nLocomotives > 0){
                p.addPoints(2);
            }
            //Add rest of points for the route to player
            //Handle proper route scoring
            if(cityList[city1].nextTown[index2].nTrains == 3)
                p.addPoints(4);
            else if(cityList[city1].nextTown[index2].nTrains == 4)
                p.addPoints(7);
            else if(cityList[city1].nextTown[index2].nTrains == 5)
                p.addPoints(10);
            else if(cityList[city1].nextTown[index2].nTrains == 6)
                p.addPoints(15);
            else if(city1 == 48 || city2 == 48)
                p.addPoints(40);
            else 
                p.addPoints(cityList[city1].nextTown[index2].nTrains);
            return true;
        }

        return false;
    }    

    /**
     * when a player can buy a path they have chosen
     * prompts them for which cards to use to buy it
     * 
     * @param one is name of first city that comprises the path in question
     * @param two is name of second city that comprises the path in question
     * @param p the player trying to buy the path
     * @param discards the collection of discarded train cards 
     * 
     */
    public void removeCards(int city1, int index2, Player p,
    ArrayList<String> discards){
        int tempnTrains = 
            cityList[city1].nextTown[index2].nTrains -
            cityList[city1].nextTown[index2].nLocomotives;
        if (cityList[city1].nextTown[index2].pathColor.equals(Color.RED)){
            JFrame chooseCard = new JFrame("Choose cards to use");
            String[] possibilities = new String[p.trainCards[8]+
                    p.trainCards[0]];
            for (int i = 0; i<p.trainCards[0]; i++){
                possibilities[i] = "red";
            }
            for (int i = p.trainCards[0]; i<p.trainCards[0]+
            p.trainCards[8]; i++){
                possibilities[i] = "locomotive";
            }
            ImageIcon im = new ImageIcon();
            for (int i = 0; i<tempnTrains; i++){  
                String s = (String)JOptionPane.showInputDialog(chooseCard,
                        "choose a card to discard", "Choose a card",
                        JOptionPane.PLAIN_MESSAGE,im, possibilities,"red");
                while(s == null)
                    s = (String)JOptionPane.showInputDialog(chooseCard,
                        "choose a card to discard", "Choose a card",
                        JOptionPane.PLAIN_MESSAGE,im, possibilities,"red");
                if (s.equals("red")) {
                    p.trainCards[0]--;
                    discards.add("red");
                    String[] nPossibilities =
                        new String[possibilities.length-1];
                    for (int j = 1; j<possibilities.length; j++)
                        nPossibilities[j-1] = possibilities[j];
                    possibilities = nPossibilities;
                }
                else if (s.equals("locomotive")) {
                    p.trainCards[8]--;
                    if (p.extraR >0)
                        p.extraR--;
                    else
                        discards.add("rainbow");
                    String[] nPossibilities =
                        new String[possibilities.length-1];
                    for (int j = 0; j<possibilities.length-1; j++)
                        nPossibilities[j] = possibilities[j];
                    possibilities = nPossibilities;                    
                }
            }
        }
        if (cityList[city1].nextTown[index2].pathColor.equals(Color.BLUE)){
            JFrame chooseCard = new JFrame("Choose cards to use");
            String[] possibilities = new String[p.trainCards[8]+
                    p.trainCards[1]];
            for (int i = 0; i<p.trainCards[1]; i++){
                possibilities[i] = "blue";
            }
            for (int i = p.trainCards[1]; i<p.trainCards[1]+
            p.trainCards[8]; i++){
                possibilities[i] = "locomotive";
            }
            ImageIcon im = new ImageIcon();
            for (int i = 0; i<tempnTrains; i++){  
                String s = (String)JOptionPane.showInputDialog(chooseCard,
                        "choose a card to discard", "Choose a card",
                        JOptionPane.PLAIN_MESSAGE,im, possibilities,"blue");
                while(s == null)
                    s = (String)JOptionPane.showInputDialog(chooseCard,
                        "choose a card to discard", "Choose a card",
                        JOptionPane.PLAIN_MESSAGE,im, possibilities,"blue");
                if (s.equals("blue")) {
                    p.trainCards[1]--;
                    discards.add("blue");
                    String[] nPossibilities =
                        new String[possibilities.length-1];
                    for (int j = 1; j<possibilities.length; j++)
                        nPossibilities[j-1] = possibilities[j];
                    possibilities = nPossibilities;
                }
                else if (s.equals("locomotive")) {
                    p.trainCards[8]--;
                    if (p.extraR >0)
                        p.extraR--;
                    else
                        discards.add("rainbow");
                    String[] nPossibilities =
                        new String[possibilities.length-1];
                    for (int j = 0; j<possibilities.length-1; j++)
                        nPossibilities[j] = possibilities[j];
                    possibilities = nPossibilities;
                }
            }
        }
        if (cityList[city1].nextTown[index2].pathColor.equals(Color.YELLOW)){
            JFrame chooseCard = new JFrame("Choose cards to use");
            String[] possibilities = new String[p.trainCards[8]+
                    p.trainCards[2]];
            for (int i = 0; i<p.trainCards[2]; i++){
                possibilities[i] = "yellow";
            }
            for (int i = p.trainCards[2]; i<p.trainCards[2]+
            p.trainCards[8]; i++){
                possibilities[i] = "locomotive";
            }
            ImageIcon im = new ImageIcon();
            for (int i = 0; i<tempnTrains; i++){  
                String s = (String)JOptionPane.showInputDialog(chooseCard,
                        "choose a card to discard", "Choose a card",
                        JOptionPane.PLAIN_MESSAGE,im, possibilities,"yellow");
                while(s == null)
                    s = (String)JOptionPane.showInputDialog(chooseCard,
                        "choose a card to discard", "Choose a card",
                        JOptionPane.PLAIN_MESSAGE,im, possibilities,"yellow");
                if (s.equals("yellow")) {
                    p.trainCards[2]--;
                    discards.add("yellow");
                    String[] nPossibilities =
                        new String[possibilities.length-1];
                    for (int j = 1; j<possibilities.length; j++)
                        nPossibilities[j-1] = possibilities[j];
                    possibilities = nPossibilities;
                }
                else if (s.equals("locomotive")) {
                    p.trainCards[8]--;
                    if (p.extraR >0)
                        p.extraR--;
                    else
                        discards.add("rainbow");
                    String[] nPossibilities =
                        new String[possibilities.length-1];
                    for (int j = 0; j<possibilities.length-1; j++)
                        nPossibilities[j] = possibilities[j];
                    possibilities = nPossibilities;                    
                }
            }
        }
        if (cityList[city1].nextTown[index2].pathColor.equals(Color.GREEN)){
            JFrame chooseCard = new JFrame("Choose cards to use");
            String[] possibilities = new String[p.trainCards[8]+
                    p.trainCards[3]];
            for (int i = 0; i<p.trainCards[3]; i++){
                possibilities[i] = "green";
            }
            for (int i = p.trainCards[3]; i<p.trainCards[3]+
            p.trainCards[8]; i++){
                possibilities[i] = "locomotive";
            }
            ImageIcon im = new ImageIcon();
            for (int i = 0; i<tempnTrains; i++){  
                String s = (String)JOptionPane.showInputDialog(chooseCard,
                        "choose a card to discard", "Choose a card",
                        JOptionPane.PLAIN_MESSAGE,im, possibilities,"green");
                while(s == null)
                    s = (String)JOptionPane.showInputDialog(chooseCard,
                        "choose a card to discard", "Choose a card",
                        JOptionPane.PLAIN_MESSAGE,im, possibilities,"green");
                if (s.equals("green")) {
                    p.trainCards[3]--;
                    discards.add("green");
                    String[] nPossibilities =
                        new String[possibilities.length-1];
                    for (int j = 1; j<possibilities.length; j++)
                        nPossibilities[j-1] = possibilities[j];
                    possibilities = nPossibilities;
                }
                else if (s.equals("locomotive")) {
                    p.trainCards[8]--;
                    if (p.extraR >0)
                        p.extraR--;
                    else
                        discards.add("rainbow");
                    String[] nPossibilities =
                        new String[possibilities.length-1];
                    for (int j = 0; j<possibilities.length-1; j++)
                        nPossibilities[j] = possibilities[j];
                    possibilities = nPossibilities;
                }
            }
        }
        if (cityList[city1].nextTown[index2].pathColor.equals(Color.ORANGE)){
            JFrame chooseCard = new JFrame("Choose cards to use");
            String[] possibilities = new String[p.trainCards[8]+
                    p.trainCards[4]];
            for (int i = 0; i<p.trainCards[4]; i++){
                possibilities[i] = "orange";
            }
            for (int i = p.trainCards[4]; i<p.trainCards[4]+
            p.trainCards[8]; i++){
                possibilities[i] = "locomotive";
            }
            ImageIcon im = new ImageIcon();
            for (int i = 0; i<tempnTrains; i++){  
                String s = (String)JOptionPane.showInputDialog(chooseCard,
                        "choose a card to discard", "Choose a card",
                        JOptionPane.PLAIN_MESSAGE,im, possibilities,"orange");
                while(s == null)
                    s = (String)JOptionPane.showInputDialog(chooseCard,
                        "choose a card to discard", "Choose a card",
                        JOptionPane.PLAIN_MESSAGE,im, possibilities,"orange");
                if (s.equals("orange")) {
                    p.trainCards[4]--;
                    discards.add("orange");
                    String[] nPossibilities =
                        new String[possibilities.length-1];
                    for (int j = 1; j<possibilities.length; j++)
                        nPossibilities[j-1] = possibilities[j];
                    possibilities = nPossibilities;
                }
                else if (s.equals("locomotive")) {
                    p.trainCards[8]--;
                    if (p.extraR >0)
                        p.extraR--;
                    else
                        discards.add("rainbow");
                    String[] nPossibilities =
                        new String[possibilities.length-1];
                    for (int j = 0; j<possibilities.length-1; j++)
                        nPossibilities[j] = possibilities[j];
                    possibilities = nPossibilities;                    
                }
            }
        }
        if (cityList[city1].nextTown[index2].pathColor.equals(Color.BLACK)){
            JFrame chooseCard = new JFrame("Choose cards to use");
            String[] possibilities = new String[p.trainCards[8]+
                    p.trainCards[6]];
            for (int i = 0; i<p.trainCards[6]; i++){
                possibilities[i] = "black";
            }
            for (int i = p.trainCards[6]; i<p.trainCards[6]+
            p.trainCards[8]; i++){
                possibilities[i] = "locomotive";
            }
            ImageIcon im = new ImageIcon();
            for (int i = 0; i<tempnTrains; i++){  
                String s = (String)JOptionPane.showInputDialog(chooseCard,
                        "choose a card to discard", "Choose a card",
                        JOptionPane.PLAIN_MESSAGE,im, possibilities,"black");
                while(s == null)
                    s = (String)JOptionPane.showInputDialog(chooseCard,
                        "choose a card to discard", "Choose a card",
                        JOptionPane.PLAIN_MESSAGE,im, possibilities,"black");
                if (s.equals("black")) {
                    p.trainCards[6]--;
                    discards.add("black");
                    String[] nPossibilities =
                        new String[possibilities.length-1];
                    for (int j = 1; j<possibilities.length; j++)
                        nPossibilities[j-1] = possibilities[j];
                    possibilities = nPossibilities;
                }
                else if (s.equals("locomotive")) {
                    p.trainCards[8]--;
                    if (p.extraR >0)
                        p.extraR--;
                    else
                        discards.add("rainbow");
                    String[] nPossibilities =
                        new String[possibilities.length-1];
                    for (int j = 0; j<possibilities.length-1; j++)
                        nPossibilities[j] = possibilities[j];
                    possibilities = nPossibilities;
                }
            }
        }
        if (cityList[city1].nextTown[index2].pathColor.equals(Color.WHITE)){
            JFrame chooseCard = new JFrame("Choose cards to use");
            String[] possibilities = new String[p.trainCards[8]+
                    p.trainCards[7]];
            for (int i = 0; i<p.trainCards[7]; i++){
                possibilities[i] = "white";
            }
            for (int i = p.trainCards[7]; i<p.trainCards[7]+
            p.trainCards[8]; i++){
                possibilities[i] = "locomotive";
            }
            ImageIcon im = new ImageIcon();
            for (int i = 0; i<tempnTrains; i++){  
                String s = (String)JOptionPane.showInputDialog(chooseCard,
                        "choose a card to discard", "Choose a card",
                        JOptionPane.PLAIN_MESSAGE,im, possibilities,"white");
                while(s == null)
                    s = (String)JOptionPane.showInputDialog(chooseCard,
                        "choose a card to discard", "Choose a card",
                        JOptionPane.PLAIN_MESSAGE,im, possibilities,"white");
                if (s.equals("white")) {
                    p.trainCards[7]--;
                    discards.add("white");
                    String[] nPossibilities =
                        new String[possibilities.length-1];
                    for (int j = 1; j<possibilities.length; j++)
                        nPossibilities[j-1] = possibilities[j];
                    possibilities = nPossibilities;
                }
                else if (s.equals("locomotive")) {
                    p.trainCards[8]--;
                    if (p.extraR >0)
                        p.extraR--;
                    else
                        discards.add("rainbow");
                    String[] nPossibilities =
                        new String[possibilities.length-1];
                    for (int j = 0; j<possibilities.length-1; j++)
                        nPossibilities[j] = possibilities[j];
                    possibilities = nPossibilities;                    
                }
            }
        }
        if (cityList[city1].nextTown[index2].pathColor.equals(Color.PINK)){
            JFrame chooseCard = new JFrame("Choose cards to use");
            String[] possibilities = new String[p.trainCards[8]+
                    p.trainCards[5]];
            for (int i = 0; i<p.trainCards[5]; i++){
                possibilities[i] = "pink";
            }
            for (int i = p.trainCards[5]; i<p.trainCards[5]+p.trainCards[8];
            i++){
                possibilities[i] = "locomotive";
            }
            ImageIcon im = new ImageIcon();
            for (int i = 0; i<tempnTrains; i++){  
                String s = (String)JOptionPane.showInputDialog(chooseCard,
                        "choose a card to discard", "Choose a card",
                        JOptionPane.PLAIN_MESSAGE,im, possibilities,"pink");
                while(s == null)
                    s = (String)JOptionPane.showInputDialog(chooseCard,
                        "choose a card to discard", "Choose a card",
                        JOptionPane.PLAIN_MESSAGE,im, possibilities,"pink");
                if (s.equals("pink")) {
                    p.trainCards[5]--;
                    discards.add("pink");
                    String[] nPossibilities =
                        new String[possibilities.length-1];
                    for (int j = 1; j<possibilities.length; j++)
                        nPossibilities[j-1] = possibilities[j];
                    possibilities = nPossibilities;
                }
                else if (s.equals("locomotive")) {
                    p.trainCards[8]--;
                    if (p.extraR >0)
                        p.extraR--;
                    else
                        discards.add("rainbow");
                    String[] nPossibilities =
                        new String[possibilities.length-1];
                    for (int j = 0; j<possibilities.length-1; j++)
                        nPossibilities[j] = possibilities[j];
                    possibilities = nPossibilities;
                }
            }
        }
        if (cityList[city1].nextTown[index2].pathColor.equals(Color.GRAY)){
            ArrayList<String> choices = new ArrayList<String>();

            JFrame chooseCard = new JFrame("Choose color to use");
            for (int i = 0; i < 8; i++){
                if(p.trainCards[i]+p.trainCards[8] >= tempnTrains){
                    if (i == 0)
                        choices.add("red");
                    if (i == 1)
                        choices.add("blue");
                    if (i == 2)
                        choices.add("yellow");
                    if (i == 3)
                        choices.add("green");
                    if (i == 4)
                        choices.add("orange");
                    if (i == 5)
                        choices.add("pink");
                    if (i == 6)
                        choices.add("black");
                    if (i == 7)
                        choices.add("white");
                }
            }   
            String[] ch = new String[choices.size()];
            for (int i = 0; i < choices.size(); i++){
                ch[i] = choices.get(i);
            }
            String s = (String)JOptionPane.showInputDialog(chooseCard,
                    "choose the color of cards to use",
                    "Choose color", JOptionPane.PLAIN_MESSAGE,null,
                    ch, choices.get(0));
            while(s == null)
                s = (String)JOptionPane.showInputDialog(chooseCard,
                    "choose the color of cards to use", "Choose color",
                    JOptionPane.PLAIN_MESSAGE,null, ch, choices.get(0));
            if (s.equals("red"))
                removeGray(city1, index2, p, discards, "red");
            if (s.equals("blue"))
                removeGray(city1, index2, p, discards, "blue");
            if (s.equals("yellow"))
                removeGray(city1, index2, p, discards, "yellow");
            if (s.equals("green"))
                removeGray(city1, index2, p, discards, "green");
            if (s.equals("orange"))
                removeGray(city1, index2, p, discards, "orange");
            if (s.equals("pink"))
                removeGray(city1, index2, p, discards, "pink");
            if (s.equals("black"))
                removeGray(city1, index2, p, discards, "black");
            if (s.equals("white"))
                removeGray(city1, index2, p, discards, "white");

        }
    }

    /**
     * when a player can buy a gray path they have chosen
     * prompts them for which cards to use to buy it
     * 
     * @param one is name of first city that comprises the path in
     * question
     * @param two is name of second city that comprises the path in
     * question
     * @param p the player trying to buy the path
     * @param discards the collection of discarded train cards 
     * 
     */
    public void removeGray(int city1, int index2, Player p,
    ArrayList<String> discards, String color){
        int tempnTrains =
            cityList[city1].nextTown[index2].nTrains -
            cityList[city1].nextTown[index2].nLocomotives;
        if (color.equals("red")){
            JFrame chooseCard = new JFrame("Choose cards to use");
            String[] possibilities = new String[p.trainCards[8]+
                    p.trainCards[0]];
            for (int i = 0; i<p.trainCards[0]; i++){
                possibilities[i] = "red";
            }
            for (int i = p.trainCards[0]; i<p.trainCards[0]+
            p.trainCards[8]; i++){
                possibilities[i] = "locomotive";
            }
            ImageIcon im = new ImageIcon();
            for (int i = 0; i<tempnTrains; i++){  
                String s = (String)JOptionPane.showInputDialog(chooseCard,
                        "choose a card to discard", "Choose a card",
                        JOptionPane.PLAIN_MESSAGE,im, possibilities,"red");
                while(s == null)
                    s = (String)JOptionPane.showInputDialog(chooseCard,
                        "choose a card to discard", "Choose a card",
                        JOptionPane.PLAIN_MESSAGE,im, possibilities,"red");
                if (s.equals("red")) {
                    p.trainCards[0]--;
                    discards.add("red");
                    String[] nPossibilities =
                        new String[possibilities.length-1];
                    for (int j = 1; j<possibilities.length; j++)
                        nPossibilities[j-1] = possibilities[j];
                    possibilities = nPossibilities;
                }
                else if (s.equals("locomotive")) {
                    p.trainCards[8]--;
                    if (p.extraR >0)
                        p.extraR--;
                    else
                        discards.add("rainbow");
                    String[] nPossibilities =
                        new String[possibilities.length-1];
                    for (int j = 0; j<possibilities.length-1; j++)
                        nPossibilities[j] = possibilities[j];
                    possibilities = nPossibilities;                    
                }
            }
        }
        if (color.equals("blue")){
            JFrame chooseCard = new JFrame("Choose cards to use");
            String[] possibilities =
                new String[p.trainCards[8]+p.trainCards[1]];
            for (int i = 0; i<p.trainCards[1]; i++){
                possibilities[i] = "blue";
            }
            for (int i = p.trainCards[1]; i<p.trainCards[1]+
            p.trainCards[8]; i++){
                possibilities[i] = "locomotive";
            }
            ImageIcon im = new ImageIcon();
            for (int i = 0; i<tempnTrains; i++){  
                String s = (String)JOptionPane.showInputDialog(chooseCard,
                        "choose a card to discard", "Choose a card", 
                        JOptionPane.PLAIN_MESSAGE,im, possibilities,"blue");
                while(s == null)
                    s = (String)JOptionPane.showInputDialog(chooseCard,
                        "choose a card to discard", "Choose a card",
                        JOptionPane.PLAIN_MESSAGE,im, possibilities,"blue");
                if (s.equals("blue")) {
                    p.trainCards[1]--;
                    discards.add("blue");
                    String[] nPossibilities =
                        new String[possibilities.length-1];
                    for (int j = 1; j<possibilities.length; j++)
                        nPossibilities[j-1] = possibilities[j];
                    possibilities = nPossibilities;
                }
                else if (s.equals("locomotive")) {
                    p.trainCards[8]--;
                    if (p.extraR >0)
                        p.extraR--;
                    else
                        discards.add("rainbow");
                    String[] nPossibilities =
                        new String[possibilities.length-1];
                    for (int j = 0; j<possibilities.length-1; j++)
                        nPossibilities[j] = possibilities[j];
                    possibilities = nPossibilities;
                }
            }
        }
        if (color.equals("yellow")){
            JFrame chooseCard = new JFrame("Choose cards to use");
            String[] possibilities = new String[p.trainCards[8]+
                    p.trainCards[2]];
            for (int i = 0; i<p.trainCards[2]; i++){
                possibilities[i] = "yellow";
            }
            for (int i = p.trainCards[2]; i<p.trainCards[2]+
            p.trainCards[8]; i++){
                possibilities[i] = "locomotive";
            }
            ImageIcon im = new ImageIcon();
            for (int i = 0; i<tempnTrains; i++){  
                String s = (String)JOptionPane.showInputDialog(chooseCard,
                        "choose a card to discard", "Choose a card",
                        JOptionPane.PLAIN_MESSAGE,im, possibilities,"yellow");
                while(s == null)
                    s = (String)JOptionPane.showInputDialog(chooseCard,
                        "choose a card to discard", "Choose a card",
                        JOptionPane.PLAIN_MESSAGE,im, possibilities,"yellow");
                if (s.equals("yellow")) {
                    p.trainCards[2]--;
                    discards.add("yellow");
                    String[] nPossibilities =
                        new String[possibilities.length-1];
                    for (int j = 1; j<possibilities.length; j++)
                        nPossibilities[j-1] = possibilities[j];
                    possibilities = nPossibilities;
                }
                else if (s.equals("locomotive")) {
                    p.trainCards[8]--;
                    if (p.extraR >0)
                        p.extraR--;
                    else
                        discards.add("rainbow");
                    String[] nPossibilities =
                        new String[possibilities.length-1];
                    for (int j = 0; j<possibilities.length-1; j++)
                        nPossibilities[j] = possibilities[j];
                    possibilities = nPossibilities;                    
                }
            }
        }
        if (color.equals("green")){
            JFrame chooseCard = new JFrame("Choose cards to use");
            String[] possibilities = new String[p.trainCards[8]+
                    p.trainCards[3]];
            for (int i = 0; i<p.trainCards[3]; i++){
                possibilities[i] = "green";
            }
            for (int i = p.trainCards[3]; i<p.trainCards[3]+p.trainCards[8];
            i++){
                possibilities[i] = "locomotive";
            }
            ImageIcon im = new ImageIcon();
            for (int i = 0; i<tempnTrains; i++){  
                String s = (String)JOptionPane.showInputDialog(chooseCard,
                        "choose a card to discard", "Choose a card",
                        JOptionPane.PLAIN_MESSAGE,im, possibilities,"green");
                while(s == null)
                    s = (String)JOptionPane.showInputDialog(chooseCard,
                        "choose a card to discard", "Choose a card",
                        JOptionPane.PLAIN_MESSAGE,im, possibilities,"green");
                if (s.equals("green")) {
                    p.trainCards[3]--;
                    discards.add("green");
                    String[] nPossibilities =
                        new String[possibilities.length-1];
                    for (int j = 1; j<possibilities.length; j++)
                        nPossibilities[j-1] = possibilities[j];
                    possibilities = nPossibilities;
                }
                else if (s.equals("locomotive")) {
                    p.trainCards[8]--;
                    if (p.extraR >0)
                        p.extraR--;
                    else
                        discards.add("rainbow");
                    String[] nPossibilities =
                        new String[possibilities.length-1];
                    for (int j = 0; j<possibilities.length-1; j++)
                        nPossibilities[j] = possibilities[j];
                    possibilities = nPossibilities;
                }
            }
        }
        if (color.equals("orange")){
            JFrame chooseCard = new JFrame("Choose cards to use");
            String[] possibilities = new String[p.trainCards[8]+
                    p.trainCards[4]];
            for (int i = 0; i<p.trainCards[4]; i++){
                possibilities[i] = "orange";
            }
            for (int i = p.trainCards[4]; i<p.trainCards[4]+
            p.trainCards[8]; i++){
                possibilities[i] = "locomotive";
            }
            ImageIcon im = new ImageIcon();
            for (int i = 0; i<tempnTrains; i++){  
                String s = (String)JOptionPane.showInputDialog(chooseCard,
                        "choose a card to discard", "Choose a card",
                        JOptionPane.PLAIN_MESSAGE,im, possibilities,"orange");
                while(s == null)
                    s = (String)JOptionPane.showInputDialog(chooseCard,
                        "choose a card to discard", "Choose a card",
                        JOptionPane.PLAIN_MESSAGE,im, possibilities,"orange");
                if (s.equals("orange")) {
                    p.trainCards[4]--;
                    discards.add("orange");
                    String[] nPossibilities =
                        new String[possibilities.length-1];
                    for (int j = 1; j<possibilities.length; j++)
                        nPossibilities[j-1] = possibilities[j];
                    possibilities = nPossibilities;
                }
                else if (s.equals("locomotive")) {
                    p.trainCards[8]--;
                    if (p.extraR >0)
                        p.extraR--;
                    else
                        discards.add("rainbow");
                    String[] nPossibilities =
                        new String[possibilities.length-1];
                    for (int j = 0; j<possibilities.length-1; j++)
                        nPossibilities[j] = possibilities[j];
                    possibilities = nPossibilities;                    
                }
            }
        }
        if (color.equals("black")){
            JFrame chooseCard = new JFrame("Choose cards to use");
            String[] possibilities = new String[p.trainCards[8]+
                    p.trainCards[6]];
            for (int i = 0; i<p.trainCards[6]; i++){
                possibilities[i] = "black";
            }
            for (int i = p.trainCards[6]; i<p.trainCards[6]+
            p.trainCards[8]; i++){
                possibilities[i] = "locomotive";
            }
            ImageIcon im = new ImageIcon();
            for (int i = 0; i<tempnTrains; i++){  
                String s = (String)JOptionPane.showInputDialog(chooseCard,
                        "choose a card to discard", "Choose a card",
                        JOptionPane.PLAIN_MESSAGE,im, possibilities,"black");
                while(s == null)
                    s = (String)JOptionPane.showInputDialog(chooseCard,
                        "choose a card to discard", "Choose a card",
                        JOptionPane.PLAIN_MESSAGE,im, possibilities,"black");
                if (s.equals("black")) {
                    p.trainCards[6]--;
                    discards.add("black");
                    String[] nPossibilities =
                        new String[possibilities.length-1];
                    for (int j = 1; j<possibilities.length; j++)
                        nPossibilities[j-1] = possibilities[j];
                    possibilities = nPossibilities;
                }
                else if (s.equals("locomotive")) {
                    p.trainCards[8]--;
                    if (p.extraR >0)
                        p.extraR--;
                    else
                        discards.add("rainbow");
                    String[] nPossibilities =
                        new String[possibilities.length-1];
                    for (int j = 0; j<possibilities.length-1; j++)
                        nPossibilities[j] = possibilities[j];
                    possibilities = nPossibilities;
                }
            }
        }
        if (color.equals("white")){
            JFrame chooseCard = new JFrame("Choose cards to use");
            String[] possibilities = new String[p.trainCards[8]+
                    p.trainCards[7]];
            for (int i = 0; i<p.trainCards[7]; i++){
                possibilities[i] = "white";
            }
            for (int i = p.trainCards[7]; i<p.trainCards[7]+p.trainCards[8];
            i++){
                possibilities[i] = "locomotive";
            }
            ImageIcon im = new ImageIcon();
            for (int i = 0; i<tempnTrains; i++){  
                String s = (String)JOptionPane.showInputDialog(chooseCard,
                        "choose a card to discard", "Choose a card",
                        JOptionPane.PLAIN_MESSAGE,im, possibilities,"white");
                while(s == null)
                    s = (String)JOptionPane.showInputDialog(chooseCard,
                        "choose a card to discard", "Choose a card",
                        JOptionPane.PLAIN_MESSAGE,im, possibilities,"white");
                if (s.equals("white")) {
                    p.trainCards[7]--;
                    discards.add("white");
                    String[] nPossibilities =
                        new String[possibilities.length-1];
                    for (int j = 1; j<possibilities.length; j++)
                        nPossibilities[j-1] = possibilities[j];
                    possibilities = nPossibilities;
                }
                else if (s.equals("locomotive")) {
                    p.trainCards[8]--;
                    if (p.extraR >0)
                        p.extraR--;
                    else
                        discards.add("rainbow");
                    String[] nPossibilities =
                        new String[possibilities.length-1];
                    for (int j = 0; j<possibilities.length-1; j++)
                        nPossibilities[j] = possibilities[j];
                    possibilities = nPossibilities;                    
                }
            }
        }
        if (color.equals("pink")){
            JFrame chooseCard = new JFrame("Choose cards to use");
            String[] possibilities = new String[p.trainCards[8]+
                    p.trainCards[5]];
            for (int i = 0; i<p.trainCards[5]; i++){
                possibilities[i] = "pink";
            }
            for (int i = p.trainCards[5]; i<p.trainCards[5]+
            p.trainCards[8]; i++){
                possibilities[i] = "locomotive";
            }
            ImageIcon im = new ImageIcon();
            for (int i = 0; i<tempnTrains; i++){  
                String s = (String)JOptionPane.showInputDialog(chooseCard,
                        "choose a card to discard", "Choose a card",
                        JOptionPane.PLAIN_MESSAGE,im, possibilities,"pink");
                while(s == null)
                    s = (String)JOptionPane.showInputDialog(chooseCard,
                        "choose a card to discard", "Choose a card",
                        JOptionPane.PLAIN_MESSAGE,im, possibilities,"pink");
                if (s.equals("pink")) {
                    p.trainCards[5]--;
                    discards.add("pink");
                    String[] nPossibilities =
                        new String[possibilities.length-1];
                    for (int j = 1; j<possibilities.length; j++)
                        nPossibilities[j-1] = possibilities[j];
                    possibilities = nPossibilities;
                }
                else if (s.equals("locomotive")) {
                    p.trainCards[8]--;
                    if (p.extraR >0)
                        p.extraR--;
                    else
                        discards.add("rainbow");
                    String[] nPossibilities =
                        new String[possibilities.length-1];
                    for (int j = 0; j<possibilities.length-1; j++)
                        nPossibilities[j] = possibilities[j];
                    possibilities = nPossibilities;
                }
            }
        }
    }

    /**
     * getNeigh finds the Node of a neighbor in a particular CityNode
     * @param city1 is the CityNode index whose neighbor is being sought
     * @param city2 is the integer value associated with the neighbor
     * @return is the neighborNode inside city1's CityNode
     */
    public CityNode.NeighborNode getNeigh(int city1, int city2)
    {
        CityNode.NeighborNode neighbor;

        int index = findNeighbor(city1, city2);

        // if index is not found, attempt to find in other direction
        if(index == -1)
        {
            index = findNeighbor(city2, city1);
        }// end if

        // if index is still not found, return null 
        //handle error elsewhere <---
        if(index == -1)
        {
            return null; 
        }// end if

        neighbor = cityList[city1].nextTown[index];

        return neighbor;
    }// end getPlayer

    /**
     * findNeighbor finds the index of a neighbor in a particular CityNode
     * @param city1 is the CityNode index whose neighbor is being sought
     * @param city2 is the integer value associated with the neighbor
     * @return is the index of the neighborNode inside city1's CityNode
     */
    public int findNeighbor(int city1, int city2)
    {
        for (int i = 0; i < cityList[city1].nextTown.length; i++)
        {
            if(cityList[city1].nextTown[i].name == cityList[city2].name)
                return i;
        }// end for

        return -1;
    }// end findNeighbor

    /**
     * checks whether the player has enough 
     * train cards of the right typr to buy this route
     * @param city1 int that represents the first city in the path
     * @param city2 int that represents the second city in the path
     * @param p the player trying to buy the path
     * 
     * @return whether the player has the right cards for the path
     * true if they do, false otherwise
     */
    public boolean checkNumTrains(int city1, int index2, Player p){
        if (cityList[city1].nextTown[index2].pathColor.equals(Color.RED) &&
        p.trainCards[0]+p.trainCards[8] <
        cityList[city1].nextTown[index2].nTrains){
            JOptionPane.showMessageDialog(null, "Must have "+
                (cityList[city1].nextTown[index2].nTrains-p.trainCards[0]) +
                ""+
                " more red cards or sufficient "+
                "locomotives to buy this route");
            return false;
        }
        if (cityList[city1].nextTown[index2].pathColor.equals(Color.BLUE)&&
        p.trainCards[1]+p.trainCards[8] <
        cityList[city1].nextTown[index2].nTrains){
            JOptionPane.showMessageDialog(null, "Must have " +
                (cityList[city1].nextTown[index2].nTrains-p.trainCards[1])+ 
                ""+ " more blue cards or sufficient "+
                "locomotives to buy this route");
            return false;
        }
        if (cityList[city1].nextTown[index2].pathColor.equals(Color.YELLOW)&&
        p.trainCards[2]+p.trainCards[8] <
        cityList[city1].nextTown[index2].nTrains){
            JOptionPane.showMessageDialog(null, "Must have " +
                (cityList[city1].nextTown[index2].nTrains-p.trainCards[2]) +
                ""+ " more yellow cards or sufficient locomotives "+
                "to buy this route");
            return false;
        }
        if (cityList[city1].nextTown[index2].pathColor.equals(Color.GREEN) &&
        p.trainCards[3]+p.trainCards[8] <
        cityList[city1].nextTown[index2].nTrains){
            JOptionPane.showMessageDialog(null, "Must have " +
                (cityList[city1].nextTown[index2].nTrains-p.trainCards[3])+
                ""+ " more green cards or sufficient "+
                "locomotives to buy this route");
            return false;
        }
        if (cityList[city1].nextTown[index2].pathColor.equals(Color.ORANGE) &&
        p.trainCards[4]+p.trainCards[8] <
        cityList[city1].nextTown[index2].nTrains){
            JOptionPane.showMessageDialog(null, "Must have " +
                (cityList[city1].nextTown[index2].nTrains-p.trainCards[4])+
                ""+ " more orange cards or sufficient locomotives "
                +"to buy this route");
            return false;
        }
        if (cityList[city1].nextTown[index2].pathColor.equals(Color.PINK) &&
        p.trainCards[5]+p.trainCards[8] <
        cityList[city1].nextTown[index2].nTrains){
            JOptionPane.showMessageDialog(null, "Must have " +
                (cityList[city1].nextTown[index2].nTrains-p.trainCards[5]) +
                ""+ " more purple cards or sufficient locomotives "
                +"to buy this route");
            return false;
        }
        if (cityList[city1].nextTown[index2].pathColor.equals(Color.BLACK) &&
        p.trainCards[6]+p.trainCards[8] <
        cityList[city1].nextTown[index2].nTrains){
            JOptionPane.showMessageDialog(null, "Must have " +
                (cityList[city1].nextTown[index2].nTrains-p.trainCards[6]) +
                ""+ " more black cards or sufficient locomotives "
                +"to buy this route");
            return false;
        }
        if (cityList[city1].nextTown[index2].pathColor.equals(Color.WHITE) &&
        p.trainCards[7]+p.trainCards[8] <
        cityList[city1].nextTown[index2].nTrains){
            JOptionPane.showMessageDialog(null, "Must have " +
                (cityList[city1].nextTown[index2].nTrains-p.trainCards[7]) +
                ""+ " more white cards or sufficient locomotives "
                +"to buy this route");
            return false;
        }
        if(cityList[city1].nextTown[index2].pathColor.equals(Color.GRAY)){
            if (p.trainCards[7]+p.trainCards[8] >=
            cityList[city1].nextTown[index2].nTrains)
                return true;
            else if (p.trainCards[6]+p.trainCards[8] >=
            cityList[city1].nextTown[index2].nTrains)
                return true;
            else if (p.trainCards[5]+p.trainCards[8] >=
            cityList[city1].nextTown[index2].nTrains)
                return true;
            else if (p.trainCards[4]+p.trainCards[8] >=
            cityList[city1].nextTown[index2].nTrains)
                return true;
            else if (p.trainCards[3]+p.trainCards[8] >=
            cityList[city1].nextTown[index2].nTrains)
                return true;
            else if (p.trainCards[2]+p.trainCards[8] >=
            cityList[city1].nextTown[index2].nTrains)
                return true;
            else if (p.trainCards[1]+p.trainCards[8] >=
            cityList[city1].nextTown[index2].nTrains)
                return true;
            else if (p.trainCards[0]+p.trainCards[8] >=
            cityList[city1].nextTown[index2].nTrains)
                return true;
            else{
                JOptionPane.showMessageDialog(null,
                    "Must have more cards of a single color or "
                    +"locomotives to buy this route");
                return false;
            }
        }
        return true;
    }    
    // end addPath

    /**
     * isPath checks if there is a valid path for a particular player
     * @param city an integer value representing the beginning of the path
     * @param dest an integer value representing the end of the path
     * @return false is returned if a path can not be found
     * @return true is returned if a path is found
     */
    protected boolean isPath(int city, int dest)
    {
        // reset city array
        for(int i = 0; i < 48; i ++)
        {
            visited[city] = false;
        }// end for

        // your dest is your source, you're not going anywhere:
        if(city == dest)
        {
            return true;
        }   
        // if start OR end are not owned by you, take a hike
        if(!cityList[city].owned || !cityList[dest].owned)
        {
            return false;
        }
        // enter wrapped function to do dirty work:
        return _isPath(city, dest);

    }// end isPath

    /**
     * _isPath checks if there is a valid path for a particular player
     *         called by wrapper function isPath
     * @param city an integer value representing the beginning of the path
     * @param dest an integer value representing the end of the path
     * @return false is returned if a path can not be found
     * @return true is returned if a path is found
     */
    protected boolean _isPath(int city, int dest)
    {
        visited[city] = true;
        // for each neighboring city, check paths:
        for (int i = 0; i < cityList[city].next.length; i++)
        {
            // if the next city has not been visited yet 
            //and if the player owns it:
            if (!visited[citySwitch(cityList[city].next[i].name)] &&
            cityList[city].next[i].owned)
            {
                _isPath(citySwitch(cityList[city].next[i].name), dest);
            }// end if
        }// end for

        if(visited[dest] == true)
            return true;

        else return false;
    }// end _isPath

    /**
     * citySwitch takes in a string argument and returns
     * its corresponding integer value
     * @param city is the city to be converted to an integer
     * @return the corresponding integer value of the string
     */
    protected int citySwitch(String city)
    {
        int answer;            // variable to store city number

        switch (city) 
        {
            case "Stornoway"    :  answer = 0;
            break;
            case "Ullapool"     :  answer = 1;
            break;
            case "Wick"         :  answer = 2;
            break;
            case "Fort William" :  answer = 3;
            break;
            case "Inverness"    :  answer = 4;
            break;
            case "Aberdeen"     :  answer = 5;
            break;
            case "Londonderry"  :  answer = 6;
            break;
            case "Glasgow"      :  answer = 7;
            break;
            case "Edinburgh"    :  answer = 8;
            break;
            case "Dundee"       : answer = 9;
            break;
            case "Sligo"        : answer = 10;
            break;
            case "Belfast"      : answer = 11;
            break;
            case "Stranraer"    :  answer = 12;
            break;
            case "Galway"       :  answer = 13;
            break;
            case "Dundalk"      :  answer = 14;
            break;
            case "Carlisle"     :  answer = 15;
            break;
            case "Newcastle"    :  answer = 16;
            break;
            case "Limerick"     :  answer = 17;
            break;
            case "Tullamore"    :  answer = 18;
            break;
            case "Dublin"       :  answer = 19;
            break;
            case "Barrow"       :  answer = 20;
            break;
            case "Cork"         : answer = 21;
            break;
            case "Rosslare"     : answer = 22;
            break;
            case "Howhead"      : answer = 23;
            break;
            case "Liverpool"    :  answer = 24; 
            break;
            case "Leeds"        :  answer = 25;
            break;
            case "Aberystwyth" :  answer = 26;
            break;
            case "Manchester"   :  answer = 27;
            break;
            case "Hull"         :  answer = 28;
            break;
            case "Carmarthen"   :  answer = 29;
            break;
            case "Llandrindod Wells":  answer = 30;
            break;
            case "Birmingham"   :  answer = 31;
            break;
            case "Nottingham"   :  answer = 32;
            break;
            case "Cardiff"      : answer = 33;
            break;
            case "Northampton"  : answer = 34;
            break;
            case "Cambridge"    : answer = 35;
            break;
            case "Norwich"      :  answer = 36;
            break;
            case "Penzance"     :  answer =37;
            break;
            case "Plymouth"     :  answer = 38;
            break;
            case "Bristol"      :  answer = 39;
            break;
            case "Reading"      :  answer = 40;
            break;
            case "London"       :  answer = 41;
            break;
            case "Ipswich"      :  answer = 42;
            break;
            case "Southampton"  :  answer = 43;
            break;
            case "Brighton"     :  answer = 44;
            break;
            case "Dover"        : answer = 45;
            break;
            case "West France"  : answer = 46;
            break;
            case "East France"  : answer = 47;
            break;         
            case "New York" : answer = 48;
            break;
            default: answer = -1;
            break;

        }// end switch
        return answer;
    }// end citySwitch

    /**
     * coordSwitch takes in a string argument and
     * returns it's corresponding coordinates
     *             on the map
     * @param city is the city to be converted to coordinates
     * @return the corresponding coordinates of the city
     */
    protected int [] coordSwitch(String city)
    {
        int answer [] = new int [2]; // variable to store city number

        switch (city) 
        {
            case "Stornoway"    :  answer[0] = 413; answer[1] = 42;
            break;
            case "Ullapool"     :  answer[0] = 449; answer[1] = 89;
            break;
            case "Wick"         :  answer[0] = 574; answer[1] = 88;
            break;
            case "Fort William" :  answer[0] = 401; answer[1] = 178;
            break;
            case "Inverness"    :  answer[0] = 483; answer[1] = 134;
            break;
            case "Aberdeen"     :  answer[0] = 565; answer[1] = 214;
            break;
            case "Londonderry"  :  answer[0] = 230; answer[1] = 261;
            break;
            case "Glasgow"      :  answer[0] = 406; answer[1] = 278;
            break;
            case "Edinburgh"    :  answer[0] = 467; answer[1] = 295;
            break;
            case "Dundee"       : answer[0] = 507; answer[1] = 249;
            break;
            case "Sligo"        : answer[0] = 128; answer[1] = 295;
            break;
            case "Belfast"      : answer[0] = 273; answer[1] = 340;
            break;
            case "Stranraer"    :  answer[0] = 335; answer[1] = 335;
            break;
            case "Galway"       :  answer[0] = 55; answer[1] = 364;
            break;
            case "Dundalk"      :  answer[0] = 221; answer[1] = 377;
            break;
            case "Carlisle"     :  answer[0] = 430; answer[1] = 390;
            break;
            case "Newcastle"    :  answer[0] = 502; answer[1] = 409;
            break;
            case "Limerick"     :  answer[0] = 56; answer[1] = 432;
            break;
            case "Tullamore"    :  answer[0] = 136; answer[1] = 417;
            break;
            case "Dublin"       :  answer[0] = 197; answer[1] = 433;
            break;
            case "Barrow"       :  answer[0] = 388; answer[1] = 438;
            break;
            case "Cork"         : answer[0] = 44; answer[1] = 501;
            break;
            case "Rosslare"     : answer[0] = 145; answer[1] = 513;
            break;
            case "Howhead"      : answer[0] = 286; answer[1] = 478;
            break;
            case "Liverpool"    :  answer[0] = 361; answer[1] = 491;
            break;
            case "Leeds"        :  answer[0] = 464; answer[1] = 496;
            break;
            case "Aberystwyth" :  answer[0] = 264; answer[1] = 564;
            break;
            case "Manchester"   :  answer[0] = 409; answer[1] = 522;
            break;
            case "Hull"         :  answer[0] = 518; answer[1] = 534;
            break;
            case "Carmarthen"   :  answer[0] = 228; answer[1] = 615;
            break;
            case "Llandrindod Wells":  answer[0] = 307; answer[1] = 606;
            break;
            case "Birmingham"   :  answer[0] = 391; answer[1] = 618;
            break;
            case "Nottingham"   :  answer[0] = 446; answer[1] = 590;
            break;
            case "Cardiff"      : answer[0] = 271; answer[1] = 655;
            break;
            case "Northampton"  : answer[0] = 431; answer[1] = 663;
            break;
            case "Cambridge"    : answer[0] = 490; answer[1] = 680;
            break;
            case "Norwich"      :  answer[0] = 583; answer[1] = 674;
            break;
            case "Penzance"     :  answer[0] = 90; answer[1] = 711;
            break;
            case "Plymouth"     :  answer[0] = 186; answer[1] = 722;
            break;
            case "Bristol"      :  answer[0] = 311; answer[1] = 692;
            break;
            case "Reading"      :  answer[0] = 397; answer[1] = 713;
            break;
            case "London"       :  answer[0] = 458; answer[1] = 733;
            break;
            case "Ipswich"      :  answer[0] = 537; answer[1] = 725;
            break;
            case "Southampton"  :  answer[0] = 362; answer[1] = 769;
            break;
            case "Brighton"     :  answer[0] = 429; answer[1] = 796;
            break;
            case "Dover"        : answer[0] = 527; answer[1] = 797;
            break;
            case "West France"  : answer[0] = 313; answer[1] = 871;
            break;
            case "East France"  : answer[0] = 601; answer[1] = 838;
            break;       
            case "New York" : answer[0] = 29; answer[1] = 821; 
            break;
            default: answer[0] = -1; answer[1] = -1;
            break;

        }// end switch
        return answer;
    }// end citySwitch

    /**
     * routeChecker resets visited array and then calls wrapped
     * function _routeChecker
     * @param player is the player number whose route is being checked
     * @param list contains a list of routes to be checked
     * @param index is the location in the list the route is to be checked
     * @return returns true if route is found, false otherwise
     */
    public boolean routeChecker(int player, ArrayList<String> list, int index)
    {

        String city1 = parseString1(list, index);
        String city2 = parseString2(list, index);

        int int_city1 = citySwitch(city1);
        int int_city2 = citySwitch(city2);

        // reset city array
        for(int i = 0; i < 48; i ++)
        {
            visited[i] = false;
        }// end for

        return _routeChecker(player, int_city1, int_city2);
    }// end routeChecker

    /**
     * _routeChecker called by wrapper function, 
     * searches for route recursively
     * @param player is the player number whose route is being checked
     * @param city1 is the first city in the route
     * @param city2 is the target city being searched for
     * @return returns true if route is found, false otherwise
     */
    public boolean _routeChecker(int player, int city1, int city2)
    {
        visited[city1] = true;

        // for each neighboring city check pNum
        for(int i = 0; i < cityList[city1].nextTown.length; i++)
        {
            if(cityList[city1].nextTown[i].ownedBy == null) continue;

            // grab index of next town over, for further processing:
            int val = citySwitch(cityList[city1].nextTown[i].name);

            // if the player number is the same as the next town pNum
            //dig deeper:
            if(player == cityList[city1].nextTown[i].ownedBy.pNum &&
            !visited[val])
            {
                // if the neighbor is the target city, return true:
                if(cityList[city1].nextTown[i].name == cityList[city2].name)
                {
                    return true;
                }// end inner if

                return _routeChecker(player, val, city2);
            }// end if
        }// end for

        return false;
    }// end _routeChecker

    /**
     * parseString1 parses string from arraylist for processing
     * @param list is the arraylist being searched
     * @param index is the index of the string to be processed
     * @return the parsed string value
     */
    public static String parseString1(ArrayList<String> list, int index)
    {
        String ans = list.get(index);

        int val = ans.indexOf(95);

        ans = ans.substring(0, val);

        String temp = ans.substring(0,1).toUpperCase() + ans.substring(1);
        ans = temp.trim();

        return ans;
    }// end parseString1

    /**
     * parseString2 parses string from arraylist for processing
     * @param list is the arraylist being searched
     * @param index is the index of the string to be processed
     * @return the parsed string value
     */
    public static String parseString2(ArrayList<String> list, int index)
    {
        String ans = list.get(index);

        int val = ans.indexOf(95);

        ans = ans.substring(val + 1, ans.length());

        String temp = ans.substring(0,1).toUpperCase() + ans.substring(1);
        ans = temp.trim();

        return ans;
    }// end parseString2

}
