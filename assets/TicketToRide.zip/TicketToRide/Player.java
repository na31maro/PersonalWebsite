import java.awt.*;
import java.util.ArrayList;
/**
 * 
 * This is a class that represents a player
 * for the game, Ticket to Ride.  It will have
 * all the variables necessary for each player.
 * 
 * @author Jordan McKosky 
 * @version 1.0
 */
public class Player
{                        
    //Color of the player
    protected Color pColor = null;

    //Number of the player... purpose
    //is for taking turns
    protected int pNum;

    //int array of each player's 
    //train cards that they have
    //in the hand at the current turn
    protected int[] trainCards = new int[9];

    //int number of each player's
    //trains that are current on the
    //board
    protected int pNumTrains;
    //Number of trains a player has left
    //Starts at 35
    protected int numTrainsLeft = 35;

    //Technology object, all the boolean
    //varaibles of the technologies that
    //will help determine if a player
    //has that technology

    protected Technology tech = new Technology();

    //points of a player
    protected int points = 0;

    //helps with the coutning of 
    //locomotive cards
    protected int extraR = 0;

    //Player List of Destinations
    ArrayList<String> pDestList = new ArrayList<String>();

    /**
     * This constructor gives the
     * player initializes a player's
     * player number.
     * @param num the number to be assigned to the player
     */
    public Player(int num){
        pNum = num;
    }

    //PLAYER GETTERS AND SETTERS

    /**
     * This methods returns a player's game
     * color.
     * 
     * @return pColor the player's game color
     */
    public Color getPColor(){
        return pColor;
    }

    /**
     * This methods sets a player's game
     * color.
     * 
     * @param c the player's color
     */
    public void setPColor(Color c){
        pColor = c;
    }

    /**
     * This method returns a player's
     * game number
     * 
     * @return pNum the player's game number
     * 
     */
    public int getPlayerNumber(){
        return pNum;  
    } 

    /**
     * This method returns an int value
     * of the current number of trains
     * the player has
     * 
     * @returns pNumTrains the 
     * number of trains that the player has
     */
    public int getPNumTrains(){
        return pNumTrains;
    }

    /**
     * This method returns an int value
     * of the current number of points
     * the player has.
     * 
     * @return points the 
     * number of points that the player has
     */
    public int getPoints(){
        return points;
    }

    /**
     * This method adds points to the 
     * players total point counter based
     * on how many trains are present
     * on the board for that 
     * respective player.
     * 
     * @param add int value of points to add
     * to the player's points.
     */
    public void addPoints(int add){
        if(points + add < 0)
            points = 0;
        else
            points += add;
    }

    /**
     * This method returns an int value
     * of the number of trains that the player
     * has left.
     * 
     * @return numTrainsLeft the number of train
     * pieces that a player has left
     */
    public int getNumTrainsLeft(){
        return numTrainsLeft;
    }
}
