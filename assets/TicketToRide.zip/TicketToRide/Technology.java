
/**
 * This class will hold boolean values
 * that will determine if a player
 * owns the respective technology card.
 * 
 * @author Jordan McKosky 
 * @version 1.0
 */
public class Technology
{
   
   //Boolean variables that determine if a
   //player has a certain technology card.
   
   //If a player has a technology card,
   //the boolean variable will be true.
   protected boolean boiler = false;
   //FINISHED IMPLEMENTATION
   protected boolean booster = false;
   protected boolean dieselPower = false;
   protected boolean doubleHeading = false;
   protected boolean equalising = false;
   protected boolean irelandFranceCon = false;
   protected boolean mechanicalStoker = false;
   protected boolean propellers = false;
   protected boolean rightOfWay = false;
   protected boolean riskyContracts = false;
   protected boolean ScotlandCon = false;
   protected boolean steamTurbine = false;
   protected boolean superHeated = false;
   protected boolean thermoCompressor = false;
   protected boolean walesCon = false;
   protected boolean waterTenders = false;
    
}
