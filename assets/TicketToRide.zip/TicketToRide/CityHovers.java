import java.awt.event.*;
/**
 * This class helps utilize hovers over the
 * gameboard that will be displayed when the 
 * mouse is over a certain location on the
 * gameboard.
 * 
 * @author Group 6
 * @version 1.0
 */
public class CityHovers 
{   
    /**
     * This Method that accepts a MouseEvent and changes
     * one of the booleans
     * 
     * @param e MouseEvent where the mouse is 
     *          currently located.
     *   
     * @return the data for the city that is being hovered over
     * (name, x and y coord)
     */
    public DrawString checkCityHover(MouseEvent e){
        //FORMAT 
        //if(locateClick(e, StartX, EndX, Start Y, EndY)
        //return new DrawString("city name", CenterX, CenterY)

        
        if(locateClick(e,403,423,32,52))
            return new DrawString("Stornoway",413,42);

            else if(locateClick(e,439,459,79,99))
            return new DrawString("Ullapool",449,89);
            
            else if(locateClick(e,564,584,78,98))
            return new DrawString("Wick",574,88);
            
            else if(locateClick(e,391,411,168,188))
            return new DrawString("Fort William",401,178);
            
            else if(locateClick(e,473,493,124,144))
            return new DrawString("Inverness",483,134);
            
            else if(locateClick(e,555,575,204,224))
            return new DrawString("Aberdeen",565,214);
            
            else if(locateClick(e,220,240,251,271))
            return new DrawString("Londonderry",230,261);
            
            else if(locateClick(e,396,416,268,288))
            return new DrawString("Glasgow",406,278);
            
            else if(locateClick(e,457,477,285,305))
            return new DrawString("Edinburgh",467,295);
            
            else if(locateClick(e,497,517,239,259))
            return new DrawString("Dundee",507,249);
            
            else if(locateClick(e,118,138,285,305))
            return new DrawString("Sligo",128,295);
            
            else if(locateClick(e,325,345,325,345))
            return new DrawString("Stranraer",335,335);
            
            else if(locateClick(e,263,283,330,350))
            return new DrawString("Belfast",273,340);
            
            else if(locateClick(e,45,65,354,374))
            return new DrawString("Galway",55,364);
            
            else if(locateClick(e,211,231,367,387))
            return new DrawString("Dundalk",221,377);
            
            else if(locateClick(e,420,440,380,400))
            return new DrawString("Carlisle",430,390);
            
            else if(locateClick(e,492,512,399,419))
            return new DrawString("Newcastle",502,409);
            
            else if(locateClick(e,46,66,422,442))
            return new DrawString("Limerick",56,432);
            
            else if(locateClick(e,126,146,407,427))
            return new DrawString("Tullamore",136,417);
            
            else if(locateClick(e,187,207,423,443))
            return new DrawString("Dublin",197,433);
            
            else if(locateClick(e,378,398,428,448))
            return new DrawString("Barrow",388,438);
            
            else if(locateClick(e,34,54,491,511))
            return new DrawString("Cork",44,501);
            
            else if(locateClick(e,135,155,503,523))
            return new DrawString("Rosslare",145,513);
            
            else if(locateClick(e,276,296,468,488))
            return new DrawString("Howhead",286,478);
            
            else if(locateClick(e,351,371,481,501))
            return new DrawString("Liverpool",361,491);
            
            else if(locateClick(e,454,474,486,506))
            return new DrawString("Leeds",464,496);
            
            else if(locateClick(e,254,274,554,574))
            return new DrawString("Aberystwyth",264,564);
            
            else if(locateClick(e,399,419,512,532))
            return new DrawString("Manchester",409,522);
            
            else if(locateClick(e,508,528,524,544))
            return new DrawString("Hull",518,534);
            
            else if(locateClick(e,218,238,605,625))
            return new DrawString("Carmarthen",228,615);
            
            else if(locateClick(e,297,317,596,616))
            return new DrawString("Llandrindod Well",307,606);
            
            else if(locateClick(e,381,401,608,628))
            return new DrawString("Birmingham",391,618);
            
            else if(locateClick(e,436,456,580,600))
            return new DrawString("Nottingham",446,590);
            
            else if(locateClick(e,261,281,645,665))
            return new DrawString("Cardiff",271,655);
            
            else if(locateClick(e,421,441,653,673))
            return new DrawString("Northampton",431,663);
            
            else if(locateClick(e,480,500,670,690))
            return new DrawString("Cambridge",490,680);
            
            else if(locateClick(e,573,593,664,684))
            return new DrawString("Norwich",583,674);
            
            else if(locateClick(e,80,100,701,721))
            return new DrawString("Penzance",90,711);
            
            else if(locateClick(e,176,196,712,732))
            return new DrawString("Plymouth",186,722);
            
            else if(locateClick(e,301,321,682,702))
            return new DrawString("Bristol",311,692);
            
            else if(locateClick(e,387,407,703,723))
            return new DrawString("Reading",397,713);
            
            else if(locateClick(e,448,468,723,743))
            return new DrawString("London",458,733);
            
            else if(locateClick(e,527,547,715,735))
            return new DrawString("Ipswich",537,725);
            
            else if(locateClick(e,352,372,759,779))
            return new DrawString("Southampton",362,769);
            
            else if(locateClick(e,419,439,786,806))
            return new DrawString("Brighton",429,796);
            
            else if(locateClick(e,517,537,787,807))
            return new DrawString("Dover",527,797);
            
            else if(locateClick(e,303,323,861,881))
            return new DrawString("West France",313,871);
            
            else if(locateClick(e,591,611,828,848))
            return new DrawString("East France",601,838);
            else if(locateClick(e,19,39,811,831))
            return new DrawString("New York", 29,821);
        else             
            return null;

    }

    /**
     * This method returns true if the mouse is clicked
     * at a specific location range and false if not
     * 
     * @param e MouseEvent where the click is located
     * @param startX starting X coordinate of desired range
     * @param endX end X coordinate of desired range
     * @param startY starting Y coordinate of desired range
     * @param endY end Y coordinate of desired range
     * 
     * @return true if mouse is clicked within specific range
     * @return false if mouse is not clicked within specific range
     */
    public boolean locateClick(MouseEvent e, int startX, 
    int endX, int startY, int endY){
        if(e.getX() > startX && e.getX() < endX &&e.getY() 
        > startY && e.getY() < endY)
            return true;
        return false;
    }

}
