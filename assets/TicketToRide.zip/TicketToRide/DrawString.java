
/**
 * This class holds the name of the city that a player is 
 * hovering over and the x and y coordinates and allows the
 * program to paint the hover.
 * 
 * @author Group 6
 * @version 1.0
 */
public class DrawString
{
    protected String name = "";
    protected int xVal;
    protected int yVal; 
    
    /**
     * This constructor initializes the
     * name, x, and y coordinates of the string
     * that will be hovering over the respective city.
     * 
     * @param n String of the city name
     * @param x x coordinate of the hover text
     * @param y y coordinate of the hover text
     */
    public DrawString(String n, int x, int y){
        name = n;
        xVal = x;
        yVal = y; 
    }
    
    /**
     * This method returns the name of the city
     * of the hover text
     * 
     * @return String name of the city
     */
    public String getName(){
        return name;
    }
    
    
    /**
     * This method returns the x coordinate of the
     * hover text
     * 
     * @return int x coordinate of the hover text.
     */
    public int getX(){
        return xVal;
    }
    
    /**
     * This method returns the y coordinate of the
     * hover text
     * 
     * @return in y coordinate of the hover text.
     */
    public int getY(){
        return yVal;
    }
}
